import {tcgStatus,startTcg,stopTcg} from './src/server/tcgAdmin.ts';
import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import { WebSocketServer, type WebSocket } from 'ws';
import {
  authenticateAdminPassword,
  authenticateMemberPassword,
  authenticateUnifiedLogin,
  claimFirstRunAdminPassword,
  consumeWsTicket,
  credentialVersion,
  createMemberAccount,
  deleteMemberAccount,
  findMemberByEmailOrId,
  getAuthSetupStatus,
  getEffectiveAdminIdentity,
  issueWsTicket,
  listMemberAccounts,
  requireAdmin,
  requireAuth,
  updateMemberAccount,
} from './src/server/authVerify.ts';
import {
  assignVpsOwner,
  bootstrapExistingNativeVps,
  enforceExpiry,
  sampleRuntimeMetrics,
  changeVpsPassword,
  createVpsInstance,
  deleteVpsInstance,
  disableVpsPublicSsh,
  disableVpsSshx,
  enableVpsPublicSsh,
  enableVpsSshx,
  executeVpsCommand,
  getClusterTasks,
  getHostDiagnostics,
  getVpsInstance,
  listVpsInstances,
  reinstallVpsInstance,
  resizeVpsInstance,
  restoreInstancesFromCloud,
  setVpsPowerState,
  streamVpsCommand,
  openInteractive, listProvisioningNodes,
} from './src/server/nativeUbuntuEngine.ts';
import { stopAllPublicSshTunnels } from './src/server/sshTunnel.ts';
import { stopAllSshxSessions } from './src/server/sshxTunnel.ts';
import {
  bootstrapEnvPanelTunnel,
  getPanelTunnelStatus,
  startPanelTunnel,
  stopPanelTunnel,
} from './src/server/cloudflarePanelTunnel.ts';
import {
  getSiteSettings,
  resolveSafeMediaFile,
  saveUploadedBackgroundMedia,
  saveUploadedLogoMedia,
  updateSiteSettings,
} from './src/server/siteSettings.ts';
import { getOsOption, type CloudflareTunnel, type OsId } from './src/types/vps.ts';
import {
  getDiscordBotStatus,
  initDiscordBot,
  reconfigureDiscordBot,
} from './src/server/discordBot.ts';
import { getSshKeys, addSshKey, deleteSshKey } from './src/server/sshKeys.ts';

const PORT = Number(process.env.PORT) || 3000;
const app = express();
const server = http.createServer(app);
const startedAt = Date.now();

const DATA_ROOT = path.resolve(process.cwd(), '.killoracloud-data');
const TUNNELS_FILE = path.join(DATA_ROOT, 'cloudflare-tunnels.json');

function loadLocalTunnels(): CloudflareTunnel[] {
  try {
    if (fs.existsSync(TUNNELS_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(TUNNELS_FILE, 'utf8'));
      return Array.isArray(parsed) ? parsed : [];
    }
  } catch {
    // ignore
  }
  return [];
}

function saveLocalTunnels(list: CloudflareTunnel[]): void {
  fs.mkdirSync(DATA_ROOT, { recursive: true, mode: 0o755 });
  fs.writeFileSync(TUNNELS_FILE, JSON.stringify(list, null, 2), 'utf8');
}

app.disable('x-powered-by');
app.set('trust proxy', 'loopback');
app.use(express.json({ limit: '1mb' }));
// Reject browser cross-origin mutations, including requests carrying session cookies.
app.use('/api', (req,res,next)=>{
  res.setHeader('Cache-Control','no-store');
  res.setHeader('X-Content-Type-Options','nosniff');
  if(!['GET','HEAD','OPTIONS'].includes(req.method)){
    const origin=req.headers.origin;
    const allowed=(process.env.KC_PUBLIC_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean);
    if(req.headers['sec-fetch-site']==='cross-site'||(origin && !allowed.includes(origin) && origin!==`${req.protocol}://${req.get('host')}`)) {res.status(403).json({error:'Cross-origin request denied'});return;}
  }
  next();
});

// Bounded, per-process request throttling; deploy behind a trusted reverse proxy.
const rateBuckets = new Map<string, { count: number; until: number }>();
app.use('/api', (req, res, next) => {
  const now = Date.now();
  const auth = req.path.startsWith('/auth/') && req.method === 'POST';
  const key = `${req.ip}:${auth ? 'auth' : 'api'}`;
  let bucket = rateBuckets.get(key);
  if (!bucket || bucket.until <= now) {
    if (rateBuckets.size >= 10000) { res.status(503).json({error:'Rate limiter busy'}); return; }
    bucket = {count:0,until:now+60000}; rateBuckets.set(key,bucket);
  }
  if (++bucket.count > (auth ? 10 : 180)) { res.setHeader('Retry-After','60'); res.status(429).json({error:'Too many requests'}); return; }
  next();
});
setInterval(()=>{for(const [k,v] of rateBuckets) if(v.until<=Date.now()) rateBuckets.delete(k);},60000).unref();

// Public 24/7 uptime heartbeat endpoints
app.get('/api/ping', (_req, res) => {
  res.json({
    ok: true,
    ts: Date.now(),
    uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
  });
});

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    status: 'healthy',
    uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
    ts: new Date().toISOString(),
  });
});

// Public Panel Branding, Glass Effect & Background Settings (never leaks Discord Bot Token)
app.get('/api/site-settings', (_req, res) => {
  const s = getSiteSettings();
  res.json({
    settings: {
      ...s,
      discordBotToken: '',
    },
  });
});

app.put('/api/site-settings', requireAuth, requireAdmin, (req, res) => {
  try {
    const body = { ...(req.body ?? {}) } as Record<string, unknown>;
    const tokenChanged =
      typeof body.discordBotToken === 'string' && body.discordBotToken.trim().length > 0;
    const roleOrGuildChanged =
      typeof body.discordGuildId === 'string' || typeof body.discordAdminRoleId === 'string';
    // Never wipe saved Discord bot token when saving unrelated branding/theme fields
    if (typeof body.discordBotToken === 'string' && !body.discordBotToken.trim()) {
      delete body.discordBotToken;
    }
    const settings = updateSiteSettings(body);
    if (tokenChanged || roleOrGuildChanged) {
      reconfigureDiscordBot();
    }
    res.json({
      settings: {
        ...settings,
        discordBotToken: '',
      },
    });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to save panel settings' });
  }
});

// Admin-only Discord Bot Live Status & Configuration
app.get('/api/discord/config', requireAuth, requireAdmin, (_req, res) => {
  const s = getSiteSettings();
  const status = getDiscordBotStatus();
  res.json({
    ...status,
    discordGuildId: s.discordGuildId,
    discordAdminRoleId: s.discordAdminRoleId,
  });
});

app.put('/api/discord/config', requireAuth, requireAdmin, (req, res) => {
  try {
    const body = req.body ?? {};
    const patch: Record<string, unknown> = {};
    if (body.clearToken === true) {
      patch.discordBotToken = '';
    } else if (typeof body.discordBotToken === 'string' && body.discordBotToken.trim()) {
      patch.discordBotToken = body.discordBotToken.trim();
    }
    if (typeof body.discordGuildId === 'string') {
      patch.discordGuildId = body.discordGuildId.trim();
    }
    if (typeof body.discordAdminRoleId === 'string') {
      patch.discordAdminRoleId = body.discordAdminRoleId.trim();
    }
    const updated = updateSiteSettings(patch);
    reconfigureDiscordBot();
    const status = getDiscordBotStatus();
    res.json({
      ...status,
      discordGuildId: updated.discordGuildId,
      discordAdminRoleId: updated.discordAdminRoleId,
    });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to update Discord bot config' });
  }
});

app.post(
  '/api/site-settings/upload-bg',
  requireAuth,
  requireAdmin,
  express.raw({ type: ['image/*', 'video/*'], limit: '25mb' }),
  (req, res) => {
    try {
      const buf = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
      const saved = saveUploadedBackgroundMedia(String(req.headers['content-type'] || ''), buf);
      const settings = updateSiteSettings({
        backgroundUrl: saved.url,
        backgroundMode: saved.mediaKind,
      });
      res.status(201).json({ url: saved.url, mediaKind: saved.mediaKind, settings });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Upload failed' });
    }
  }
);

app.post(
  '/api/site-settings/upload-logo',
  requireAuth,
  requireAdmin,
  express.raw({ type: ['image/*'], limit: '8mb' }),
  (req, res) => {
    try {
      const buf = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
      const saved = saveUploadedLogoMedia(String(req.headers['content-type'] || ''), buf);
      const settings = updateSiteSettings({
        logoUrl: saved.url,
      });
      res.status(201).json({ url: saved.url, settings });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Logo upload failed' });
    }
  }
);

app.get('/media/:filename', (req, res) => {
  const filename = paramId(req.params.filename);
  const resolved = resolveSafeMediaFile(filename);
  if (!resolved) {
    res.status(404).end();
    return;
  }
  res.setHeader('Content-Type', resolved.contentType);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.sendFile(resolved.filePath, { dotfiles: 'allow' });
});

function attachSessionCookie(res: express.Response, token: string): void {
  const maxAgeMs = 1000 * 60 * 60 * 8;
  res.cookie('kc_session', token, {
    httpOnly: true,
    sameSite: 'strict',
    secure: true,
    path: '/',
    maxAge: maxAgeMs,
  });
}

// Public auth status & Single Unified Login endpoint (Admin + Member)
app.get('/api/auth/status', (_req, res) => {
  res.json(getAuthSetupStatus());
});

app.post('/api/auth/admin/setup', (req, res) => {
  try {
    const username = typeof req.body?.username === 'string' ? req.body.username : 'admin';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const email = typeof req.body?.email === 'string' ? req.body.email : undefined;
    const result = claimFirstRunAdminPassword(username, password, email);
    attachSessionCookie(res, result.token);
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Admin setup failed' });
  }
});

app.post('/api/auth/login', (req, res) => {
  try {
    const identifier =
      typeof req.body?.identifier === 'string'
        ? req.body.identifier
        : typeof req.body?.username === 'string'
          ? req.body.username
          : '';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const result = authenticateUnifiedLogin(identifier, password);
    attachSessionCookie(res, result.token);
    res.json(result);
  } catch (err) {
    res.status(401).json({ error: err instanceof Error ? err.message : 'Invalid credentials' });
  }
});

app.post('/api/auth/admin/login', (req, res) => {
  try {
    const username = typeof req.body?.username === 'string' ? req.body.username : 'admin';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const result = authenticateAdminPassword(username, password);
    attachSessionCookie(res, result.token);
    res.json(result);
  } catch (err) {
    res.status(401).json({ error: err instanceof Error ? err.message : 'Invalid admin credentials' });
  }
});

app.post('/api/auth/member/login', (req, res) => {
  try {
    const username = typeof req.body?.username === 'string' ? req.body.username : '';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const result = authenticateMemberPassword(username, password);
    attachSessionCookie(res, result.token);
    res.json(result);
  } catch (err) {
    res.status(401).json({ error: err instanceof Error ? err.message : 'Invalid member credentials' });
  }
});

app.post('/api/auth/logout', (_req, res) => {
  res.clearCookie('kc_session', { path: '/', sameSite: 'strict', secure: true });
  res.json({ ok: true });
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  res.json({ user: req.user });
});

// Member Account Creator CRUD (Admin only — members are strictly role: 'member' with Gmail)
app.get('/api/members', requireAuth, requireAdmin, (_req, res) => {
  res.json({ members: listMemberAccounts() });
});

app.post('/api/members', requireAuth, requireAdmin, (req, res) => {
  try {
    const created = createMemberAccount({
      username: typeof req.body?.username === 'string' ? req.body.username : '',
      password: String(req.body?.password || ''),
      displayName: typeof req.body?.displayName === 'string' ? req.body.displayName : undefined,
      email: String(req.body?.email || ''),
      maxVps: Number(req.body?.maxVps) || 5,
      maxVcpu: Number(req.body?.maxVcpu) || 32,
      maxRamMb: Number(req.body?.maxRamMb) || 32768,
      maxDiskGb: Number(req.body?.maxDiskGb) || 500,
    });
    res.status(201).json({ member: created });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to create member' });
  }
});

app.patch('/api/members/:id', requireAuth, requireAdmin, (req, res) => {
  try {
    const id = paramId(req.params.id);
    const updated = updateMemberAccount(id, req.body ?? {});
    res.json({ member: updated });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to update member' });
  }
});

app.delete('/api/members/:id', requireAuth, requireAdmin, (req, res) => {
  const id = paramId(req.params.id);
  deleteMemberAccount(id);
  res.json({ ok: true });
});

// Real Panel Cloudflare Tunnel (connects THIS website/panel on port 3000 to your custom domain or trycloudflare URL)
app.get('/api/panel-tunnel/status', requireAuth, requireAdmin, (_req, res) => {
  res.json({ tunnel: getPanelTunnelStatus() });
});

app.post('/api/panel-tunnel/start', requireAuth, requireAdmin, async (req, res) => {
  try {
    const mode = req.body?.mode === 'quick' ? 'quick' : 'token';
    const token = typeof req.body?.token === 'string' ? req.body.token : undefined;
    const customUrl = typeof req.body?.customUrl === 'string' ? req.body.customUrl : undefined;
    const tunnel = await startPanelTunnel({ mode, token, customUrl });
    res.json({ tunnel });
  } catch (err) {
    res.status(400).json({
      error: err instanceof Error ? err.message : 'Failed to start Cloudflare Panel Tunnel',
      tunnel: getPanelTunnelStatus(),
    });
  }
});

app.post('/api/panel-tunnel/stop', requireAuth, requireAdmin, (_req, res) => {
  const tunnel = stopPanelTunnel();
  res.json({ tunnel });
});

// Cloudflare Tunnel local persistence endpoints (also synced to Firestore when Google is linked)
app.get('/api/tunnels', requireAuth, (req, res) => {
  const user = req.user!;
  const all = loadLocalTunnels();
  const filtered = user.isAdmin ? all : all.filter((t) => t.ownerId === user.uid);
  res.json({ tunnels: filtered });
});

app.post('/api/tunnels', requireAuth, (_req, res) => {
  res.status(501).json({error: 'Guest tunnel provisioning is not implemented; admin panel Cloudflare tunnel remains available'});
});

app.patch('/api/tunnels/:id', requireAuth, (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const all = loadLocalTunnels();
  const found = all.find((t) => t.id === id);
  if (!found) {
    res.status(404).json({ error: 'Tunnel not found' });
    return;
  }
  if (!user.isAdmin && found.ownerId !== user.uid) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }
  if (typeof req.body?.enabled === 'boolean') found.enabled = req.body.enabled;
  found.updatedAt = new Date().toISOString();
  saveLocalTunnels(all);
  res.json({ tunnel: found });
});

app.delete('/api/tunnels/:id', requireAuth, (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const all = loadLocalTunnels();
  const found = all.find((t) => t.id === id);
  if (!found) {
    res.status(404).json({ error: 'Tunnel not found' });
    return;
  }
  if (!user.isAdmin && found.ownerId !== user.uid) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }
  saveLocalTunnels(all.filter((t) => t.id !== id));
  res.json({ ok: true });
});

function paramId(raw: string | string[] | undefined): string {
  return Array.isArray(raw) ? raw[0] || '' : raw || '';
}

function assertVpsAccess(
  vpsId: string,
  uid: string,
  isAdmin: boolean,
  email?: string
):
  | { ok: false; error: string; status: 403 | 404 }
  | { ok: true; instance: NonNullable<ReturnType<typeof getVpsInstance>> } {
  const inst = getVpsInstance(vpsId);
  if (!inst) return { ok: false, error: 'VPS not found', status: 404 };
  const normEmail = (email || '').trim().toLowerCase();
  const emailOwnerMatch = false;
  void normEmail;
  if (!isAdmin && inst.ownerId !== uid && !emailOwnerMatch) {
    return { ok: false, error: 'Forbidden', status: 403 };
  }
  return { ok: true, instance: inst };
}

// Host diagnostics & cluster tasks (authenticated)
app.get('/api/host/diagnostics', requireAuth, requireAdmin, (req, res) => {
  res.json({
    diagnostics: getHostDiagnostics(),
    tasks: req.user?.isAdmin ? getClusterTasks() : [],
  });
});

// SSH Keys Management Endpoints
app.get('/api/ssh-keys', requireAuth, (req, res) => {
  try {
    const user = req.user!;
    const keys = getSshKeys(user.email || user.username || 'admin');
    res.json({ keys });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to fetch SSH keys' });
  }
});

app.post('/api/ssh-keys', requireAuth, (req, res) => {
  try {
    const user = req.user!;
    const { name, publicKey } = req.body ?? {};
    const keyRecord = addSshKey(user.email || user.username || 'admin', name, publicKey);
    res.status(201).json({ key: keyRecord });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to add SSH key' });
  }
});

app.delete('/api/ssh-keys/:id', requireAuth, (req, res) => {
  try {
    const user = req.user!;
    const keyId = paramId(req.params.id);
    deleteSshKey(user.email || user.username || 'admin', keyId);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to delete SSH key' });
  }
});

// List user's VPS instances (Admin sees all; Members see VPS owned by their UID or Gmail)
app.get('/api/tcg/status',requireAuth,requireAdmin,(_req,res)=>res.json(tcgStatus()));
app.post('/api/tcg/start',requireAuth,requireAdmin,async(req,res)=>{try{res.json(await startTcg(req.body?.mode));}catch{res.status(400).json({error:'TCG start failed; check private directory, dependencies and existing VM'});}});
app.post('/api/tcg/stop',requireAuth,requireAdmin,async(_req,res)=>{try{res.json(await stopTcg());}catch{res.status(409).json({error:'TCG stop failed or operation in progress'});}});
app.get('/api/provisioning-nodes', requireAuth, requireAdmin, (_req,res)=>res.json({nodes:listProvisioningNodes()}));
app.get('/api/vps', requireAuth, (req, res) => {
  const user = req.user!;
  res.json({
    instances: listVpsInstances(user.uid, user.isAdmin, user.email),
    tasks: req.user?.isAdmin ? getClusterTasks() : [],
  });
});

// Create new VPS / Proxmox VE instance (Admin only — Admin can assign to any Member's Gmail)
app.post('/api/vps', requireAuth, requireAdmin, async (req, res) => {
  try {
    const user = req.user!;
    const body = req.body ?? {};
    if (!body.name || typeof body.name !== 'string') {
      res.status(400).json({ error: 'Instance name is required' });
      return;
    }

    const reqVcpu = Number(body.vcpu) || 4;
    const reqRamMb = Number(body.ramMb) || 4096;
    const reqDiskGb = Number(body.diskGb) || 60;

    if (!user.isAdmin && user.quotas) {
      const owned = listVpsInstances(user.uid, false, user.email);
      if (owned.length >= user.quotas.maxVps) {
        res.status(403).json({ error: `VPS limit reached (${user.quotas.maxVps} max for your account)` });
        return;
      }
      if (reqVcpu > user.quotas.maxVcpu) {
        res.status(403).json({ error: `Requested vCPU exceeds your account quota (${user.quotas.maxVcpu} vCPU max)` });
        return;
      }
      if (reqRamMb > user.quotas.maxRamMb) {
        res.status(403).json({ error: `Requested RAM exceeds your account quota (${user.quotas.maxRamMb} MB max)` });
        return;
      }
      if (reqDiskGb > user.quotas.maxDiskGb) {
        res.status(403).json({ error: `Requested storage exceeds your account quota (${user.quotas.maxDiskGb} GB max)` });
        return;
      }
    }

    let targetOwnerId = user.uid;
    let targetOwnerEmail = user.email;

    if (user.isAdmin && typeof body.assignToEmail === 'string' && body.assignToEmail.trim()) {
      const assignEmail = body.assignToEmail.trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(assignEmail)) {
        res.status(400).json({ error: 'Invalid Member Gmail address for VPS assignment' });
        return;
      }
      const member = findMemberByEmailOrId(assignEmail);
      if (!member) throw Error('Create the member account before assigning a VPS');
      targetOwnerId = member ? member.id : `email:${assignEmail}`;
      targetOwnerEmail = member ? member.email : assignEmail;
    }

    const created = await createVpsInstance(
      targetOwnerId,
      {
        name: body.name,
        hostname: typeof body.hostname === 'string' ? body.hostname : undefined,
        osId: body.osId,
        vcpu: reqVcpu,
        ramMb: reqRamMb,
        diskGb: reqDiskGb,
        cpuModel: typeof body.cpuModel === 'string' ? body.cpuModel : undefined,
        rootPassword: typeof body.rootPassword === 'string' ? body.rootPassword : undefined,
        nodeName: typeof body.nodeName === 'string' ? body.nodeName : 'killora-node-01',
      },
      targetOwnerEmail
    );
    res.status(201).json({ instance: created });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to create VPS' });
  }
});

// Admin assigns or transfers an existing VPS to a Member's Gmail (or back to Admin)
app.patch('/api/vps/:id/assign', requireAuth, requireAdmin, (req, res) => {
  try {
    const id = paramId(req.params.id);
    const rawEmail = typeof req.body?.ownerEmail === 'string' ? req.body.ownerEmail.trim().toLowerCase() : '';
    const adminIdentity = getEffectiveAdminIdentity();

    if (!rawEmail || rawEmail === adminIdentity.email.toLowerCase()) {
      const updated = assignVpsOwner(id, 'admin-root', adminIdentity.email);
      res.json({ instance: updated });
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(rawEmail)) {
      res.status(400).json({ error: 'Enter a valid Member Gmail address (e.g. member@gmail.com)' });
      return;
    }

    const member = findMemberByEmailOrId(rawEmail);
    if (!member) throw Error('Create the member account before assigning a VPS');
    const updated = assignVpsOwner(id, member ? member.id : `email:${rawEmail}`, member ? member.email : rawEmail);
    res.json({ instance: updated });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to assign VPS' });
  }
});

// Cloud restore from Firestore after container restart/wake
app.post('/api/cloud/restore', requireAuth, async (req, res) => {
  try {
    const user = req.user!;
    const records = Array.isArray(req.body?.instances) ? req.body.instances : [];
    const instances = await restoreInstancesFromCloud(user.uid, records);
    res.json({ instances, restored: instances.length });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Cloud restore failed' });
  }
});

// Power actions (start, stop, reboot, pause, resume)
app.post('/api/vps/:id/power', requireAuth, async (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }

  const action = req.body?.action;
  if (!['start', 'stop', 'reboot', 'pause', 'resume'].includes(action)) {
    res.status(400).json({ error: 'Invalid power action' });
    return;
  }

  try {
    const updated = await setVpsPowerState(id, action);
    res.json({ instance: updated });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Power action failed' });
  }
});

// Change VPS root password (accessible to Admin and the assigned Member owner)
app.post('/api/vps/:id/password', requireAuth, async (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }

  try {
    const newPassword = typeof req.body?.password === 'string' ? req.body.password : '';
    const updated = await changeVpsPassword(id, newPassword);
    res.json({ instance: updated });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to change root password' });
  }
});

// Fresh OS Reinstall (accessible to Admin and the assigned Member owner)
app.post('/api/vps/:id/reinstall', requireAuth, async (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }

  try {
    const osId = (typeof req.body?.osId === 'string' ? req.body.osId : access.instance.osId) as OsId;
    const rootPassword =
      typeof req.body?.rootPassword === 'string' && req.body.rootPassword.trim()
        ? req.body.rootPassword.trim()
        : undefined;
    const updated = await reinstallVpsInstance(id, osId, rootPassword);
    res.json({ instance: updated });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to reinstall OS' });
  }
});

// Live hardware resize (Admin only)
app.post('/api/vps/:id/resize', requireAuth, requireAdmin, async (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }

  try {
    const updated = await resizeVpsInstance(id, {
      vcpu: Number(req.body?.vcpu),
      ramMb: Number(req.body?.ramMb),
      diskGb: Number(req.body?.diskGb),
      cpuModel: typeof req.body?.cpuModel === 'string' ? req.body.cpuModel : undefined,
    });
    res.json({ instance: updated });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Resize failed' });
  }
});

// Delete / destroy VPS instance (Admin only)
app.delete('/api/vps/:id', requireAuth, requireAdmin, async (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }

  try {
    await deleteVpsInstance(id);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Delete failed' });
  }
});

// Execute command in VPS console
app.post('/api/vps/:id/exec', requireAuth, async (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }

  const command = typeof req.body?.command === 'string' ? req.body.command : '';
  if (!command.trim() || command.length > 4000) {
    res.status(400).json({ error: 'Command must be between 1 and 4000 characters' });
    return;
  }

  try {
    const result = await executeVpsCommand(id, command);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Command failed' });
  }
});

// Live unbuffered SSE streaming endpoint (streams stdout/stderr instantaneously line-by-line through Cloud Run proxy)
app.post('/api/vps/:id/exec-stream', requireAuth, (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }

  const command = typeof req.body?.command === 'string' ? req.body.command : '';
  if (!command.trim() || command.length > 4000) {
    res.status(400).json({ error: 'Command must be between 1 and 4000 characters' });
    return;
  }

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.socket?.setNoDelay(true);
  res.flushHeaders?.();
  // Send 2KB initial SSE comment padding to force immediate proxy buffer flush
  res.write(`: ${' '.repeat(2048)}\n\n`);

  const writeSse = (payload: Record<string, unknown>) => {
    if (!res.writableEnded) {
      res.write(`data: ${JSON.stringify(payload)}\n\n`);
      (res as unknown as { flush?: () => void }).flush?.();
    }
  };

  try {
    let activeProc: { kill: () => void; writeStdin: (data: string) => void; resize?: (cols:number,rows:number)=>void } | null = null;
    activeProc = streamVpsCommand(id, command, {
      onChunk: (chunk) => {
        writeSse({ type: 'chunk', chunk });
      },
      onExit: (exitCode) => {
        activeProc = null;
        writeSse({ type: 'done', exitCode });
        if (!res.writableEnded) {
          res.end();
        }
      },
    });
    res.on('close', () => {
      activeProc?.kill();
      activeProc = null;
    });
  } catch (err) {
    writeSse({
      type: 'chunk',
      chunk: `\x1b[1;31m${err instanceof Error ? err.message : 'Command failed'}\x1b[0m\n`,
    });
    writeSse({ type: 'done', exitCode: 1 });
    if (!res.writableEnded) {
      res.end();
    }
  }
});

// Issue short-lived WebSocket console ticket
app.post('/api/vps/:id/ws-ticket', requireAuth, (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }
  const ticket = issueWsTicket(id, user);
  res.json({ ticket });
});

// Public SSH Tunnel Start (Pinggy pure ssh2 + bore.pub fallback)
app.post('/api/vps/:id/ssh-tunnel/start', requireAuth, async (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }

  try {
    const updated = await enableVpsPublicSsh(id);
    res.json({ instance: updated });
  } catch (err) {
    res.status(502).json({ error: err instanceof Error ? err.message : 'Failed to start public SSH tunnel' });
  }
});

// Public SSH Tunnel Stop
app.post('/api/vps/:id/ssh-tunnel/stop', requireAuth, async (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }

  try {
    const updated = await disableVpsPublicSsh(id);
    res.json({ instance: updated });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to stop public SSH tunnel' });
  }
});

// Real sshx.io Web Terminal Start
app.post('/api/vps/:id/sshx/start', requireAuth, async (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }

  try {
    const updated = await enableVpsSshx(id);
    res.json({ instance: updated });
  } catch (err) {
    res.status(502).json({ error: err instanceof Error ? err.message : 'Failed to start sshx.io session' });
  }
});

// Real sshx.io Web Terminal Stop
app.post('/api/vps/:id/sshx/stop', requireAuth, (req, res) => {
  const user = req.user!;
  const id = paramId(req.params.id);
  const access = assertVpsAccess(id, user.uid, user.isAdmin, user.email);
  if (!access.ok) {
    res.status(access.status).json({ error: access.error });
    return;
  }

  try {
    const updated = disableVpsSshx(id);
    res.json({ instance: updated });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to stop sshx.io session' });
  }
});

// WebSocket interactive live-streaming console
const wss = new WebSocketServer({ noServer: true, maxPayload: 65536 });

server.on('upgrade', (req, socket, head) => {
  let url:URL;try{url=new URL(req.url || '/', 'http://localhost');}catch{socket.destroy();return;}
  if (url.pathname !== '/ws/terminal') {
    socket.destroy();
    return;
  }

  const vpsId = url.searchParams.get('vpsId') || '';
  const ticket = url.searchParams.get('ticket') || '';
  const ticketEntry = consumeWsTicket(ticket, vpsId);
  if (!ticketEntry) {
    socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
    socket.destroy();
    return;
  }

  const access = assertVpsAccess(vpsId, ticketEntry.uid, ticketEntry.isAdmin, ticketEntry.email);
  if (!access.ok) {
    socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
    socket.destroy();
    return;
  }

  wss.handleUpgrade(req, socket, head, (ws) => {
    wss.emit('connection', ws, access.instance.id, ticketEntry);
  });
});

wss.on('connection', (ws: WebSocket, vpsId: string, ticket: {uid:string;isAdmin:boolean;email:string;version:string}) => {
  const inst = getVpsInstance(vpsId);
  if (!inst) {
    ws.close(1008, 'VPS not found');
    return;
  }
  const osInfo = getOsOption(inst.osId);
  let activeProc: { kill: () => void; writeStdin: (data: string) => void; resize?: (cols:number,rows:number)=>void } | null = null;

  ws.send(
    JSON.stringify({
      type: 'ready',
      data: `\x1b[1;36mKilloraCloud Live Console\x1b[0m — ${osInfo.prettyName} (${inst.hostname})\n`,
    })
  );

  let generation = 0;
  const authorized = () => { try { const a = assertVpsAccess(vpsId,ticket.uid,ticket.isAdmin,ticket.email); return ticket.version === credentialVersion(ticket.uid) && a.ok && (!a.instance.expiresAt || Date.parse(a.instance.expiresAt)>Date.now()); } catch { return false; } };
  const guard = setInterval(()=>{if(!authorized()) {activeProc?.kill(); ws.close(1008,'Access revoked');}},5000); guard.unref();
  ws.on('message', (raw) => {
    try {
      if (!authorized()) { activeProc?.kill(); ws.close(1008,'Access revoked'); return; }
      const msg = JSON.parse(raw.toString('utf8')) as {
        type?: string;
        command?: string;
        data?: string; cols?: number; rows?: number;
      };
      if(msg.type==='resize'){activeProc?.resize?.(Number(msg.cols),Number(msg.rows));return;}
      if(msg.type==='shell'){activeProc?.kill();const current=++generation;activeProc=openInteractive(vpsId,Number(msg.cols),Number(msg.rows),{onChunk:data=>{if(current!==generation)return;if(ws.bufferedAmount>1048576){activeProc?.kill();ws.close(1009);return;}if(ws.readyState===ws.OPEN)ws.send(JSON.stringify({type:'chunk',data}));},onExit:exitCode=>{if(current===generation&&ws.readyState===ws.OPEN)ws.send(JSON.stringify({type:'done',exitCode}));}});return;}
      if (msg.type === 'kill') {
        generation++;
        activeProc?.kill();
        activeProc = null;
        if (ws.readyState === ws.OPEN) {
          ws.send(JSON.stringify({ type: 'chunk', data: '^C\n' }));
          ws.send(JSON.stringify({ type: 'done', exitCode: 130 }));
        }
        return;
      }
      if (msg.type === 'stdin' && typeof msg.data === 'string') {
        activeProc?.writeStdin(msg.data);
        return;
      }
      if (msg.type === 'exec' && typeof msg.command === 'string') {
        activeProc?.kill();
        const current = ++generation;
        activeProc = streamVpsCommand(vpsId, msg.command, {
          onChunk: (chunk) => {
            if (current !== generation) return;
            if (ws.bufferedAmount > 1048576) { activeProc?.kill(); ws.close(1009,'Output overflow'); return; }
            if (ws.readyState === ws.OPEN) {
              ws.send(JSON.stringify({ type: 'chunk', data: chunk }));
            }
          },
          onExit: (exitCode) => {
            if (current !== generation) return;
            activeProc = null;
            if (ws.readyState === ws.OPEN) {
              ws.send(JSON.stringify({ type: 'done', exitCode }));
            }
          },
        });
      }
    } catch (err) {
      if (ws.readyState === ws.OPEN) {
        ws.send(
          JSON.stringify({
            type: 'chunk',
            data: `\x1b[1;31m${err instanceof Error ? err.message : 'Console error'}\x1b[0m\n`,
          })
        );
        ws.send(JSON.stringify({ type: 'done', exitCode: 1 }));
      }
    }
  });

  ws.on('close', () => {
    clearInterval(guard); generation++;
    activeProc?.kill();
    activeProc = null;
  });
});

async function setupFrontendAndStart() {
  await bootstrapExistingNativeVps();
  await enforceExpiry();
  setInterval(()=>void enforceExpiry().catch(console.error), 60000).unref();
  void sampleRuntimeMetrics();
  setInterval(()=>void sampleRuntimeMetrics(),10000).unref();

  const distDir = path.resolve(process.cwd(), 'dist');
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(path.join(distDir, 'index.html'));

  if (isProd) {
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false, allowedHosts: (process.env.KC_VITE_ALLOWED_HOSTS||'').split(',').map(x=>x.trim()).filter(Boolean), fs: {deny:['.env','.env.*','*.{crt,pem,key}','**/.git/**','**/.killoracloud-data/**','**/runners/**']} },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  server.listen(PORT, process.env.KC_BIND_HOST || '127.0.0.1', () => {
    console.log(`KilloraCloud VPS Panel running on http://0.0.0.0:${PORT}`);
    void bootstrapEnvPanelTunnel();
    initDiscordBot();

    // 24/7 internal keep-alive heartbeat loop (works alongside user's external cronjob)
    setInterval(() => {
      void fetch(`http://127.0.0.1:${PORT}/api/ping`).catch(() => {
        // ignore
      });
    }, 25_000);
  });
}

process.on('SIGTERM', () => {
  stopPanelTunnel();
  stopAllPublicSshTunnels();
  stopAllSshxSessions();
  process.exit(0);
});

process.on('SIGINT', () => {
  stopPanelTunnel();
  stopAllPublicSshTunnels();
  stopAllSshxSessions();
  process.exit(0);
});

setupFrontendAndStart().catch((err) => {
  console.error('Failed to start KilloraCloud server:', err);
  process.exit(1);
});
