import React, { useMemo, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import type { SiteSettings } from '../lib/api';

interface ResolvedBackground {
  kind: 'none' | 'image' | 'video' | 'youtube' | 'instagram' | 'facebook' | 'vimeo' | 'website';
  src: string;
}

function isSafeBackgroundSource(raw: string): boolean {
  const s = (raw || '').trim();
  if (!s || /[<>"'`\s]/.test(s)) return false;
  if (/^\/media\/[a-z0-9_-]+\.(png|jpg|gif|webp|avif|mp4|webm|ogv|mov)$/i.test(s)) {
    return true;
  }
  return /^https?:\/\//i.test(s);
}

function extractYouTubeId(url: URL): string | null {
  const host = url.hostname.toLowerCase().replace(/^www\./, '');
  if (host === 'youtu.be') {
    const id = url.pathname.split('/').filter(Boolean)[0];
    return id && /^[A-Za-z0-9_-]{6,20}$/.test(id) ? id : null;
  }
  if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'youtube-nocookie.com') {
    const vParam = url.searchParams.get('v');
    if (vParam && /^[A-Za-z0-9_-]{6,20}$/.test(vParam)) return vParam;
    const parts = url.pathname.split('/').filter(Boolean);
    if (
      parts.length >= 2 &&
      ['shorts', 'embed', 'live', 'v'].includes(parts[0].toLowerCase()) &&
      /^[A-Za-z0-9_-]{6,20}$/.test(parts[1])
    ) {
      return parts[1];
    }
  }
  return null;
}

function extractInstagramEmbed(url: URL): string | null {
  const host = url.hostname.toLowerCase().replace(/^www\./, '');
  if (host !== 'instagram.com' && host !== 'm.instagram.com' && host !== 'instagr.am') {
    return null;
  }
  const parts = url.pathname.split('/').filter(Boolean);
  if (parts.length >= 2 && ['reel', 'reels', 'p', 'tv'].includes(parts[0].toLowerCase())) {
    const type = parts[0].toLowerCase() === 'reels' ? 'reel' : parts[0].toLowerCase();
    const code = parts[1].replace(/[^A-Za-z0-9_-]/g, '');
    if (code) {
      return `https://www.instagram.com/${type}/${code}/embed/`;
    }
  }
  return null;
}

function extractFacebookEmbed(url: URL, rawHref: string): string | null {
  const host = url.hostname.toLowerCase().replace(/^www\./, '');
  if (
    host === 'facebook.com' ||
    host === 'm.facebook.com' ||
    host === 'fb.watch' ||
    host === 'web.facebook.com'
  ) {
    return `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(
      rawHref
    )}&autoplay=true&mute=1&show_text=false&t=0`;
  }
  return null;
}

function extractVimeoId(url: URL): string | null {
  const host = url.hostname.toLowerCase().replace(/^www\./, '');
  if (host === 'vimeo.com' || host === 'player.vimeo.com') {
    const match = url.pathname.match(/\/(?:video\/)?(\d{5,15})/);
    return match?.[1] || null;
  }
  return null;
}

export function resolveBackgroundMedia(settings: SiteSettings): ResolvedBackground & { youtubeId?: string } {
  const raw = (settings.backgroundUrl || '').trim();
  if (!raw || settings.backgroundMode === 'none' || !isSafeBackgroundSource(raw)) {
    return { kind: 'none', src: '' };
  }

  // Local uploaded media
  if (raw.startsWith('/media/')) {
    if (/\.(mp4|webm|ogv|mov)$/i.test(raw)) {
      return { kind: 'video', src: raw };
    }
    return { kind: 'image', src: raw };
  }

  let parsed: URL;
  try {
    parsed = new URL(raw);
  } catch {
    return { kind: 'none', src: '' };
  }

  // Always check YouTube, Instagram, Facebook, and Vimeo URLs FIRST (even if backgroundMode was set to 'video' or 'embed')
  const ytId = extractYouTubeId(parsed);
  if (ytId) {
    // Always start iframe with mute=1&enablejsapi=1 so mobile/desktop browsers never block autoplay;
    // sound is controlled dynamically via YouTube IFrame postMessage API without reloading the iframe.
    return {
      kind: 'youtube',
      youtubeId: ytId,
      src: `https://www.youtube.com/embed/${ytId}?autoplay=1&mute=1&enablejsapi=1&loop=1&playlist=${ytId}&controls=0&showinfo=0&rel=0&modestbranding=1&playsinline=1&iv_load_policy=3`,
    };
  }

  const igEmbed = extractInstagramEmbed(parsed);
  if (igEmbed) {
    return { kind: 'instagram', src: igEmbed };
  }

  const fbEmbed = extractFacebookEmbed(parsed, parsed.toString());
  if (fbEmbed) {
    return { kind: 'facebook', src: fbEmbed };
  }

  const vimeoId = extractVimeoId(parsed);
  if (vimeoId) {
    return {
      kind: 'vimeo',
      src: `https://player.vimeo.com/video/${vimeoId}?background=1&autoplay=1&muted=${
        settings.backgroundMuted ? 1 : 0
      }&loop=1`,
    };
  }

  // Manual override if user explicitly selected image or direct video for a non-social URL
  if (settings.backgroundMode === 'image') {
    return { kind: 'image', src: raw };
  }
  if (settings.backgroundMode === 'video') {
    return { kind: 'video', src: raw };
  }

  const lowerPath = parsed.pathname.toLowerCase();

  // Direct video URL
  if (/\.(mp4|webm|ogv|mov|m4v)(\?|$)/i.test(lowerPath)) {
    return { kind: 'video', src: parsed.toString() };
  }

  // Direct photo / GIF URL
  if (/\.(png|jpe?g|gif|webp|avif|svg|bmp)(\?|$)/i.test(lowerPath)) {
    return { kind: 'image', src: parsed.toString() };
  }

  // Any other website URL
  return { kind: 'website', src: parsed.toString() };
}

export const BackgroundStage: React.FC<{ settings: SiteSettings }> = ({ settings }) => {
  const [localMuted, setLocalMuted] = useState<boolean>(settings.backgroundMuted);
  const ytIframeRef = React.useRef<HTMLIFrameElement | null>(null);
  const videoRef = React.useRef<HTMLVideoElement | null>(null);

  React.useEffect(() => {
    setLocalMuted(settings.backgroundMuted);
  }, [settings.backgroundMuted]);

  const resolved = useMemo(
    () => resolveBackgroundMedia({ ...settings, backgroundMuted: localMuted }),
    [settings, localMuted]
  );

  const sendYouTubeCommand = React.useCallback((func: string, args: unknown[] = []) => {
    const win = ytIframeRef.current?.contentWindow;
    if (!win) return;
    try {
      win.postMessage(JSON.stringify({ event: 'command', func, args }), '*');
    } catch {
      // ignore cross-origin postMessage errors
    }
  }, []);

  const registerYouTubeListeners = React.useCallback(() => {
    const win = ytIframeRef.current?.contentWindow;
    if (!win) return;
    try {
      win.postMessage(JSON.stringify({ event: 'listening', id: 1, channel: 'widget' }), '*');
      win.postMessage(
        JSON.stringify({ event: 'command', func: 'addEventListener', args: ['onStateChange'] }),
        '*'
      );
    } catch {
      // ignore cross-origin postMessage errors
    }
  }, []);

  const syncYouTubeAudio = React.useCallback(
    (muted: boolean) => {
      registerYouTubeListeners();
      sendYouTubeCommand('playVideo');
      if (muted) {
        sendYouTubeCommand('mute');
      } else {
        sendYouTubeCommand('unMute');
        sendYouTubeCommand('setVolume', [100]);
      }
    },
    [registerYouTubeListeners, sendYouTubeCommand]
  );

  // Non-stop 24/7 loop & anti-pause watchdog for YouTube background videos
  React.useEffect(() => {
    if (resolved.kind !== 'youtube') return;
    syncYouTubeAudio(localMuted);

    const handleUserGesture = () => {
      syncYouTubeAudio(localMuted);
    };

    const handleYouTubeMessage = (event: MessageEvent) => {
      if (typeof event.data !== 'string') return;
      try {
        const data = JSON.parse(event.data);
        // YouTube playerState: 0 = ended, 2 = paused, 5 = video cued, -1 = unstarted
        const state =
          data?.event === 'onStateChange'
            ? data?.info
            : data?.event === 'infoDelivery'
              ? data?.info?.playerState
              : undefined;
        if (state === 0) {
          sendYouTubeCommand('seekTo', [0, true]);
          sendYouTubeCommand('playVideo');
        } else if (state === 2 || state === 5 || state === -1) {
          sendYouTubeCommand('playVideo');
        }
      } catch {
        // ignore non-JSON messages
      }
    };

    const handleVisibility = () => {
      if (!document.hidden) {
        sendYouTubeCommand('playVideo');
      }
    };

    // Periodic keep-alive pulse so YouTube never pauses or stops looping
    const keepAliveTimer = window.setInterval(() => {
      registerYouTubeListeners();
      sendYouTubeCommand('playVideo');
    }, 1500);

    window.addEventListener('message', handleYouTubeMessage);
    window.addEventListener('pointerdown', handleUserGesture, { passive: true });
    window.addEventListener('keydown', handleUserGesture, { passive: true });
    window.addEventListener('focus', handleVisibility);
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      window.clearInterval(keepAliveTimer);
      window.removeEventListener('message', handleYouTubeMessage);
      window.removeEventListener('pointerdown', handleUserGesture);
      window.removeEventListener('keydown', handleUserGesture);
      window.removeEventListener('focus', handleVisibility);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [resolved.kind, localMuted, registerYouTubeListeners, sendYouTubeCommand, syncYouTubeAudio]);

  // Non-stop 24/7 loop & anti-pause watchdog for HTML5 <video> backgrounds
  React.useEffect(() => {
    if (resolved.kind !== 'video') return;
    const ensureVideoPlaying = () => {
      const el = videoRef.current;
      if (!el) return;
      el.loop = true;
      if (el.ended) {
        el.currentTime = 0;
      }
      if (el.paused) {
        void el.play().catch(() => {});
      }
    };

    ensureVideoPlaying();
    const timer = window.setInterval(ensureVideoPlaying, 1200);
    window.addEventListener('focus', ensureVideoPlaying);
    window.addEventListener('pointerdown', ensureVideoPlaying, { passive: true });
    document.addEventListener('visibilitychange', ensureVideoPlaying);

    return () => {
      window.clearInterval(timer);
      window.removeEventListener('focus', ensureVideoPlaying);
      window.removeEventListener('pointerdown', ensureVideoPlaying);
      document.removeEventListener('visibilitychange', ensureVideoPlaying);
    };
  }, [resolved.kind, resolved.src]);

  if (resolved.kind === 'none') {
    return null;
  }

  const blurStyle =
    settings.backgroundBlur > 0
      ? { filter: `blur(${settings.backgroundBlur}px)`, transform: 'scale(1.04)' }
      : undefined;
  const dimOpacity = Math.max(0, Math.min(0.85, settings.backgroundDim / 100));

  return (
    <>
      <div
        aria-hidden="true"
        className="fixed inset-0 z-0 overflow-hidden bg-slate-950 pointer-events-none select-none"
      >
        {resolved.kind === 'image' && (
          <img
            src={resolved.src}
            alt=""
            style={blurStyle}
            className="w-full h-full object-cover"
          />
        )}

        {resolved.kind === 'video' && (
          <video
            ref={videoRef}
            key={resolved.src}
            src={resolved.src}
            autoPlay
            loop
            muted={localMuted}
            playsInline
            onPause={(e) => {
              const el = e.currentTarget;
              if (el.ended) el.currentTime = 0;
              void el.play().catch(() => {});
            }}
            onEnded={(e) => {
              const el = e.currentTarget;
              el.currentTime = 0;
              void el.play().catch(() => {});
            }}
            style={blurStyle}
            className="w-full h-full object-cover"
          />
        )}

        {(resolved.kind === 'youtube' || resolved.kind === 'vimeo') && (
          <div
            className="absolute inset-0 overflow-hidden bg-cover bg-center"
            style={{
              ...blurStyle,
              ...(resolved.youtubeId
                ? {
                    backgroundImage: `url(https://i.ytimg.com/vi/${resolved.youtubeId}/hqdefault.jpg)`,
                  }
                : {}),
            }}
          >
            <iframe
              ref={ytIframeRef}
              key={resolved.src}
              src={resolved.src}
              title="Panel background video"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
              referrerPolicy="strict-origin-when-cross-origin"
              onLoad={() => {
                setTimeout(() => syncYouTubeAudio(localMuted), 300);
                setTimeout(() => syncYouTubeAudio(localMuted), 1000);
                setTimeout(() => syncYouTubeAudio(localMuted), 2200);
              }}
              style={{
                width: 'max(100vw, 177.78vh)',
                height: 'max(100vh, 56.25vw)',
              }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 border-0 pointer-events-none"
            />
          </div>
        )}

        {(resolved.kind === 'instagram' ||
          resolved.kind === 'facebook' ||
          resolved.kind === 'website') && (
          <div className="absolute inset-0 overflow-hidden" style={blurStyle}>
            <iframe
              key={resolved.src}
              src={resolved.src}
              title="Panel background media"
              allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
              sandbox="allow-scripts allow-same-origin allow-presentation allow-popups"
              referrerPolicy="strict-origin-when-cross-origin"
              className="w-full h-full border-0 pointer-events-none scale-[1.03]"
            />
          </div>
        )}

        {/* Adjustable dark readability scrim over custom background */}
        <div
          className="absolute inset-0 transition-opacity duration-200"
          style={{ backgroundColor: `rgba(4, 8, 20, ${dimOpacity})` }}
        />
      </div>

      {/* Subtle audio mute/unmute pill for video backgrounds */}
      {(resolved.kind === 'video' || resolved.kind === 'youtube' || resolved.kind === 'vimeo') && (
        <button
          type="button"
          onClick={() => {
            const next = !localMuted;
            setLocalMuted(next);
            syncYouTubeAudio(next);
          }}
          title={localMuted ? 'Unmute background video' : 'Mute background video'}
          className="fixed bottom-4 left-4 z-40 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl glass-card text-[11px] font-medium text-slate-200 hover:text-white cursor-pointer"
        >
          {localMuted ? (
            <>
              <VolumeX className="w-3.5 h-3.5 text-slate-400" />
              <span>BG Muted (Tap for Sound)</span>
            </>
          ) : (
            <>
              <Volume2 className="w-3.5 h-3.5 text-sky-400" />
              <span>BG Sound On</span>
            </>
          )}
        </button>
      )}
    </>
  );
};
