import React, { useMemo, useRef, useState } from 'react';
import {
  Sparkles,
  Image as ImageIcon,
  Film,
  Globe,
  Upload,
  Save,
  RotateCcw,
  Loader2,
  Volume2,
  VolumeX,
  Eye,
  Type,
  Server,
} from 'lucide-react';
import {
  saveSiteSettings,
  uploadBackgroundMedia,
  uploadLogoMedia,
  type BackgroundMediaMode,
  type SiteSettings,
} from '../lib/api';
import { resolveBackgroundMedia } from './BackgroundStage';

interface Props {
  settings: SiteSettings;
  onSettingsChanged: (next: SiteSettings) => void;
  onNotify: (msg: string, tone?: 'info' | 'success' | 'error') => void;
}

const SOURCE_LABELS: Record<ReturnType<typeof resolveBackgroundMedia>['kind'], string> = {
  none: 'Default Deep-Space Grid',
  image: 'Photo / GIF Image',
  video: 'Direct Video (Autoplay Loop)',
  youtube: 'YouTube Video / Shorts',
  instagram: 'Instagram Reel / Post',
  facebook: 'Facebook Video / Reel',
  vimeo: 'Vimeo Video',
  website: 'Live Website Embed',
};

export const PanelSettingsView: React.FC<Props> = ({
  settings,
  onSettingsChanged,
  onNotify,
}) => {
  const [draft, setDraft] = useState<SiteSettings>(settings);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const logoInputRef = useRef<HTMLInputElement | null>(null);

  const detected = useMemo(() => resolveBackgroundMedia(draft), [draft]);

  const updateDraft = (patch: Partial<SiteSettings>) => {
    const next = { ...draft, ...patch };
    setDraft(next);
    // Live preview immediately across the whole panel!
    onSettingsChanged(next);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const saved = await saveSiteSettings(draft);
      setDraft(saved);
      onSettingsChanged(saved);
      onNotify('Hosting name, logo, glass effect & background saved for all users', 'success');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to save settings', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingLogo(true);
    try {
      const res = await uploadLogoMedia(file);
      setDraft(res.settings);
      onSettingsChanged(res.settings);
      onNotify('Hosting logo uploaded and applied across login & panel', 'success');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Logo upload failed', 'error');
    } finally {
      setUploadingLogo(false);
      if (logoInputRef.current) logoInputRef.current.value = '';
    }
  };

  const handleRemoveLogo = async () => {
    setSaving(true);
    try {
      const saved = await saveSiteSettings({ ...draft, logoUrl: '' });
      setDraft(saved);
      onSettingsChanged(saved);
      onNotify('Custom logo removed (reverted to default icon)', 'info');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to remove logo', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleResetBg = async () => {
    setSaving(true);
    try {
      const saved = await saveSiteSettings({
        ...draft,
        backgroundUrl: '',
        backgroundMode: 'none',
        backgroundBlur: 0,
        backgroundDim: 42,
      });
      setDraft(saved);
      onSettingsChanged(saved);
      onNotify('Background reset to default deep-space dark theme', 'info');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Reset failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const res = await uploadBackgroundMedia(file);
      setDraft(res.settings);
      onSettingsChanged(res.settings);
      onNotify(
        `Uploaded ${res.mediaKind === 'video' ? 'video' : 'photo/GIF'} background and applied live`,
        'success'
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Upload failed', 'error');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Panel Branding, Logo, Glass &amp; Background
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Change your hosting name, upload your hosting logo, toggle transparent glass effect ON/OFF, and set any Photo, GIF, Video, YouTube, Instagram, Facebook, or Website URL as your live panel background.
          </p>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-60 text-xs font-semibold text-slate-950 cursor-pointer shrink-0"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Save Changes
        </button>
      </div>

      {/* 1. Hosting Name, Logo & Branding */}
      <div className="glass-panel rounded-2xl p-6 space-y-5">
        <div className="flex items-center gap-2 text-sm font-semibold text-white">
          <Type className="w-4 h-4 text-sky-400" />
          1. Hosting Name, Logo &amp; Tagline
        </div>

        {/* Logo Upload & Preview Bar */}
        <div className="rounded-xl bg-black/30 border border-white/[0.08] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 min-w-0">
            <div className="w-14 h-14 rounded-2xl bg-sky-500/15 border border-sky-400/30 flex items-center justify-center overflow-hidden shrink-0">
              {draft.logoUrl ? (
                <img
                  src={draft.logoUrl}
                  alt={draft.siteName || 'Hosting Logo'}
                  className="w-full h-full object-contain"
                />
              ) : (
                <Server className="w-7 h-7 text-sky-300" />
              )}
            </div>
            <div className="min-w-0 space-y-1">
              <div className="text-xs font-semibold text-white">
                Hosting Logo (Top Header, Menu &amp; Login Page)
              </div>
              <div className="text-[11px] text-slate-400">
                Upload PNG, JPG, GIF, WebP, or paste an image URL below.
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <input
              ref={logoInputRef}
              type="file"
              accept="image/png,image/jpeg,image/gif,image/webp,image/avif"
              onChange={handleLogoUpload}
              className="hidden"
            />
            <button
              type="button"
              disabled={uploadingLogo}
              onClick={() => logoInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-500/15 hover:bg-sky-500/25 border border-sky-400/40 text-xs font-semibold text-sky-200 cursor-pointer disabled:opacity-50"
            >
              {uploadingLogo ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Upload className="w-3.5 h-3.5" />
              )}
              Upload Hosting Logo
            </button>

            {draft.logoUrl && (
              <button
                type="button"
                disabled={saving}
                onClick={() => void handleRemoveLogo()}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/[0.06] hover:bg-rose-500/20 border border-white/10 text-xs text-slate-300 hover:text-rose-200 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Remove Logo
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <label className="space-y-1.5">
            <span className="text-xs text-slate-300">Hosting / Panel Name</span>
            <input
              type="text"
              required
              maxLength={60}
              value={draft.siteName}
              onChange={(e) => updateDraft({ siteName: e.target.value })}
              placeholder="KilloraCloud"
              className="w-full px-3.5 py-2.5 text-sm font-semibold rounded-xl glass-input"
            />
          </label>
          <label className="space-y-1.5">
            <span className="text-xs text-slate-300">Login Page Subtitle / Tagline</span>
            <input
              type="text"
              maxLength={120}
              value={draft.siteTagline}
              onChange={(e) => updateDraft({ siteTagline: e.target.value })}
              placeholder="24/7 Cloud VPS Control Panel"
              className="w-full px-3.5 py-2.5 text-sm rounded-xl glass-input"
            />
          </label>
          <label className="space-y-1.5">
            <span className="text-xs text-slate-300">Logo Image URL (or upload above)</span>
            <input
              type="text"
              value={draft.logoUrl}
              onChange={(e) => updateDraft({ logoUrl: e.target.value })}
              placeholder="https://.../logo.png or uploaded /media/..."
              className="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl glass-input"
            />
          </label>
        </div>
      </div>

      {/* 2. Transparent Glass Effect ON / OFF */}
      <div className="glass-panel rounded-2xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <Sparkles className="w-4 h-4 text-sky-400" />
              2. Transparent Glass Effect
            </div>
            <p className="text-xs text-slate-400">
              Turn Glass Effect ON so all cards, panels, login box, and menu become crystal-clear frosted glass showing your background through them.
            </p>
          </div>

          <button
            type="button"
            onClick={() => updateDraft({ glassEnabled: !draft.glassEnabled })}
            className={`inline-flex items-center gap-2.5 px-4 py-2 rounded-xl border text-xs font-semibold transition-all cursor-pointer shrink-0 ${
              draft.glassEnabled
                ? 'bg-sky-500/20 border-sky-400 text-sky-200'
                : 'bg-white/[0.05] border-white/15 text-slate-300'
            }`}
          >
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                draft.glassEnabled ? 'bg-emerald-400' : 'bg-slate-500'
              }`}
            />
            Glass Effect: {draft.glassEnabled ? 'ON (Transparent)' : 'OFF (Solid)'}
          </button>
        </div>

        {draft.glassEnabled && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2 border-t border-white/[0.08]">
            <label className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Panel Transparency (Lower = More See-Through)</span>
                <span className="font-mono text-sky-300 tabular-nums">{draft.glassOpacity}%</span>
              </div>
              <input
                type="range"
                min={10}
                max={85}
                value={draft.glassOpacity}
                onChange={(e) => updateDraft({ glassOpacity: Number(e.target.value) })}
                className="w-full accent-sky-400 cursor-pointer"
              />
            </label>

            <label className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Frosted Glass Blur Strength</span>
                <span className="font-mono text-sky-300 tabular-nums">{draft.glassBlur}px</span>
              </div>
              <input
                type="range"
                min={4}
                max={32}
                value={draft.glassBlur}
                onChange={(e) => updateDraft({ glassBlur: Number(e.target.value) })}
                className="w-full accent-sky-400 cursor-pointer"
              />
            </label>
          </div>
        )}
      </div>

      {/* 3. Custom Background (Photo / GIF / Video / YouTube / Instagram / Facebook / Website URL) */}
      <div className="glass-panel rounded-2xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <Film className="w-4 h-4 text-emerald-400" />
              3. Custom Background Media (Photo, GIF, Video, YouTube, Instagram, Facebook, Website)
            </div>
            <p className="text-xs text-slate-400">
              Paste any share URL from YouTube, Instagram Reels/Posts, Facebook Video/Reels, Vimeo, direct MP4/WebM video, photo/GIF, or website — or upload a file directly from your device.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/gif,image/webp,image/avif,video/mp4,video/webm,video/quicktime"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              type="button"
              disabled={uploading}
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-400/35 text-xs font-semibold text-emerald-200 cursor-pointer disabled:opacity-50"
            >
              {uploading ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Upload className="w-3.5 h-3.5" />
              )}
              Upload Photo / GIF / Video
            </button>

            {draft.backgroundUrl && (
              <button
                type="button"
                disabled={saving}
                onClick={() => void handleResetBg()}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/[0.06] hover:bg-rose-500/20 border border-white/10 text-xs text-slate-300 hover:text-rose-200 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Remove BG
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
          <label className="md:col-span-9 space-y-1.5">
            <span className="text-xs text-slate-300 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-sky-400" />
              Background URL (YouTube, Instagram, Facebook, Website, Photo, GIF, or MP4)
            </span>
            <input
              type="text"
              value={draft.backgroundUrl}
              onChange={(e) =>
                updateDraft({
                  backgroundUrl: e.target.value,
                  backgroundMode: e.target.value.trim() ? 'auto' : 'none',
                })
              }
              placeholder="https://youtu.be/... or https://instagram.com/reel/... or https://facebook.com/... or .mp4 / .gif / .jpg"
              className="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl glass-input"
            />
          </label>

          <label className="md:col-span-3 space-y-1.5">
            <span className="text-xs text-slate-300">Media Mode</span>
            <select
              value={draft.backgroundMode}
              onChange={(e) =>
                updateDraft({ backgroundMode: e.target.value as BackgroundMediaMode })
              }
              className="w-full px-3 py-2.5 text-xs rounded-xl glass-input"
            >
              <option value="auto" className="bg-slate-950">Auto-Detect URL</option>
              <option value="image" className="bg-slate-950">Force Photo / GIF</option>
              <option value="video" className="bg-slate-950">Force Video (.mp4/.webm)</option>
              <option value="embed" className="bg-slate-950">Force Website / Social Embed</option>
              <option value="none" className="bg-slate-950">Disabled (Default Grid)</option>
            </select>
          </label>
        </div>

        {/* Live Detected Format Bar */}
        <div className="rounded-xl bg-black/35 border border-white/[0.08] px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <Eye className="w-4 h-4 text-sky-400 shrink-0" />
            <span>Detected Background Mode:</span>
            <span className="font-mono font-semibold text-emerald-300">
              {SOURCE_LABELS[detected.kind]}
            </span>
          </div>

          <button
            type="button"
            onClick={() => updateDraft({ backgroundMuted: !draft.backgroundMuted })}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-slate-200 cursor-pointer"
          >
            {draft.backgroundMuted ? (
              <>
                <VolumeX className="w-3.5 h-3.5 text-slate-400" />
                Start Video Muted
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5 text-sky-400" />
                Video Sound Enabled
              </>
            )}
          </button>
        </div>

        {/* Dim & Blur Sliders */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <label className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Dark Overlay Dimming (Keeps Text Readable)</span>
              <span className="font-mono text-sky-300 tabular-nums">{draft.backgroundDim}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={85}
              value={draft.backgroundDim}
              onChange={(e) => updateDraft({ backgroundDim: Number(e.target.value) })}
              className="w-full accent-sky-400 cursor-pointer"
            />
          </label>

          <label className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Background Media Blur</span>
              <span className="font-mono text-sky-300 tabular-nums">{draft.backgroundBlur}px</span>
            </div>
            <input
              type="range"
              min={0}
              max={20}
              value={draft.backgroundBlur}
              onChange={(e) => updateDraft({ backgroundBlur: Number(e.target.value) })}
              className="w-full accent-sky-400 cursor-pointer"
            />
          </label>
        </div>

        <div className="rounded-xl bg-white/[0.03] border border-white/[0.08] p-3.5 text-[11px] text-slate-400 space-y-1">
          <div className="font-semibold text-slate-200 flex items-center gap-1.5">
            <ImageIcon className="w-3.5 h-3.5 text-sky-400" />
            Supported URLs &amp; Uploads:
          </div>
          <p>
            • <span className="text-slate-200">YouTube</span>: <span className="font-mono">youtube.com/watch?v=...</span>, <span className="font-mono">youtu.be/...</span>, <span className="font-mono">youtube.com/shorts/...</span>
          </p>
          <p>
            • <span className="text-slate-200">Instagram &amp; Facebook</span>: <span className="font-mono">instagram.com/reel/...</span>, <span className="font-mono">instagram.com/p/...</span>, <span className="font-mono">facebook.com/reel/...</span>, <span className="font-mono">fb.watch/...</span>
          </p>
          <p>
            • <span className="text-slate-200">Photos, GIFs, Direct Videos &amp; Websites</span>: Any <span className="font-mono">.jpg / .png / .webp / .gif / .mp4 / .webm</span> link, uploaded file (up to 25 MB), or live website URL.
          </p>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          disabled={saving}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-60 text-xs font-bold text-slate-950 cursor-pointer"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Save &amp; Apply Theme Globally
        </button>
      </div>
    </form>
  );
};
