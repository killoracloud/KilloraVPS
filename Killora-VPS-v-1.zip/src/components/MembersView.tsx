import React, { useEffect, useState } from 'react';
import {
  UserPlus,
  Trash2,
  Mail,
  Ban,
  CheckCircle2,
  Loader2,
  KeyRound,
  Copy,
  Check,
  Server,
} from 'lucide-react';
import type { MemberAccount, VpsInstance } from '../types/vps';
import {
  createMember,
  deleteMember,
  fetchMembers,
  updateMember,
} from '../lib/api';

interface Props {
  currentEmail: string;
  instances: VpsInstance[];
  onNotify: (msg: string, tone?: 'info' | 'success' | 'error') => void;
}

export const MembersView: React.FC<Props> = ({ currentEmail, instances, onNotify }) => {
  const [members, setMembers] = useState<MemberAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [maxVps, setMaxVps] = useState(5);
  const [maxVcpu, setMaxVcpu] = useState(32);
  const [maxRamGb, setMaxRamGb] = useState(32);
  const maxRamMb = Math.max(512, Math.round((Number(maxRamGb) || 0.5) * 1024));
  const [maxDiskGb, setMaxDiskGb] = useState(500);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const loadList = async () => {
    try {
      const list = await fetchMembers();
      setMembers(list);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to load members', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadList();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    try {
      const created = await createMember({
        email: email.trim(),
        username: username.trim() || undefined,
        password,
        displayName: displayName.trim() || undefined,
        maxVps,
        maxVcpu,
        maxRamMb,
        maxDiskGb,
      });
      setMembers((prev) => [created, ...prev]);
      onNotify(
        `Member "${created.email}" (@${created.username}) created. You can now assign VPS instances to this Gmail.`,
        'success'
      );
      setEmail('');
      setUsername('');
      setPassword('');
      setDisplayName('');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to create member', 'error');
    } finally {
      setCreating(false);
    }
  };

  const toggleActive = async (m: MemberAccount) => {
    try {
      const updated = await updateMember(m.id, { active: !m.active });
      setMembers((prev) => prev.map((item) => (item.id === m.id ? updated : item)));
      onNotify(
        `${updated.email} is now ${updated.active ? 'active' : 'suspended'}`,
        'info'
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Update failed', 'error');
    }
  };

  const handleDelete = async (m: MemberAccount) => {
    try {
      await deleteMember(m.id);
      setMembers((prev) => prev.filter((item) => item.id !== m.id));
      onNotify(`Removed member "${m.email}"`, 'info');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Delete failed', 'error');
    }
  };

  const copyText = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedKey(value);
      setTimeout(() => setCopiedKey(null), 1500);
    } catch {
      // ignore
    }
  };

  const countMemberVps = (m: MemberAccount) =>
    instances.filter(
      (v) =>
        v.ownerId === m.id ||
        (v.ownerEmail && v.ownerEmail.toLowerCase() === m.email.toLowerCase())
    ).length;

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-white">
          Member Account Creator
        </h1>
        <p className="mt-1 text-xs text-slate-400">
          Create Member Gmail accounts with login passwords &amp; VPS quotas. You can assign VPS instances directly to any Member&apos;s Gmail from the VPS Creator or Dashboard. (Single Admin: {currentEmail})
        </p>
      </div>

      {/* Create Member Gmail Account Form */}
      <form onSubmit={handleCreate} className="glass-panel rounded-2xl p-6 space-y-5">
        <div className="flex items-center gap-2 text-sm font-semibold text-white">
          <UserPlus className="w-4 h-4 text-sky-400" />
          Create Member Gmail Account
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <label className="space-y-1.5">
            <span className="text-xs text-slate-300">Member Gmail *</span>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="member@gmail.com"
              className="w-full px-3.5 py-2 text-xs font-mono rounded-xl glass-input"
            />
          </label>

          <label className="space-y-1.5">
            <span className="text-xs text-slate-300">Username (optional)</span>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Auto from Gmail"
              className="w-full px-3.5 py-2 text-xs font-mono rounded-xl glass-input"
            />
          </label>

          <label className="space-y-1.5">
            <span className="text-xs text-slate-300">Member Password *</span>
            <input
              type="password"
              required
              minLength={4}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Min 4 characters"
              className="w-full px-3.5 py-2 text-xs rounded-xl glass-input"
            />
          </label>

          <label className="space-y-1.5">
            <span className="text-xs text-slate-300">Display Name</span>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Rahul Sharma"
              className="w-full px-3.5 py-2 text-xs rounded-xl glass-input"
            />
          </label>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <label className="space-y-1.5">
            <span className="text-xs text-slate-300">Max VPS Count (Unlimited)</span>
            <input
              type="number"
              min={1}
              value={maxVps}
              onChange={(e) => setMaxVps(Number(e.target.value))}
              className="w-full px-3.5 py-2 text-xs font-mono tabular-nums rounded-xl glass-input"
            />
          </label>
          <label className="space-y-1.5">
            <span className="text-xs text-slate-300">Max vCPU / VPS (Unlimited)</span>
            <input
              type="number"
              min={1}
              value={maxVcpu}
              onChange={(e) => setMaxVcpu(Number(e.target.value))}
              className="w-full px-3.5 py-2 text-xs font-mono tabular-nums rounded-xl glass-input"
            />
          </label>
          <label className="space-y-1.5">
            <span className="text-xs text-slate-300 flex items-center justify-between gap-1">
              <span>Max RAM (GB)</span>
              <span className="text-[11px] font-mono text-emerald-400 tabular-nums">
                = {maxRamMb.toLocaleString()} MB
              </span>
            </span>
            <input
              type="number"
              min={0.5}
              step="any"
              value={maxRamGb}
              onChange={(e) => setMaxRamGb(Number(e.target.value))}
              className="w-full px-3.5 py-2 text-xs font-mono tabular-nums rounded-xl glass-input"
            />
          </label>
          <label className="space-y-1.5">
            <span className="text-xs text-slate-300">Max Disk (GB, Unlimited)</span>
            <input
              type="number"
              min={1}
              value={maxDiskGb}
              onChange={(e) => setMaxDiskGb(Number(e.target.value))}
              className="w-full px-3.5 py-2 text-xs font-mono tabular-nums rounded-xl glass-input"
            />
          </label>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={creating}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-slate-950 cursor-pointer"
          >
            {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
            Create Member Account
          </button>
        </div>
      </form>

      {/* Created Members Directory */}
      <div className="glass-panel rounded-2xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-white/[0.08] flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white">Member Gmail Accounts</h2>
          <span className="text-xs text-slate-400 tabular-nums">{members.length} members</span>
        </div>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-400">Loading member accounts...</div>
        ) : members.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            No member accounts created yet. Create a Member Gmail account above to assign VPS instances to them.
          </div>
        ) : (
          <div className="divide-y divide-white/[0.07]">
            {members.map((m) => {
              const assignedCount = countMemberVps(m);
              return (
                <div
                  key={m.id}
                  className="px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
                >
                  <div className="space-y-1.5 min-w-0">
                    <div className="flex items-center gap-2.5 flex-wrap">
                      <Mail className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                      <button
                        type="button"
                        onClick={() => void copyText(m.email)}
                        className="inline-flex items-center gap-1 font-mono text-sky-300 hover:text-sky-200 font-medium cursor-pointer"
                        title="Copy member Gmail"
                      >
                        {m.email}
                        {copiedKey === m.email ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3 opacity-70" />
                        )}
                      </button>
                      <span className="text-slate-500">·</span>
                      <span className="font-semibold text-white">{m.displayName}</span>
                      <span className="font-mono text-slate-400">(@{m.username})</span>
                      <span className="text-slate-500">·</span>
                      <span className={m.active ? 'text-emerald-400' : 'text-rose-400'}>
                        {m.active ? 'Active' : 'Suspended'}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-3 text-slate-400 font-mono tabular-nums">
                      <span className="inline-flex items-center gap-1 text-emerald-300">
                        <Server className="w-3 h-3" />
                        {assignedCount} Assigned VPS
                      </span>
                      <span>·</span>
                      <span>
                        Quota: {m.maxVps} VPS · {m.maxVcpu} vCPU · {(m.maxRamMb / 1024).toFixed(0)} GB RAM · {m.maxDiskGb} GB NVMe
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => void toggleActive(m)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer ${
                        m.active
                          ? 'border-amber-500/30 text-amber-300 hover:bg-amber-500/15'
                          : 'border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/15'
                      }`}
                    >
                      {m.active ? <Ban className="w-3.5 h-3.5" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                      {m.active ? 'Suspend' : 'Activate'}
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleDelete(m)}
                      className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/15 cursor-pointer"
                      title="Delete member"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
