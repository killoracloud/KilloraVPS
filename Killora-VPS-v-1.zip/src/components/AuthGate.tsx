import React, { useEffect, useState } from 'react';
import {
  User as UserIcon,
  Lock,
  Loader2,
  Server,
  KeyRound,
  Mail,
} from 'lucide-react';
import {
  fetchAuthStatus,
  loginUnified,
  setSessionToken,
  setupFirstRunAdmin,
  type SiteSettings,
} from '../lib/api';
import type { AuthSessionUser } from '../types/vps';

interface Props {
  siteSettings: SiteSettings;
  onCredentialLogin: (user: AuthSessionUser) => void;
}

export const AuthGate: React.FC<Props> = ({ siteSettings, onCredentialLogin }) => {
  const [adminConfigured, setAdminConfigured] = useState(true);
  const [usesEnvPasscode, setUsesEnvPasscode] = useState(false);
  const [statusLoading, setStatusLoading] = useState(true);

  const [identifier, setIdentifier] = useState('');
  const [setupEmail, setSetupEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void fetchAuthStatus()
      .then((status) => {
        setAdminConfigured(status.adminConfigured);
        setUsesEnvPasscode(status.usesEnvPasscode);
        if (!status.adminConfigured && !status.usesEnvPasscode) {
          setIdentifier(status.adminUsername || 'admin');
          setSetupEmail(status.adminEmail || '');
        }
      })
      .catch(() => {
        // default to normal sign-in form
      })
      .finally(() => setStatusLoading(false));
  }, []);

  const needsFirstRunSetup = !statusLoading && !adminConfigured && !usesEnvPasscode;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = needsFirstRunSetup
        ? await setupFirstRunAdmin(identifier, password, setupEmail)
        : await loginUnified(identifier, password);
      setSessionToken(res.token, res.user);
      onCredentialLogin(res.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid username, Gmail, or password');
    } finally {
      setSubmitting(false);
    }
  };

  const hasCustomBg = Boolean(
    siteSettings.backgroundUrl && siteSettings.backgroundMode !== 'none'
  );

  return (
    <div
      className={`min-h-screen text-slate-100 flex items-center justify-center p-5 relative overflow-hidden ${
        hasCustomBg ? 'kc-has-custom-bg' : 'kc-atmosphere'
      }`}
    >
      {/* Soft ambient glass backdrop glow (only when using default dark grid) */}
      {!hasCustomBg && (
        <>
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 -left-24 w-96 h-96 rounded-full bg-sky-500/15 blur-3xl"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -bottom-24 -right-24 w-96 h-96 rounded-full bg-indigo-500/15 blur-3xl"
          />
        </>
      )}

      <div className="relative z-10 max-w-md w-full glass-panel rounded-2xl p-7 space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-sky-500/15 border border-sky-400/30 flex items-center justify-center text-sky-300 overflow-hidden">
            {siteSettings.logoUrl ? (
              <img
                src={siteSettings.logoUrl}
                alt={siteSettings.siteName || 'Hosting Logo'}
                className="w-full h-full object-contain"
              />
            ) : (
              <Server className="w-6 h-6" />
            )}
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            {siteSettings.siteName || 'KilloraCloud'}
          </h1>
          <p className="text-xs text-slate-300">
            {siteSettings.siteTagline || '24/7 Cloud VPS Control Panel'}
          </p>
        </div>

        {error && (
          <div className="rounded-xl bg-rose-950/60 border border-rose-500/40 px-4 py-3 text-xs text-rose-200">
            {error}
          </div>
        )}

        {needsFirstRunSetup && (
          <div className="rounded-xl bg-sky-950/40 border border-sky-500/30 px-4 py-3 text-xs text-sky-200 leading-relaxed">
            First-time Admin setup: Enter your Admin Gmail, Username, and Password below (or configure{' '}
            <span className="font-mono text-white">ADMIN_EMAIL</span>,{' '}
            <span className="font-mono text-white">ADMIN_USERNAME</span>, and{' '}
            <span className="font-mono text-white">ADMIN_PASSWORD</span> in <span className="font-mono text-white">.env</span> / Secrets).
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {needsFirstRunSetup && (
            <label className="block space-y-1.5">
              <span className="text-xs text-slate-300">Admin Gmail</span>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={setupEmail}
                  onChange={(e) => setSetupEmail(e.target.value)}
                  placeholder="youradmin@gmail.com"
                  className="w-full pl-10 pr-3.5 py-2.5 text-sm rounded-xl glass-input"
                />
              </div>
            </label>
          )}

          <label className="block space-y-1.5">
            <span className="text-xs text-slate-300">
              {needsFirstRunSetup ? 'Admin Username' : 'Username or Gmail'}
            </span>
            <div className="relative">
              <UserIcon className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                autoComplete="username"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder={needsFirstRunSetup ? 'admin' : 'Enter username or Gmail'}
                className="w-full pl-10 pr-3.5 py-2.5 text-sm rounded-xl glass-input"
              />
            </div>
          </label>

          <label className="block space-y-1.5">
            <span className="text-xs text-slate-300">
              {needsFirstRunSetup ? 'Create Admin Password (min 6 chars)' : 'Password'}
            </span>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                autoComplete={needsFirstRunSetup ? 'new-password' : 'current-password'}
                minLength={needsFirstRunSetup ? 6 : 1}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full pl-10 pr-3.5 py-2.5 text-sm rounded-xl glass-input"
              />
            </div>
          </label>

          <button
            type="submit"
            disabled={submitting}
            className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-slate-950 text-sm font-semibold transition-colors cursor-pointer"
          >
            {submitting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <KeyRound className="w-4 h-4" />
            )}
            {needsFirstRunSetup ? 'Set Admin & Sign In' : 'Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
};
