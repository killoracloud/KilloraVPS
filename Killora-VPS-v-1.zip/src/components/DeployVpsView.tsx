import React, { useEffect, useMemo, useState } from 'react';
import {
  Loader2,
  Server,
  Cpu,
  HardDrive,
  MemoryStick,
  Lock,
  Search,
  Check,
  Mail,
} from 'lucide-react';
import {
  CPU_MODEL_CATALOG,
  DEFAULT_CPU_MODEL,
  OS_CATALOG,
  type CreateVpsPayload,
  type MemberAccount,
  type OsId,
  type VpsInstance,
} from '../types/vps';
import { createVps, fetchMembers, fetchProvisioningNodes } from '../lib/api';

interface Props {
  isAdmin: boolean;
  onDeployed: (inst: VpsInstance) => void;
  onNotify: (msg: string, tone?: 'info' | 'success' | 'error') => void;
}

export const DeployVpsView: React.FC<Props> = ({ isAdmin, onDeployed, onNotify }) => {
  const [osId, setOsId] = useState<OsId>('ubuntu-24.04');
  const [name, setName] = useState('');
  const [hostname, setHostname] = useState('');
  const [vcpu, setVcpu] = useState(8);
  const [ramGb, setRamGb] = useState(16);
  const ramMb = Math.max(512, Math.round((Number(ramGb) || 0.5) * 1024));
  const [diskGb, setDiskGb] = useState(120);
  const [cpuModel, setCpuModel] = useState(DEFAULT_CPU_MODEL);
  const [cpuVendorFilter, setCpuVendorFilter] = useState<'ALL' | 'AMD' | 'Intel'>('ALL');
  const [cpuSearch, setCpuSearch] = useState('');
  const [rootPassword, setRootPassword] = useState('');
  const [assignToEmail, setAssignToEmail] = useState('');
  const [members, setMembers] = useState<MemberAccount[]>([]);
  const [nodes,setNodes]=useState<string[]>([]);const [node,setNode]=useState('');
  useEffect(()=>{if(isAdmin)void fetchProvisioningNodes().then(n=>{setNodes(n);setNode(n[0]||'');}).catch(()=>{});},[isAdmin]);
  const [deploying, setDeploying] = useState(false);

  useEffect(() => {
    if (!isAdmin) return;
    void fetchMembers()
      .then(setMembers)
      .catch(() => {
        // ignore
      });
  }, [isAdmin]);

  const filteredCpus = useMemo(() => {
    const q = cpuSearch.trim().toLowerCase();
    return CPU_MODEL_CATALOG.filter((item) => {
      if (cpuVendorFilter !== 'ALL' && item.vendor !== cpuVendorFilter) return false;
      if (q) {
        const hay = `${item.model} ${item.series} ${item.arch} ${item.vendor}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [cpuVendorFilter, cpuSearch]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setDeploying(true);
    try {
      const defaultName =
        osId === 'proxmox-9'
          ? 'proxmox9-vps'
          : osId === 'proxmox-8'
            ? 'proxmox8-vps'
            : `${osId.split('-')[0]}-vps`;
      const payload: CreateVpsPayload = {
        name: name.trim() || defaultName,
        hostname: hostname.trim() || undefined,
        osId,
        vcpu,
        ramMb,
        diskGb,
        cpuModel,
        rootPassword: rootPassword.trim() || undefined,
        nodeName: node || undefined,
        assignToEmail: isAdmin && assignToEmail.trim() ? assignToEmail.trim() : undefined,
      };
      const created = await createVps(payload);
      onNotify(
        payload.assignToEmail
          ? `Deployed ${created.name} and assigned to ${payload.assignToEmail}`
          : `Deployed ${created.name} (${created.cpuModel})`,
        'success'
      );
      onDeployed(created);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Deployment failed', 'error');
    } finally {
      setDeploying(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-white">VPS Creator</h1>
        <p className="mt-1 text-xs text-slate-400">
          Choose Ubuntu, Debian, or Proxmox VE 8/9, select from 29 AMD EPYC, Ryzen, Intel Xeon &amp; Core processors, and set custom vCPU, RAM, and NVMe disk specs.
        </p>
      </div>

      {isAdmin && <label>Provisioning node <select value={node} onChange={e=>setNode(e.target.value)} className="glass-input p-2">{nodes.map(n=><option key={n}>{n}</option>)}</select></label>}
      {/* Operating System Selector */}
      <div className="glass-panel rounded-2xl p-5 space-y-3.5">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white">1. Select Operating System</h2>
          <span className="text-xs text-slate-400">Includes Proxmox VE 8 &amp; 9 (Real X-logo screenfetch)</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {OS_CATALOG.map((item) => {
            const active = osId === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setOsId(item.id)}
                className={`text-left p-4 rounded-xl border transition-all cursor-pointer ${
                  active
                    ? 'bg-sky-500/15 border-sky-400 text-white shadow-[0_0_24px_rgba(56,189,248,0.16)]'
                    : 'bg-black/30 border-white/[0.08] hover:border-white/20 text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-semibold">{item.label}</span>
                  <span
                    className={`text-[11px] font-mono ${
                      item.family === 'proxmox' ? 'text-orange-400' : 'text-sky-300'
                    }`}
                  >
                    {item.codename}
                  </span>
                </div>
                <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">
                  {item.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* 29-Processor Enterprise & High-Clock Catalog */}
      <div className="glass-panel rounded-2xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-white">
              2. Select Processor ({CPU_MODEL_CATALOG.length} Models Available)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Selected: <span className="text-sky-300 font-mono">{cpuModel}</span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-black/40 rounded-xl border border-white/[0.08]">
              {(['ALL', 'AMD', 'Intel'] as const).map((vendor) => (
                <button
                  key={vendor}
                  type="button"
                  onClick={() => setCpuVendorFilter(vendor)}
                  className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    cpuVendorFilter === vendor
                      ? 'bg-sky-500 text-slate-950 font-semibold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {vendor === 'ALL' ? 'All CPUs' : vendor}
                </button>
              ))}
            </div>

            <div className="relative w-52">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={cpuSearch}
                onChange={(e) => setCpuSearch(e.target.value)}
                placeholder="Search EPYC, Ryzen, Xeon..."
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl glass-input"
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-72 overflow-y-auto pr-1">
          {filteredCpus.map((cpu) => {
            const selected = cpuModel === cpu.model;
            return (
              <button
                key={cpu.model}
                type="button"
                onClick={() => setCpuModel(cpu.model)}
                className={`text-left p-3 rounded-xl border transition-all cursor-pointer ${
                  selected
                    ? 'bg-sky-500/18 border-sky-400 text-white'
                    : 'bg-black/30 border-white/[0.07] hover:border-white/20 text-slate-200'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-xs font-semibold leading-snug">{cpu.model}</span>
                  {selected && <Check className="w-4 h-4 text-sky-400 shrink-0" />}
                </div>
                <div className="mt-1.5 flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                  <span className={cpu.vendor === 'AMD' ? 'text-orange-300' : 'text-sky-300'}>
                    {cpu.series}
                  </span>
                  <span>·</span>
                  <span>{cpu.arch}</span>
                  <span>·</span>
                  <span>{cpu.clockHint}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Hardware Allocation & Identity */}
      <div className="glass-panel rounded-2xl p-5 space-y-5">
        <h2 className="text-sm font-semibold text-white">3. Hardware Resources &amp; Credentials</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="space-y-1.5">
            <span className="text-xs text-slate-300 flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-sky-400" />
              VPS Name
            </span>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="killora-prod-01"
              className="w-full px-3.5 py-2.5 text-sm rounded-xl glass-input"
            />
          </label>

          <label className="space-y-1.5">
            <span className="text-xs text-slate-300">Hostname (optional)</span>
            <input
              type="text"
              value={hostname}
              onChange={(e) => setHostname(e.target.value)}
              placeholder="node01.killoracloud.internal"
              className="w-full px-3.5 py-2.5 text-sm font-mono rounded-xl glass-input"
            />
          </label>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <label className="space-y-1.5">
            <span className="text-xs text-slate-300 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-sky-400" />
              vCPU Cores (Unlimited)
            </span>
            <input
              type="number"
              min={1}
              value={vcpu}
              onChange={(e) => setVcpu(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 text-sm font-mono tabular-nums rounded-xl glass-input"
            />
          </label>

          <label className="space-y-1.5">
            <span className="text-xs text-slate-300 flex items-center justify-between gap-1.5">
              <span className="flex items-center gap-1.5">
                <MemoryStick className="w-3.5 h-3.5 text-emerald-400" />
                RAM in GB (Auto → MB, Unlimited)
              </span>
              <span className="text-[11px] font-mono text-emerald-400 tabular-nums">
                = {ramMb.toLocaleString()} MB
              </span>
            </span>
            <input
              type="number"
              min={0.5}
              step="any"
              value={ramGb}
              onChange={(e) => setRamGb(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 text-sm font-mono tabular-nums rounded-xl glass-input"
            />
          </label>

          <label className="space-y-1.5">
            <span className="text-xs text-slate-300 flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-indigo-400" />
              NVMe Disk in GB (Unlimited)
            </span>
            <input
              type="number"
              min={1}
              value={diskGb}
              onChange={(e) => setDiskGb(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 text-sm font-mono tabular-nums rounded-xl glass-input"
            />
          </label>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="block space-y-1.5">
            <span className="text-xs text-slate-300 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-sky-400" />
              Root Password (leave blank to auto-generate)
            </span>
            <input
              type="password"
              value={rootPassword}
              onChange={(e) => setRootPassword(e.target.value)}
              placeholder="Auto-generated secure root password"
              className="w-full px-3.5 py-2.5 text-sm rounded-xl glass-input"
            />
          </label>

          {isAdmin && (
            <label className="block space-y-1.5">
              <span className="text-xs text-slate-300 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-emerald-400" />
                Assign VPS to Member Gmail (Optional)
              </span>
              {members.length > 0 ? (
                <select
                  value={assignToEmail}
                  onChange={(e) => setAssignToEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl glass-input"
                >
                  <option value="" className="bg-slate-950">
                    Keep in Admin Account
                  </option>
                  {members.map((m) => (
                    <option key={m.id} value={m.email} className="bg-slate-950">
                      {m.email} ({m.displayName})
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type="email"
                  value={assignToEmail}
                  onChange={(e) => setAssignToEmail(e.target.value)}
                  placeholder="Leave blank for Admin, or enter member@gmail.com"
                  className="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl glass-input"
                />
              )}
            </label>
          )}
        </div>
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          disabled={deploying}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-slate-950 text-sm font-bold transition-colors cursor-pointer"
        >
          {deploying ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Creating VPS...
            </>
          ) : (
            'Create & Launch VPS'
          )}
        </button>
      </div>
    </form>
  );
};
