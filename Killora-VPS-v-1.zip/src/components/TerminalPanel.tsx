import { InteractiveConsole } from './InteractiveConsole';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Terminal as TerminalIcon,
  Send,
  Copy,
  Check,
  Globe,
  Loader2,
  Eye,
  EyeOff,
  Trash2,
  Play,
  Square,
  OctagonX,
} from 'lucide-react';
import { getOsOption, type VpsInstance } from '../types/vps';
import {
  getSessionToken,
  requestWsTicket,
  startSshTunnel,
  stopSshTunnel,
} from '../lib/api';
import { auth } from '../lib/firebase';

interface Props {
  instance: VpsInstance | null;
  allInstances: VpsInstance[];
  onSelectInstance: (vpsId: string) => void;
  onInstanceUpdated: (inst: VpsInstance) => void;
  onNotify: (msg: string, tone?: 'info' | 'success' | 'error') => void;
}

interface AnsiSpan {
  text: string;
  color?: string;
  bgColor?: string;
  bold?: boolean;
}

const ANSI_256_MAP: Record<number, string> = {
  1: '#EF4444',
  2: '#10B981',
  3: '#F59E0B',
  4: '#3B82F6',
  5: '#A855F7',
  6: '#06B6D4',
  7: '#F8FAFC',
  8: '#64748B',
  9: '#F87171',
  15: '#FFFFFF',
  160: '#DC2626',
  196: '#FF2E2E',
  202: '#E95420', // Official Canonical Ubuntu Orange
  208: '#FF7A00', // Official Proxmox VE Orange
  214: '#F59E0B',
  231: '#FFFFFF',
  240: '#64748B',
  244: '#94A3B8',
};

const ANSI_BASIC_MAP: Record<number, string> = {
  30: '#334155',
  31: '#EF4444',
  32: '#10B981',
  33: '#F59E0B',
  34: '#3B82F6',
  35: '#A855F7',
  36: '#06B6D4',
  37: '#F8FAFC',
  90: '#64748B',
  91: '#F87171',
  92: '#34D399',
  93: '#FBBF24',
  94: '#60A5FA',
  95: '#C084FC',
  96: '#22D3EE',
  97: '#FFFFFF',
};

const ANSI_BG_MAP: Record<number, string> = {
  40: '#1E293B',
  41: '#EF4444',
  42: '#10B981',
  43: '#F59E0B',
  44: '#3B82F6',
  45: '#A855F7',
  46: '#06B6D4',
  47: '#E2E8F0',
  100: '#475569',
  101: '#F87171',
  102: '#34D399',
  103: '#FBBF24',
  104: '#60A5FA',
  105: '#C084FC',
  106: '#22D3EE',
  107: '#FFFFFF',
};

function parseAnsiLine(rawLine: string): AnsiSpan[] {
  const line = rawLine.replace(/\x1b\[\?[0-9;]*[a-zA-Z]/g, '');
  const spans: AnsiSpan[] = [];
  const regex = /\x1b\[([0-9;]*)m/g;
  let lastIndex = 0;
  let currentColor: string | undefined;
  let currentBgColor: string | undefined;
  let currentBold = false;

  let match: RegExpExecArray | null;
  while ((match = regex.exec(line)) !== null) {
    if (match.index > lastIndex) {
      spans.push({
        text: line.slice(lastIndex, match.index),
        color: currentColor,
        bgColor: currentBgColor,
        bold: currentBold,
      });
    }
    const codes = match[1].split(';').map((n) => parseInt(n || '0', 10));
    for (let i = 0; i < codes.length; i++) {
      const code = codes[i];
      if (code === 0) {
        currentColor = undefined;
        currentBgColor = undefined;
        currentBold = false;
      } else if (code === 1) {
        currentBold = true;
      } else if (code === 22) {
        currentBold = false;
      } else if (code === 39) {
        currentColor = undefined;
      } else if (code === 49) {
        currentBgColor = undefined;
      } else if (code === 38 && codes[i + 1] === 5 && typeof codes[i + 2] === 'number') {
        const idx = codes[i + 2];
        currentColor = ANSI_256_MAP[idx] || '#E95420';
        i += 2;
      } else if (code === 48 && codes[i + 1] === 5 && typeof codes[i + 2] === 'number') {
        const idx = codes[i + 2];
        currentBgColor = ANSI_256_MAP[idx] || '#334155';
        i += 2;
      } else if (ANSI_BASIC_MAP[code]) {
        currentColor = ANSI_BASIC_MAP[code];
      } else if (ANSI_BG_MAP[code]) {
        currentBgColor = ANSI_BG_MAP[code];
      }
    }
    lastIndex = regex.lastIndex;
  }

  if (lastIndex < line.length) {
    spans.push({
      text: line.slice(lastIndex),
      color: currentColor,
      bgColor: currentBgColor,
      bold: currentBold,
    });
  }

  return spans.length > 0 ? spans : [{ text: ' ' }];
}

export const TerminalPanel: React.FC<Props> = ({
  instance,
  allInstances,
  onSelectInstance,
  onInstanceUpdated,
  onNotify,
}) => {
  const [command, setCommand] = useState('');
  const [running, setRunning] = useState(false);
  const [wsConnected, setWsConnected] = useState(false);
  const [tunnelBusy, setTunnelBusy] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [history, setHistory] = useState<string[]>([]);
  const [historyIdx, setHistoryIdx] = useState(-1);
  const [rawText, setRawText] = useState('');

  const outputRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const appendOutput = useCallback((chunk: string) => {
    setRawText((prev) => {
      const normalized = chunk.replace(/\r\n/g, '\n');
      let buf = prev;
      for (let i = 0; i < normalized.length; i++) {
        const ch = normalized[i];
        if (ch === '\r') {
          // Carriage return without newline: overwrite current line (for apt/dpkg/curl live progress bars)
          const lastNl = buf.lastIndexOf('\n');
          buf = lastNl === -1 ? '' : buf.slice(0, lastNl + 1);
        } else {
          buf += ch;
        }
      }
      // Keep last 45,000 chars for fast rendering during long live streams
      return buf.length > 45000 ? buf.slice(-45000) : buf;
    });
  }, []);

  // Connect real-time WebSocket stream whenever instance changes (with automatic reconnect)
  useEffect(() => {
    if (!instance) {
      setRawText('');
      return;
    }

    let cancelled = false;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
    const osInfo = getOsOption(instance.osId);
    setRawText(
      `\x1b[1;36mKilloraCloud Live Stream Console\x1b[0m — ${instance.hostname} (${osInfo.prettyName})\n` +
        `Connected to /dev/pts/0 — all commands stream live in real time.\n\n`
    );

    const connectWs = async () => {
      if (cancelled) return;
      try {
        const ticket = await requestWsTicket(instance.id);
        if (cancelled) return;
        const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${proto}//${window.location.host}/ws/terminal?vpsId=${encodeURIComponent(
          instance.id
        )}&ticket=${encodeURIComponent(ticket)}`;
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          if (!cancelled) setWsConnected(true);
        };
        ws.onmessage = (event) => {
          try {
            const msg = JSON.parse(String(event.data)) as {
              type?: string;
              data?: string;
            };
            if (msg.type === 'chunk' && typeof msg.data === 'string') {
              appendOutput(msg.data);
            } else if (msg.type === 'done') {
              setRunning(false);
            }
          } catch {
            // ignore non-json message
          }
        };
        ws.onclose = () => {
          if (!cancelled) {
            setWsConnected(false);
            setRunning(false);
            reconnectTimer = setTimeout(() => {
              void connectWs();
            }, 1500);
          }
        };
        ws.onerror = () => {
          if (!cancelled) setWsConnected(false);
        };
      } catch {
        if (!cancelled) {
          setWsConnected(false);
          reconnectTimer = setTimeout(() => {
            void connectWs();
          }, 2500);
        }
      }
    };

    void connectWs();

    return () => {
      cancelled = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      abortRef.current?.abort();
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      setWsConnected(false);
      setRunning(false);
    };
  }, [instance?.id, appendOutput]);

  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [rawText]);

  const copyText = async (text: string, key: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 1800);
    } catch {
      onNotify('Could not copy to clipboard', 'error');
    }
  };

  const stopRunningCommand = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'kill' }));
    }
    if (abortRef.current) {
      abortRef.current.abort();
      abortRef.current = null;
      appendOutput('^C\n');
    }
    setRunning(false);
  };

  const runLiveHttpStream = async (vpsId: string, trimmed: string) => {
    const controller = new AbortController();
    abortRef.current = controller;

    let token = getSessionToken();
    if (!token && auth.currentUser) {
      token = await auth.currentUser.getIdToken();
    }

    const res = await fetch(`/api/vps/${vpsId}/exec-stream`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/event-stream',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ command: trimmed }),
      signal: controller.signal,
    });

    if (!res.ok || !res.body) {
      const errData = await res.json().catch(() => ({}));
      throw new Error((errData as { error?: string }).error || `Stream failed (${res.status})`);
    }

    const contentType = res.headers.get('content-type') || '';
    const isSse = contentType.includes('text/event-stream');

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let sseBuffer = '';

    const processSseLine = (line: string) => {
      if (!line.startsWith('data:')) return;
      const jsonStr = line.slice(5).trim();
      if (!jsonStr) return;
      try {
        const parsed = JSON.parse(jsonStr) as { type?: string; chunk?: string };
        if (parsed.type === 'chunk' && typeof parsed.chunk === 'string') {
          appendOutput(parsed.chunk);
        }
      } catch {
        // ignore partial line
      }
    };

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      if (value) {
        const decoded = decoder.decode(value, { stream: true });
        if (isSse) {
          sseBuffer += decoded;
          let nlIdx: number;
          while ((nlIdx = sseBuffer.indexOf('\n')) !== -1) {
            const line = sseBuffer.slice(0, nlIdx).trim();
            sseBuffer = sseBuffer.slice(nlIdx + 1);
            if (line) processSseLine(line);
          }
        } else {
          appendOutput(decoded);
        }
      }
    }
    const tail = decoder.decode();
    if (tail) {
      if (isSse) {
        sseBuffer += tail;
        for (const line of sseBuffer.split('\n')) {
          if (line.trim()) processSseLine(line.trim());
        }
      } else {
        appendOutput(tail);
      }
    }
  };

  const runCommand = async (rawCmd: string) => {
    if (!instance) return;
    const trimmed = rawCmd.trim();
    if (!trimmed) return;

    if (trimmed === 'clear') {
      setRawText('');
      setCommand('');
      return;
    }

    setCommand('');
    setHistory((prev) => [trimmed, ...prev.slice(0, 49)]);
    setHistoryIdx(-1);
    appendOutput(
      `\x1b[1;32mroot@${instance.hostname}\x1b[0m:\x1b[1;34m~\x1b[0m# ${trimmed}\n`
    );
    setRunning(true);

    // Wait briefly if WebSocket is in the middle of handshake
    if (wsRef.current && wsRef.current.readyState === WebSocket.CONNECTING) {
      await new Promise<void>((resolve) => {
        const timer = setTimeout(resolve, 300);
        wsRef.current?.addEventListener(
          'open',
          () => {
            clearTimeout(timer);
            resolve();
          },
          { once: true }
        );
      });
    }

    // Primary path: ultra-fast live WebSocket stream (0 HTTP handshake overhead!)
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'exec', command: trimmed }));
      return;
    }

    // Fallback path: unbuffered Server-Sent Events (SSE) stream (flushes every line live through Cloud Run proxy!)
    try {
      await runLiveHttpStream(instance.id, trimmed);
    } catch (err) {
      if ((err as Error)?.name !== 'AbortError') {
        appendOutput(
          `\x1b[1;31mError:\x1b[0m ${err instanceof Error ? err.message : 'Command failed'}\n`
        );
      }
    } finally {
      abortRef.current = null;
      setRunning(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.ctrlKey && e.key.toLowerCase() === 'c' && running) {
      e.preventDefault();
      stopRunningCommand();
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      void runCommand(command);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (history.length > 0) {
        const nextIdx = Math.min(history.length - 1, historyIdx + 1);
        setHistoryIdx(nextIdx);
        setCommand(history[nextIdx]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIdx <= 0) {
        setHistoryIdx(-1);
        setCommand('');
      } else {
        const nextIdx = historyIdx - 1;
        setHistoryIdx(nextIdx);
        setCommand(history[nextIdx]);
      }
    }
  };

  const togglePublicSsh = async () => {
    if (!instance) return;
    setTunnelBusy(true);
    try {
      const updated = instance.publicSsh?.active
        ? await stopSshTunnel(instance.id)
        : await startSshTunnel(instance.id);
      onInstanceUpdated(updated);
      if (updated.publicSsh?.active) {
        onNotify(
          `Public SSH ready (${updated.publicSsh.provider}): ${updated.publicSsh.command}`,
          'success'
        );
      } else {
        onNotify('Public SSH tunnel closed', 'info');
      }
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Failed to toggle Public SSH tunnel',
        'error'
      );
    } finally {
      setTunnelBusy(false);
    }
  };

  if (!instance) {
    return (
      <div className="glass-panel rounded-2xl p-10 text-center space-y-2">
        <TerminalIcon className="w-7 h-7 text-slate-400 mx-auto" />
        <p className="text-sm font-semibold text-white">No VPS Selected</p>
        <p className="text-xs text-slate-400">
          Create a VPS instance first to open the live streaming console and Public SSH tunnel.
        </p>
      </div>
    );
  }

  const osInfo = getOsOption(instance.osId);
  const quickCommands =
    osInfo.family === 'proxmox'
      ? ['screenfetch', 'pveversion', 'cat /etc/os-release', 'lscpu', 'free -h', 'df -h', 'uname -a']
      : ['screenfetch', 'cat /etc/os-release', 'lscpu', 'free -h', 'df -h', 'uname -a'];

  const lines = rawText.split('\n');

  return (
    <div className="space-y-4 w-full max-w-full overflow-x-hidden">
      <InteractiveConsole id={instance.id} key={instance.id}/>
      <div className="glass-panel rounded-2xl p-3.5 sm:p-4 space-y-3.5 w-full max-w-full overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2.5 min-w-0">
            <select
              value={instance.id}
              onChange={(e) => onSelectInstance(e.target.value)}
              className="max-w-full px-3 py-2 text-xs font-medium rounded-xl glass-input truncate"
            >
              {allInstances.map((v) => (
                <option key={v.id} value={v.id} className="bg-slate-950 text-white">
                  {v.name} ({getOsOption(v.osId).label})
                </option>
              ))}
            </select>

            <div className="text-xs text-slate-300 flex flex-wrap items-center gap-2 font-mono min-w-0">
              <span>{instance.ipAddress}</span>
              <span aria-hidden="true">·</span>
              <span className={wsConnected ? 'text-emerald-400' : 'text-sky-400'}>
                {wsConnected ? 'Live WS Stream' : 'Live HTTP Stream'}
              </span>
            </div>
          </div>

          <button
            type="button"
            disabled={tunnelBusy || instance.status !== 'running'}
            onClick={togglePublicSsh}
            className={`w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer disabled:opacity-50 shrink-0 ${
              instance.publicSsh?.active
                ? 'bg-rose-500/20 border border-rose-500/40 text-rose-200 hover:bg-rose-500/30'
                : 'bg-sky-500 hover:bg-sky-400 text-slate-950'
            }`}
          >
            {tunnelBusy ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : instance.publicSsh?.active ? (
              <Square className="w-3.5 h-3.5" />
            ) : (
              <Play className="w-3.5 h-3.5" />
            )}
            {instance.publicSsh?.active ? 'Stop Public SSH' : 'Generate Public SSH'}
          </button>
        </div>

        {/* Root Password Bar — Always fits on Phone Screen */}
        <div className="rounded-xl bg-black/40 border border-white/10 px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-slate-400 shrink-0">Root Pass:</span>
            <span className="text-white break-all">
              {showPassword ? instance.rootPassword : '••••••••••••'}
            </span>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/[0.07] hover:bg-white/[0.14] text-slate-200 cursor-pointer"
              title={showPassword ? 'Hide password' : 'Show password'}
            >
              {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span>{showPassword ? 'Hide' : 'Show'}</span>
            </button>
            <button
              type="button"
              onClick={() => copyText(instance.rootPassword, 'pass')}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 border border-sky-400/30 text-sky-200 font-semibold cursor-pointer"
              title="Copy root password"
            >
              {copiedKey === 'pass' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Pass</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Active Public SSH Box — Full Width, Wrapped & Mobile-Safe Copy Button */}
        {instance.publicSsh?.active && (
          <div className="rounded-xl bg-emerald-950/35 border border-emerald-400/40 p-3 space-y-2.5 w-full max-w-full overflow-hidden">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-300">
                <Globe className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Public SSH Command ({instance.publicSsh.provider})</span>
              </div>
              <span className="text-[11px] font-mono text-emerald-300/80">
                Port: {instance.publicSsh.port}
              </span>
            </div>

            <div className="rounded-lg bg-black/65 border border-white/10 px-3 py-2 font-mono text-xs text-emerald-200 break-all select-all">
              {instance.publicSsh.command}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => copyText(instance.publicSsh!.command, 'ssh')}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold cursor-pointer"
              >
                {copiedKey === 'ssh' ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>SSH Command Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy SSH Command</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => copyText(instance.rootPassword, 'ssh-pass')}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-slate-100 text-xs font-semibold cursor-pointer"
              >
                {copiedKey === 'ssh-pass' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Password Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Password</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Quick Command Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          {quickCommands.map((cmd) => (
            <button
              key={cmd}
              type="button"
              disabled={running || instance.status !== 'running'}
              onClick={() => void runCommand(cmd)}
              className="px-3 py-1.5 text-xs font-mono rounded-lg bg-white/[0.06] border border-white/10 hover:border-sky-400/50 hover:text-sky-300 text-slate-200 transition-colors disabled:opacity-40 cursor-pointer"
            >
              {cmd}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => setRawText('')}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-400 hover:text-white cursor-pointer"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Clear
        </button>
      </div>

      {/* Live Streaming Glass ANSI Terminal */}
      <div className="bg-black/75 backdrop-blur-xl border border-white/12 rounded-2xl overflow-hidden flex flex-col h-[500px] shadow-2xl">
        <div
          ref={outputRef}
          className="flex-1 overflow-y-auto p-4 font-mono text-[13px] leading-relaxed text-slate-100 whitespace-pre"
        >
          {lines.map((line, i) => (
            <div key={i} className="min-h-[1.2rem]">
              {parseAnsiLine(line).map((span, j) => (
                <span
                  key={j}
                  style={{
                    color: span.color,
                    backgroundColor: span.bgColor,
                    fontWeight: span.bold ? 600 : 400,
                  }}
                >
                  {span.text}
                </span>
              ))}
            </div>
          ))}
        </div>

        <div className="border-t border-white/10 bg-black/50 px-3 sm:px-4 py-2.5 sm:py-3 flex items-center gap-2">
          <span className="font-mono text-xs text-emerald-400 shrink-0 hidden sm:inline">
            root@{instance.hostname}:~#
          </span>
          <span className="font-mono text-xs text-emerald-400 shrink-0 sm:hidden">
            #
          </span>
          <input
            type="text"
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={instance.status !== 'running'}
            placeholder={
              running
                ? 'Running live... tap Stop to cancel'
                : instance.status === 'running'
                  ? 'Type command (e.g. neofetch, apt update)...'
                  : 'Start this VPS to run commands'
            }
            className="flex-1 min-w-0 bg-transparent font-mono text-xs text-white placeholder:text-slate-500 focus:outline-none"
          />
          {running ? (
            <button
              type="button"
              onClick={stopRunningCommand}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-500/20 border border-rose-500/50 hover:bg-rose-500/35 text-rose-200 text-xs font-semibold transition-colors cursor-pointer shrink-0"
            >
              <OctagonX className="w-3.5 h-3.5" />
              <span>Stop</span>
            </button>
          ) : (
            <button
              type="button"
              disabled={!command.trim() || instance.status !== 'running'}
              onClick={() => void runCommand(command)}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-400 disabled:opacity-40 text-slate-950 text-xs font-semibold transition-colors cursor-pointer shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Run</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
