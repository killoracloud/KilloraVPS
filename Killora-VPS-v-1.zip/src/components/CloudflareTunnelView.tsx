import React, { useCallback, useEffect, useState } from 'react';
import {
  Globe,
  Link2,
  Power,
  Copy,
  Check,
  ExternalLink,
  Loader2,
  ShieldCheck,
  Zap,
  Terminal,
  RefreshCw,
  KeyRound,
} from 'lucide-react';
import {
  fetchPanelTunnelStatus,
  startPanelCloudflareTunnel,
  stopPanelCloudflareTunnel,
  type PanelTunnelStatus,
} from '../lib/api';

interface Props {
  isAdmin: boolean;
  onNotify: (msg: string, tone?: 'info' | 'success' | 'error') => void;
}

function isSafeHttpUrl(url: string | null | undefined): url is string {
  if (!url) return false;
  return /^https?:\/\/[^\s"'<>]+$/i.test(url);
}

export const CloudflareTunnelView: React.FC<Props> = ({ isAdmin, onNotify }) => {
  const [tunnel, setTunnel] = useState<PanelTunnelStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [busyMode, setBusyMode] = useState<'token' | 'quick' | 'stop' | null>(null);
  const [customUrl, setCustomUrl] = useState('');
  const [tunnelToken, setTunnelToken] = useState('');
  const [copiedUrl, setCopiedUrl] = useState(false);

  const loadStatus = useCallback(async (syncCustomInput = false) => {
    try {
      const data = await fetchPanelTunnelStatus();
      setTunnel(data);
      if (syncCustomInput && data.customUrl) {
        setCustomUrl(data.customUrl);
      }
    } catch {
      // ignore transient polling error
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadStatus(true);
    const id = window.setInterval(() => {
      void loadStatus(false);
    }, 3000);
    return () => window.clearInterval(id);
  }, [loadStatus]);

  const handleConnectCustom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    if (!tunnelToken.trim() && !tunnel?.usesEnvToken) {
      onNotify('Paste your Cloudflare Tunnel Token from Zero Trust Dashboard', 'error');
      return;
    }
    setBusyMode('token');
    try {
      const updated = await startPanelCloudflareTunnel({
        mode: 'token',
        token: tunnelToken.trim() || undefined,
        customUrl: customUrl.trim(),
      });
      setTunnel(updated);
      setTunnelToken('');
      onNotify(
        updated.publicUrl
          ? `Panel connected to ${updated.publicUrl}`
          : 'Cloudflare custom domain tunnel connected',
        'success'
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to connect Cloudflare Tunnel', 'error');
      void loadStatus(false);
    } finally {
      setBusyMode(null);
    }
  };

  const handleStartQuickTunnel = async () => {
    if (!isAdmin) return;
    setBusyMode('quick');
    try {
      const updated = await startPanelCloudflareTunnel({ mode: 'quick' });
      setTunnel(updated);
      onNotify(
        updated.publicUrl
          ? `Instant panel URL ready: ${updated.publicUrl}`
          : 'Quick Cloudflare Tunnel started',
        'success'
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to start Quick Tunnel', 'error');
      void loadStatus(false);
    } finally {
      setBusyMode(null);
    }
  };

  const handleStop = async () => {
    if (!isAdmin) return;
    setBusyMode('stop');
    try {
      const updated = await stopPanelCloudflareTunnel();
      setTunnel(updated);
      onNotify('Panel Cloudflare Tunnel stopped', 'info');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to stop tunnel', 'error');
    } finally {
      setBusyMode(null);
    }
  };

  const copyPublicUrl = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 1800);
      onNotify('Copied panel custom URL', 'success');
    } catch {
      // ignore clipboard errors
    }
  };

  const isConnected = tunnel?.status === 'connected';
  const isConnecting = tunnel?.status === 'connecting' || tunnel?.status === 'installing';
  const activeUrl = tunnel?.publicUrl || (isConnected ? tunnel?.customUrl : null) || null;
  const currentGoogleUrl =
    typeof window !== 'undefined' ? window.location.origin : 'http://127.0.0.1:3000';

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Cloudflare Tunnel — Panel Custom URL
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Connect this KilloraCloud website &amp; panel directly to your own custom domain via Cloudflare Tunnel so you never have to share the default Google URL.
          </p>
        </div>

        <button
          type="button"
          onClick={() => void loadStatus(false)}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-xs text-slate-200 cursor-pointer self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Refresh Status
        </button>
      </div>

      {/* Live Status Banner */}
      <div className="glass-panel rounded-2xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 min-w-0">
            <div
              className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border ${
                isConnected
                  ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-300'
                  : isConnecting
                    ? 'bg-amber-500/15 border-amber-400/40 text-amber-300'
                    : tunnel?.status === 'error'
                      ? 'bg-rose-500/15 border-rose-400/40 text-rose-300'
                      : 'bg-white/[0.06] border-white/15 text-slate-400'
              }`}
            >
              {isConnecting ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Globe className="w-5 h-5" />
              )}
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-semibold text-white">
                  {loading
                    ? 'Checking tunnel status...'
                    : isConnected
                      ? tunnel?.mode === 'quick'
                        ? 'Panel Live on Cloudflare Quick Tunnel'
                        : 'Panel Live on Your Custom Domain Tunnel'
                      : isConnecting
                        ? 'Connecting to Cloudflare Edge...'
                        : tunnel?.status === 'error'
                          ? 'Tunnel Disconnected (Error)'
                          : 'Panel Tunnel Offline'}
                </span>
                {isConnected && (
                  <span className="inline-flex items-center gap-1.5 text-[11px] font-mono text-emerald-300">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    {tunnel?.edgeConnections || 1} Edge {tunnel?.edgeConnections === 1 ? 'Link' : 'Links'}
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 truncate font-mono">
                Origin: {tunnel?.targetUrl || 'http://127.0.0.1:3000'} · Default URL: {currentGoogleUrl}
              </div>
            </div>
          </div>

          {isAdmin && (isConnected || isConnecting) && (
            <button
              type="button"
              disabled={busyMode !== null}
              onClick={() => void handleStop()}
              className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-xs font-semibold text-rose-200 disabled:opacity-50 cursor-pointer shrink-0"
            >
              {busyMode === 'stop' ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Power className="w-3.5 h-3.5" />
              )}
              Disconnect Tunnel
            </button>
          )}
        </div>

        {/* Active Public / Custom URL Highlight Box */}
        {isSafeHttpUrl(activeUrl) && (
          <div className="rounded-xl bg-emerald-500/10 border border-emerald-400/30 p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="text-[11px] uppercase tracking-wider text-emerald-300 font-semibold">
                Your Active Panel URL (Open Instead of Google URL)
              </div>
              <div className="text-sm font-mono text-white truncate mt-0.5">{activeUrl}</div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => void copyPublicUrl(activeUrl)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 border border-white/15 text-xs text-white cursor-pointer"
              >
                {copiedUrl ? (
                  <Check className="w-3.5 h-3.5 text-emerald-300" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
                Copy URL
              </button>
              <a
                href={activeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-xs font-semibold text-slate-950"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                Open Panel
              </a>
            </div>
          </div>
        )}

        {tunnel?.error && (
          <div className="rounded-xl bg-rose-500/10 border border-rose-500/30 px-3.5 py-2.5 text-xs text-rose-200">
            {tunnel.error}
          </div>
        )}
      </div>

      {/* Two Connection Options (Admin Only Controls) */}
      {isAdmin ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Option 1: Permanent Custom Domain via Cloudflare Zero Trust Token */}
          <form
            onSubmit={handleConnectCustom}
            className="lg:col-span-7 glass-panel rounded-2xl p-5 space-y-4"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Link2 className="w-4 h-4 text-sky-400" />
                  Connect Your Own Custom Domain
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Use your own domain (like <span className="font-mono text-slate-200">panel.yourdomain.com</span>) with Cloudflare Zero Trust Tunnel.
                </p>
              </div>
              {tunnel?.usesEnvToken && (
                <span className="text-[11px] font-mono text-emerald-300 shrink-0">
                  Env Token Ready
                </span>
              )}
            </div>

            <div className="space-y-3">
              <label className="block space-y-1.5">
                <span className="text-xs text-slate-300">Your Custom Panel URL</span>
                <input
                  type="text"
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  placeholder="https://panel.yourdomain.com"
                  className="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl glass-input"
                />
              </label>

              <label className="block space-y-1.5">
                <span className="text-xs text-slate-300 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-sky-400" />
                  Cloudflare Tunnel Token
                </span>
                <input
                  type="password"
                  value={tunnelToken}
                  onChange={(e) => setTunnelToken(e.target.value)}
                  placeholder={
                    tunnel?.usesEnvToken
                      ? 'Leave blank to use CLOUDFLARE_TUNNEL_TOKEN secret, or paste new token'
                      : 'Paste eyJh... token (or full cloudflared service install command)'
                  }
                  className="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl glass-input"
                  autoComplete="off"
                />
              </label>
            </div>

            <button
              type="submit"
              disabled={busyMode !== null}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-60 text-xs font-semibold text-slate-950 transition-colors cursor-pointer"
            >
              {busyMode === 'token' ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Link2 className="w-4 h-4" />
              )}
              {busyMode === 'token' ? 'Connecting Custom Domain...' : 'Connect Custom Domain Tunnel'}
            </button>

            {/* Quick Setup Steps */}
            <div className="rounded-xl bg-white/[0.03] border border-white/[0.08] p-3.5 space-y-2 text-[11px] text-slate-300">
              <div className="font-semibold text-white">Cloudflare Zero Trust Setup (1 Minute):</div>
              <ol className="list-decimal list-inside space-y-1 text-slate-400">
                <li>
                  Open <span className="text-slate-200">one.dash.cloudflare.com</span> →{' '}
                  <span className="text-slate-200">Networks → Tunnels → Create a tunnel → Cloudflared</span>.
                </li>
                <li>
                  Copy the <span className="text-slate-200">Tunnel Token</span> and paste it above.
                </li>
                <li>
                  Under <span className="text-slate-200">Public Hostname</span>, set your domain (e.g.{' '}
                  <span className="font-mono text-sky-300">panel.yourdomain.com</span>) → Service Type:{' '}
                  <span className="font-mono text-emerald-300">HTTP</span> → URL:{' '}
                  <span className="font-mono text-emerald-300">127.0.0.1:3000</span>.
                </li>
                <li>
                  For automatic reconnect after container restarts, save your token as{' '}
                  <span className="font-mono text-slate-200">CLOUDFLARE_TUNNEL_TOKEN</span> in Settings → Secrets.
                </li>
              </ol>
            </div>
          </form>

          {/* Option 2: Instant Free Quick Tunnel */}
          <div className="lg:col-span-5 glass-panel rounded-2xl p-5 flex flex-col justify-between gap-4">
            <div className="space-y-3">
              <div>
                <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  Instant Free Cloudflare URL
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  No domain or Cloudflare account needed. Instantly generate a live{' '}
                  <span className="font-mono text-slate-200">https://*.trycloudflare.com</span> URL for this entire KilloraCloud panel in 3 seconds.
                </p>
              </div>

              <div className="rounded-xl bg-white/[0.03] border border-white/[0.08] p-3.5 space-y-2 text-xs text-slate-300">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Panel Target</span>
                  <span className="font-mono text-white">http://127.0.0.1:3000</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Protocol</span>
                  <span className="font-mono text-sky-300">HTTP/2 + TLS (HTTPS)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">cloudflared Engine</span>
                  <span className="font-mono text-emerald-300">
                    {tunnel?.binaryReady ? 'Installed & Ready' : 'Auto-Install'}
                  </span>
                </div>
              </div>
            </div>

            <button
              type="button"
              disabled={busyMode !== null}
              onClick={() => void handleStartQuickTunnel()}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-60 text-xs font-semibold text-slate-950 transition-colors cursor-pointer"
            >
              {busyMode === 'quick' ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Zap className="w-4 h-4" />
              )}
              {busyMode === 'quick' ? 'Generating Live URL...' : 'Start Instant TryCloudflare URL'}
            </button>
          </div>
        </div>
      ) : (
        <div className="glass-panel rounded-2xl p-5 flex items-center gap-3 text-xs text-slate-300">
          <ShieldCheck className="w-5 h-5 text-sky-400 shrink-0" />
          Only the panel Administrator can connect or disconnect the website&apos;s Cloudflare Tunnel. Once connected, the active custom URL appears above.
        </div>
      )}

      {/* Live Cloudflared Connection Log */}
      <div className="glass-panel rounded-2xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/[0.08] flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-white">
            <Terminal className="w-3.5 h-3.5 text-sky-400" />
            Cloudflared Connector Logs
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            {tunnel?.logs.length ?? 0} lines
          </span>
        </div>
        <div className="p-4 bg-slate-950/75 font-mono text-[11px] text-slate-300 max-h-56 overflow-y-auto space-y-1">
          {!tunnel || tunnel.logs.length === 0 ? (
            <div className="text-slate-500">
              No tunnel logs yet. Connect a custom domain token or start an instant TryCloudflare URL above.
            </div>
          ) : (
            tunnel.logs.map((line, idx) => (
              <div key={idx} className="break-all leading-relaxed">
                {line}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
