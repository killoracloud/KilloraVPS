import React, { useCallback, useEffect, useState } from 'react';
import {
  Bot,
  Save,
  Loader2,
  Terminal,
  Shield,
  Sparkles,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Trash2,
} from 'lucide-react';
import {
  fetchDiscordBotConfig,
  saveDiscordBotConfig,
  type DiscordBotConfigStatus,
  type SiteSettings,
} from '../lib/api';

interface Props {
  settings: SiteSettings;
  onSettingsChanged: (next: SiteSettings) => void;
  onNotify: (msg: string, tone?: 'info' | 'success' | 'error') => void;
}

export const DiscordBotView: React.FC<Props> = ({ settings, onSettingsChanged, onNotify }) => {
  const [status, setStatus] = useState<DiscordBotConfigStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [draftToken, setDraftToken] = useState('');
  const [draftGuildId, setDraftGuildId] = useState(settings.discordGuildId || '');
  const [draftAdminRoleId, setDraftAdminRoleId] = useState(settings.discordAdminRoleId || '');
  const [saving, setSaving] = useState(false);

  const refreshStatus = useCallback(async (syncInputs = false) => {
    try {
      const data = await fetchDiscordBotConfig();
      setStatus(data);
      if (syncInputs) {
        setDraftGuildId(data.discordGuildId || '');
        setDraftAdminRoleId(data.discordAdminRoleId || '');
      }
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to load Discord bot status', 'error');
    } finally {
      setLoading(false);
    }
  }, [onNotify]);

  useEffect(() => {
    void refreshStatus(true);
    const id = setInterval(() => {
      void refreshStatus(false);
    }, 6000);
    return () => clearInterval(id);
  }, [refreshStatus]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updated = await saveDiscordBotConfig({
        ...(draftToken.trim() ? { discordBotToken: draftToken.trim() } : {}),
        discordGuildId: draftGuildId.trim(),
        discordAdminRoleId: draftAdminRoleId.trim(),
      });
      setStatus(updated);
      setDraftToken('');
      onSettingsChanged({
        ...settings,
        discordGuildId: updated.discordGuildId,
        discordAdminRoleId: updated.discordAdminRoleId,
      });
      onNotify('Discord Bot configuration saved! Reconnecting and syncing slash commands...', 'success');
      setTimeout(() => {
        void refreshStatus(false);
      }, 2500);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to save Discord bot settings', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDisconnect = async () => {
    setSaving(true);
    try {
      const updated = await saveDiscordBotConfig({
        clearToken: true,
        discordGuildId: draftGuildId.trim(),
        discordAdminRoleId: draftAdminRoleId.trim(),
      });
      setStatus(updated);
      setDraftToken('');
      onNotify('Discord Bot token cleared and bot disconnected.', 'info');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to disconnect bot', 'error');
    } finally {
      setSaving(false);
    }
  };

  const isOnline = Boolean(status?.online);
  const isConfigured = Boolean(status?.configured);

  return (
    <form onSubmit={handleSave} className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <Bot className="w-7 h-7 text-indigo-400" />
            Discord Bot Control Panel
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Configure your Discord Bot Token, Server (Guild) ID, and Admin Role ID to control VPS creation, member linking, real SSH, and real sshx.io sessions directly from Discord.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => void refreshStatus(false)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-xs font-medium text-slate-200 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh
          </button>

          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 disabled:opacity-60 text-xs font-semibold text-slate-950 cursor-pointer transition-colors"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save &amp; Connect Bot
          </button>
        </div>
      </div>

      {/* Live Status & Credentials Card */}
      <div className="glass-panel rounded-2xl p-6 space-y-5 border border-indigo-500/20">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span
              className={`w-3 h-3 rounded-full shrink-0 ${
                isOnline
                  ? 'bg-emerald-400 animate-pulse'
                  : isConfigured
                    ? 'bg-sky-400 animate-pulse'
                    : 'bg-amber-400'
              }`}
            />
            <div>
              <div className="text-sm font-semibold text-white">
                {loading
                  ? 'Checking Discord Bot status...'
                  : isOnline
                    ? `Online as ${status?.botTag || 'Discord Bot'}`
                    : isConfigured
                      ? 'Connecting to Discord...'
                      : 'Discord Bot Offline (Token Required)'}
              </div>
              {status && (
                <div className="text-[11px] text-slate-400 flex flex-wrap items-center gap-3 mt-0.5">
                  <span>Servers: <strong className="text-slate-200">{status.guildCount}</strong></span>
                  <span>Linked Panel Users: <strong className="text-slate-200">{status.linkedUsersCount}</strong></span>
                  <span className="inline-flex items-center gap-1">
                    {status.commandsSynced ? (
                      <>
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-300">Slash Commands Synced</span>
                      </>
                    ) : (
                      <span>Commands Pending Sync</span>
                    )}
                  </span>
                </div>
              )}
            </div>
          </div>

          {isConfigured && (
            <button
              type="button"
              onClick={() => void handleDisconnect()}
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-[11px] font-medium cursor-pointer shrink-0"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Remove Token
            </button>
          )}
        </div>

        {status?.lastError && (
          <div className="rounded-xl bg-rose-500/10 border border-rose-500/30 p-3 flex items-start gap-2.5 text-xs text-rose-200">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold">Discord Connection Error</div>
              <div className="text-[11px] text-rose-300/90 mt-0.5 font-mono">{status.lastError}</div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 pt-1">
          <label className="space-y-1.5 block">
            <span className="text-xs font-medium text-slate-300">
              Discord Bot Token {isConfigured ? '(Saved — enter new to replace)' : ''}
            </span>
            <input
              type="password"
              placeholder={isConfigured ? '••••••••••••••••••••••••••••' : 'Paste your Discord Bot Token'}
              value={draftToken}
              onChange={(e) => setDraftToken(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-indigo-500"
            />
            <span className="text-[10px] text-slate-500">
              Stored securely server-side; never exposed publicly.
            </span>
          </label>

          <label className="space-y-1.5 block">
            <span className="text-xs font-medium text-slate-300">Discord Server (Guild) ID</span>
            <input
              type="text"
              placeholder="123456789012345678"
              value={draftGuildId}
              onChange={(e) => setDraftGuildId(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-indigo-500"
            />
            <span className="text-[10px] text-slate-500">
              Syncs all slash commands &amp; OS/CPU menus instantly to your server.
            </span>
          </label>

          <label className="space-y-1.5 block">
            <span className="text-xs font-medium text-slate-300">VPS Admin Role ID</span>
            <input
              type="text"
              placeholder="123456789012345678"
              value={draftAdminRoleId}
              onChange={(e) => setDraftAdminRoleId(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-indigo-500"
            />
            <span className="text-[10px] text-slate-500">
              Only members with this Discord Role ID can run <code className="text-indigo-300">/vps create</code>, delete, suspend &amp; renew.
            </span>
          </label>
        </div>
      </div>

      {/* Supported Commands Reference */}
      <div className="glass-panel rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-2 text-sm font-semibold text-white">
          <Terminal className="w-4 h-4 text-indigo-400" />
          Active Discord Slash Commands
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="rounded-xl bg-black/30 border border-white/[0.08] p-4 space-y-2">
            <div className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5" />
              Admin Role Commands
            </div>
            <ul className="text-[11px] text-slate-300 space-y-1.5 font-mono">
              <li>• /vps create @user &lt;ram&gt; &lt;cpu&gt; &lt;disk&gt; &lt;os&gt; &lt;cpu_model&gt; &lt;expire&gt;</li>
              <li className="text-slate-400 font-sans pl-3">Shows all 6 OS choices &amp; all 29 CPU models. Sends root password privately to user&apos;s DM only.</li>
              <li>• /vps list</li>
              <li>• /vps renew @user &lt;expire&gt; <span className="text-slate-400 font-sans">(dropdown of user&apos;s VPS)</span></li>
              <li>• /vps suspend @user <span className="text-slate-400 font-sans">(dropdown of user&apos;s VPS)</span></li>
              <li>• /vps delete @user <span className="text-slate-400 font-sans">(dropdown + Confirm Delete prompt)</span></li>
            </ul>
          </div>

          <div className="rounded-xl bg-black/30 border border-white/[0.08] p-4 space-y-2">
            <div className="text-xs font-bold text-sky-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Member Commands
            </div>
            <ul className="text-[11px] text-slate-300 space-y-1.5 font-mono">
              <li>• /panel-link</li>
              <li className="text-slate-400 font-sans pl-3">DMs the user step-by-step for Email, Username &amp; Password, registers them on the web panel, and links Discord.</li>
              <li>• /manage</li>
              <li className="text-slate-400 font-sans pl-3">Persistent live panel with owner lock (&quot;This is not your VPS!&quot; for others), Start/Stop/Restart, Reinstall OS picker, real Pinggy/Bore SSH command, and real sshx.io web terminal URL.</li>
            </ul>
          </div>
        </div>
      </div>
    </form>
  );
};
