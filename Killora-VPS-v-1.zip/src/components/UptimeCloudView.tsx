import React, { useState } from 'react';
import {
  Cloud,
  RefreshCw,
  Activity,
  CheckCircle2,
  Loader2,
  Copy,
  Check,
} from 'lucide-react';
import type { KeepAliveSnapshot } from '../lib/keepAlive';
import type { HostDiagnostics, VpsInstance } from '../types/vps';

interface Props {
  heartbeat: KeepAliveSnapshot;
  diagnostics: HostDiagnostics | null;
  instances: VpsInstance[];
  lastCloudSyncAt: string | null;
  googleLinked: boolean;
  onLinkGoogleSync: () => Promise<void>;
  onForceCloudSync: () => Promise<void>;
  onForcePing: () => Promise<void>;
}

export const UptimeCloudView: React.FC<Props> = ({
  heartbeat,
  diagnostics,
  instances,
  lastCloudSyncAt,
  googleLinked,
  onLinkGoogleSync,
  onForceCloudSync,
  onForcePing,
}) => {
  const [syncing, setSyncing] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const pingUrl = `${origin}/api/ping`;
  const healthUrl = `${origin}/api/health`;

  const copyUrl = async (url: string, key: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedUrl(key);
      setTimeout(() => setCopiedUrl(null), 1600);
    } catch {
      // ignore
    }
  };

  const handleSync = async () => {
    setSyncing(true);
    try {
      await onForceCloudSync();
    } finally {
      setSyncing(false);
    }
  };

  const formatDuration = (sec: number) => {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${h}h ${m}m ${s}s`;
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            24/7 Host Keep-Alive &amp; Cloud Sync
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Keep your KilloraCloud host awake 24/7 with background Web Worker heartbeats, external monitor URLs, and Firebase Firestore zero-data-loss backup.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => void onForcePing()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-slate-100 cursor-pointer"
          >
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
            Ping Now
          </button>
          {googleLinked ? (
            <button
              type="button"
              disabled={syncing}
              onClick={() => void handleSync()}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-slate-950 cursor-pointer"
            >
              {syncing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <RefreshCw className="w-3.5 h-3.5" />
              )}
              Sync &amp; Restore Cloud Vault
            </button>
          ) : (
            <button
              type="button"
              onClick={() => void onLinkGoogleSync()}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 cursor-pointer"
            >
              <Cloud className="w-3.5 h-3.5" />
              Link Google Cloud Backup
            </button>
          )}
        </div>
      </div>

      {/* Live Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="glass-card rounded-2xl p-5 space-y-1.5">
          <div className="text-xs text-slate-400">24/7 Heartbeat Engine</div>
          <div className="text-lg font-bold text-white flex items-center gap-2">
            <CheckCircle2
              className={`w-4 h-4 ${
                heartbeat.online ? 'text-emerald-400' : 'text-amber-400'
              }`}
            />
            {heartbeat.online ? 'Host Online' : 'Reconnecting'}
          </div>
          <div className="text-xs text-slate-400 font-mono tabular-nums">
            Latency {heartbeat.latencyMs ?? 0}ms · {heartbeat.totalPings} pings
          </div>
        </div>

        <div className="glass-card rounded-2xl p-5 space-y-1.5">
          <div className="text-xs text-slate-400">Server Uptime</div>
          <div className="text-lg font-bold text-white font-mono tabular-nums">
            {formatDuration(heartbeat.serverUptimeSec)}
          </div>
          <div className="text-xs text-slate-400 font-mono">
            Tier {diagnostics?.runtimeTier || 'unknown'} · {diagnostics?.hostCpuCount ?? 'unknown'} Host Cores
          </div>
        </div>

        <div className="glass-card rounded-2xl p-5 space-y-1.5">
          <div className="text-xs text-slate-400">Firestore Cloud Backup</div>
          <div className="text-lg font-bold text-white flex items-center gap-2 tabular-nums">
            <Cloud className="w-4 h-4 text-sky-400" />
            {googleLinked ? `${instances.length} Synced VMs` : 'Local Mode'}
          </div>
          <div className="text-xs text-slate-400 font-mono">
            {lastCloudSyncAt
              ? `Synced ${new Date(lastCloudSyncAt).toLocaleTimeString()}`
              : googleLinked
                ? 'Ready'
                : 'Link Google for cloud restore'}
          </div>
        </div>
      </div>

      {/* External 24/7 UptimeRobot / Cron-Job Ping URLs */}
      <div className="glass-panel rounded-2xl p-5 space-y-4">
        <div>
          <h2 className="text-sm font-semibold text-white">
            External 24/7 Monitor Endpoints (UptimeRobot / Cron-Job.org)
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Add either URL below to a free 1-minute or 2-minute monitor so the panel never sleeps even when your browser is completely closed.
          </p>
        </div>

        <div className="space-y-2.5">
          {[
            { label: 'Heartbeat Ping URL', url: pingUrl, key: 'ping' },
            { label: 'Health Check URL', url: healthUrl, key: 'health' },
          ].map((item) => (
            <div
              key={item.key}
              className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-4 py-3 rounded-xl bg-black/40 border border-white/[0.08]"
            >
              <div className="min-w-0">
                <div className="text-[11px] text-slate-400">{item.label}</div>
                <div className="font-mono text-xs text-sky-300 truncate">{item.url}</div>
              </div>
              <button
                type="button"
                onClick={() => void copyUrl(item.url, item.key)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.07] hover:bg-white/[0.14] text-xs text-white shrink-0 cursor-pointer"
              >
                {copiedUrl === item.key ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
                {copiedUrl === item.key ? 'Copied' : 'Copy URL'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
