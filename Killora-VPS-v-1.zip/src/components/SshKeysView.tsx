import React, { useEffect, useState } from 'react';
import { Key, Plus, Trash2, Copy, Check, Terminal, Shield, Loader2, AlertCircle } from 'lucide-react';
import { fetchSshKeys, addSshKey, deleteSshKey, type SshKeyRecord } from '../lib/api';

interface Props {
  onNotify: (msg: string, tone?: 'info' | 'success' | 'error') => void;
}

export const SshKeysView: React.FC<Props> = ({ onNotify }) => {
  const [keys, setKeys] = useState<SshKeyRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [nameInput, setNameInput] = useState('');
  const [keyInput, setKeyInput] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const loadKeys = async () => {
    try {
      const data = await fetchSshKeys();
      setKeys(data);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to load SSH keys', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadKeys();
  }, []);

  const handleAddKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyInput.trim()) {
      onNotify('Please paste your public SSH key', 'error');
      return;
    }
    setSubmitting(true);
    try {
      const newKey = await addSshKey(nameInput || 'My SSH Key', keyInput);
      setKeys((prev) => [newKey, ...prev]);
      setNameInput('');
      setKeyInput('');
      onNotify('SSH key added successfully. Will be injected into all future VPS & reinstalls!', 'success');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to add SSH key', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteSshKey(id);
      setKeys((prev) => prev.filter((k) => k.id !== id));
      onNotify('SSH key deleted successfully', 'info');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to delete SSH key', 'error');
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
    onNotify('Public SSH key copied to clipboard', 'success');
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <Key className="w-7 h-7 text-sky-400" />
            SSH Public Keys &amp; Passwordless Access
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Add your public SSH keys here. They are automatically injected into <code className="text-sky-300">/root/.ssh/authorized_keys</code> of all newly provisioned and reinstalled Ubuntu / Debian / Proxmox VPS instances for instant passwordless SSH.
          </p>
        </div>
      </div>

      {/* Add New Key Form Card */}
      <div className="glass-panel rounded-2xl p-6 space-y-5 border border-sky-500/20">
        <div className="flex items-center gap-2 text-sm font-semibold text-white">
          <Plus className="w-4 h-4 text-sky-400" />
          Add New Public SSH Key
        </div>

        <form onSubmit={handleAddKey} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-1 space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Key Name / Label</label>
              <input
                type="text"
                placeholder="e.g. MacBook Pro M3 / Termux Phone"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                maxLength={40}
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-sky-500"
              />
            </div>
            <div className="sm:col-span-2 space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Public Key (ssh-rsa or ssh-ed25519)</label>
              <input
                type="text"
                placeholder="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAI... user@machine"
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-sky-500"
              />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span>Generate one in your terminal via: <code className="text-sky-300 font-mono">ssh-keygen -t ed25519</code></span>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-60 text-xs font-bold text-slate-950 cursor-pointer shrink-0 transition-colors"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              Save &amp; Register SSH Key
            </button>
          </div>
        </form>
      </div>

      {/* Keys List */}
      <div className="glass-panel rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-white">
            <Shield className="w-4 h-4 text-emerald-400" />
            Your Registered SSH Keys ({keys.length})
          </div>
        </div>

        {loading ? (
          <div className="py-12 flex justify-center items-center">
            <Loader2 className="w-6 h-6 text-sky-400 animate-spin" />
          </div>
        ) : keys.length === 0 ? (
          <div className="py-12 text-center rounded-xl bg-black/20 border border-white/[0.06] space-y-2">
            <AlertCircle className="w-8 h-8 text-slate-500 mx-auto" />
            <div className="text-xs font-semibold text-slate-300">No SSH Keys Registered Yet</div>
            <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
              Add your public SSH key above so you can SSH directly into your VPS without entering passwords.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {keys.map((k) => (
              <div
                key={k.id}
                className="rounded-xl bg-black/30 border border-white/[0.08] p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all hover:border-sky-500/30"
              >
                <div className="space-y-1.5 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span className="text-xs font-bold text-white">{k.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {new Date(k.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-slate-300 bg-black/50 px-3 py-2 rounded-lg truncate max-w-2xl border border-white/[0.04]">
                    {k.publicKey}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleCopy(k.publicKey, k.id)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] text-white text-[11px] font-medium transition-colors cursor-pointer"
                  >
                    {copiedId === k.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-300" />}
                    {copiedId === k.id ? 'Copied' : 'Copy Key'}
                  </button>

                  <button
                    onClick={() => handleDelete(k.id)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-400 text-[11px] font-medium transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
