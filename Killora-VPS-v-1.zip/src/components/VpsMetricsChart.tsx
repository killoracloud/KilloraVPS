import React, { useMemo } from 'react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import type { VpsInstance } from '../types/vps';

export interface VpsMetricSample {
  time: string;
  cpuPct: number;
  ramPct: number;
  ramUsedMb: number;
}

function formatClock(ms: number): string {
  const d = new Date(ms);
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const ss = String(d.getSeconds()).padStart(2, '0');
  return `${hh}:${mm}:${ss}`;
}

function formatMemoryAmount(mb: number): string {
  if (mb >= 1024) {
    const gb = mb / 1024;
    return Number.isInteger(gb) ? `${gb} GB` : `${gb.toFixed(1)} GB`;
  }
  return `${Math.round(mb)} MB`;
}

export function createMetricSample(
  vm: VpsInstance,
  timestampMs: number = Date.now()
): VpsMetricSample {
  const safeRamMb = Math.max(256, vm.ramMb || 1024);
  const cpuPct = Number(Math.max(0, Math.min(100, vm.cpuUsagePct ?? 0)).toFixed(1));
  const ramUsedMb = Math.max(
    0,
    Math.min(safeRamMb, Math.round(vm.ramUsedMb ?? 0))
  );
  const ramPct = Number(((ramUsedMb / safeRamMb) * 100).toFixed(1));
  return {
    time: formatClock(timestampMs),
    cpuPct,
    ramPct,
    ramUsedMb,
  };
}

export function seedVpsMetricHistory(
  vm: VpsInstance,
  count: number = 12,
  stepMs: number = 4000
): VpsMetricSample[] {
  return vm.cpuUsagePct === undefined || vm.ramUsedMb === undefined ? [] : [createMetricSample(vm)];
}

interface CustomTooltipProps {
  active?: boolean;
  label?: string | number;
  payload?: ReadonlyArray<{
    value?: number;
    payload?: VpsMetricSample;
  }>;
  metric: 'cpu' | 'ram';
  ramTotalMb: number;
}

const MetricTooltip: React.FC<CustomTooltipProps> = ({
  active,
  label,
  payload,
  metric,
  ramTotalMb,
}) => {
  if (!active || !payload || payload.length === 0) return null;
  const sample = payload[0]?.payload;
  if (!sample) return null;

  return (
    <div className="rounded-lg bg-slate-950/95 border border-white/15 px-2.5 py-1.5 text-[11px] font-mono tabular-nums shadow-lg">
      <div className="text-slate-400">{String(label ?? sample.time)}</div>
      {metric === 'cpu' ? (
        <div className="mt-0.5 text-sky-300 font-semibold">
          CPU {sample.cpuPct.toFixed(1)}%
        </div>
      ) : (
        <div className="mt-0.5 text-emerald-300 font-semibold">
          {formatMemoryAmount(sample.ramUsedMb)} / {formatMemoryAmount(ramTotalMb)} ({sample.ramPct.toFixed(1)}%)
        </div>
      )}
    </div>
  );
};

interface Props {
  vm: VpsInstance;
  history: VpsMetricSample[];
}

export const VpsMetricsChart: React.FC<Props> = ({ vm, history }) => {
  const series = useMemo(() => {
    if (history.length > 0) return history;
    return seedVpsMetricHistory(vm);
  }, [history, vm]);

  const latest = series[series.length - 1];
  const safeId = useMemo(() => vm.id.replace(/[^a-zA-Z0-9_-]/g, ''), [vm.id]);

  const { peakCpu, peakRamPct, cpuDomainMax, ramDomainMax } = useMemo(() => {
    let maxCpu = 0;
    let maxRam = 0;
    for (const pt of series) {
      if (pt.cpuPct > maxCpu) maxCpu = pt.cpuPct;
      if (pt.ramPct > maxRam) maxRam = pt.ramPct;
    }
    return {
      peakCpu: maxCpu,
      peakRamPct: maxRam,
      cpuDomainMax: Math.min(100, Math.max(20, Math.ceil((maxCpu * 1.4) / 5) * 5)),
      ramDomainMax: Math.min(100, Math.max(25, Math.ceil((maxRam * 1.4) / 5) * 5)),
    };
  }, [series]);
  if (!latest || vm.cpuUsagePct === undefined || vm.ramUsedMb === undefined) return <div className="text-slate-400 text-xs">Live metrics unavailable</div>;

  return (
    <div className="border-b border-white/[0.08] pb-3.5 space-y-2.5">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* CPU Live Area Graph */}
        <div className="min-w-0 space-y-1.5">
          <div className="flex items-baseline justify-between gap-2 text-xs">
            <span className="text-slate-300 font-medium">CPU Usage</span>
            <span className="font-mono tabular-nums text-sky-300 font-semibold">
              {latest.cpuPct.toFixed(1)}%
            </span>
          </div>
          <div className="h-[82px] w-full min-w-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={series}
                margin={{ top: 4, right: 4, left: -16, bottom: 0 }}
              >
                <defs>
                  <linearGradient id={`cpu-grad-${safeId}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.34} />
                    <stop offset="100%" stopColor="#38bdf8" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="2 3"
                  vertical={false}
                  stroke="rgba(255,255,255,0.06)"
                />
                <XAxis dataKey="time" hide />
                <YAxis
                  domain={[0, cpuDomainMax]}
                  tickCount={3}
                  width={42}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 10, fill: '#94a3b8' }}
                  tickFormatter={(v: number) => `${v}%`}
                />
                <Tooltip
                  content={<MetricTooltip metric="cpu" ramTotalMb={vm.ramMb} />}
                  cursor={{
                    stroke: 'rgba(56, 189, 248, 0.45)',
                    strokeWidth: 1,
                    strokeDasharray: '3 3',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="cpuPct"
                  stroke="#38bdf8"
                  strokeWidth={1.75}
                  fill={`url(#cpu-grad-${safeId})`}
                  isAnimationActive={false}
                  dot={false}
                  activeDot={{
                    r: 3.5,
                    fill: '#38bdf8',
                    stroke: '#020617',
                    strokeWidth: 1.5,
                  }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Memory Live Area Graph */}
        <div className="min-w-0 space-y-1.5 sm:border-l sm:border-white/[0.06] sm:pl-4">
          <div className="flex items-baseline justify-between gap-2 text-xs">
            <span className="text-slate-300 font-medium">Memory Usage</span>
            <span className="font-mono tabular-nums text-emerald-300 font-semibold truncate">
              {formatMemoryAmount(latest.ramUsedMb)} / {formatMemoryAmount(vm.ramMb)} ·{' '}
              {latest.ramPct.toFixed(0)}%
            </span>
          </div>
          <div className="h-[82px] w-full min-w-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={series}
                margin={{ top: 4, right: 4, left: -16, bottom: 0 }}
              >
                <defs>
                  <linearGradient id={`ram-grad-${safeId}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#34d399" stopOpacity={0.34} />
                    <stop offset="100%" stopColor="#34d399" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="2 3"
                  vertical={false}
                  stroke="rgba(255,255,255,0.06)"
                />
                <XAxis dataKey="time" hide />
                <YAxis
                  domain={[0, ramDomainMax]}
                  tickCount={3}
                  width={42}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 10, fill: '#94a3b8' }}
                  tickFormatter={(v: number) => `${v}%`}
                />
                <Tooltip
                  content={<MetricTooltip metric="ram" ramTotalMb={vm.ramMb} />}
                  cursor={{
                    stroke: 'rgba(52, 211, 153, 0.45)',
                    strokeWidth: 1,
                    strokeDasharray: '3 3',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="ramPct"
                  stroke="#34d399"
                  strokeWidth={1.75}
                  fill={`url(#ram-grad-${safeId})`}
                  isAnimationActive={false}
                  dot={false}
                  activeDot={{
                    r: 3.5,
                    fill: '#34d399',
                    stroke: '#020617',
                    strokeWidth: 1.5,
                  }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono tabular-nums text-slate-400">
        <span>
          Peak CPU {peakCpu.toFixed(1)}% · Peak RAM {peakRamPct.toFixed(1)}%
        </span>
        <span>Updated {latest.time}</span>
      </div>
    </div>
  );
};
