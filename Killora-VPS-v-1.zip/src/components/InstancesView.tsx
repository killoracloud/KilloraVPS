import React, { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Play,
  Square,
  RotateCw,
  Pause,
  Terminal,
  Sliders,
  Trash2,
  Plus,
  Globe,
  Loader2,
  AlertCircle,
  Search,
  X,
  Cpu,
  HardDrive,
  MemoryStick,
  Mail,
  UserCheck,
  KeyRound,
  RefreshCcw,
  Check,
  Copy,
} from 'lucide-react';
import {
  CPU_MODEL_PRESETS,
  OS_CATALOG,
  getOsOption,
  type HostDiagnostics,
  type MemberAccount,
  type OsId,
  type VpsInstance,
  type VpsStatus,
} from '../types/vps';
import {
  assignVpsToGmail,
  changeVpsRootPassword,
  deleteVps,
  fetchMembers,
  powerVps,
  reinstallVpsOs,
  resizeVps,
  startSshTunnel,
} from '../lib/api';
import {
  VpsMetricsChart,
  createMetricSample,
  seedVpsMetricHistory,
  type VpsMetricSample,
} from './VpsMetricsChart';

interface Props {
  isAdmin: boolean;
  instances: VpsInstance[];
  diagnostics: HostDiagnostics | null;
  onOpenConsole: (vpsId: string) => void;
  onDeployNew: () => void;
  onInstanceUpdated: (inst: VpsInstance) => void;
  onDelete: (vpsId: string) => Promise<void>;
  onNotify: (msg: string, tone?: 'info' | 'success' | 'error') => void;
}

export const AnimatedVmStatus: React.FC<{
  status: VpsStatus;
  busy?: boolean;
}> = ({ status, busy }) => {
  const effective: VpsStatus | 'transitioning' = busy ? 'transitioning' : status;
  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.span
        key={effective}
        initial={{ opacity: 0, y: -3, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 3, scale: 0.96 }}
        transition={{ duration: 0.16 }}
        className="inline-flex items-center gap-2 text-xs font-medium whitespace-nowrap"
      >
        {effective === 'running' && (
          <>
            <span className="relative flex h-2.5 w-2.5 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
            </span>
            <span className="text-emerald-400">Running</span>
          </>
        )}
        {(effective === 'transitioning' ||
          effective === 'provisioning' ||
          effective === 'rebooting') && (
          <>
            <Loader2 className="w-3.5 h-3.5 text-sky-400 animate-spin shrink-0" />
            <span className="text-sky-300">Updating</span>
          </>
        )}
        {effective === 'paused' && (
          <>
            <motion.span
              animate={{ opacity: [1, 0.35, 1] }}
              transition={{ duration: 1.4, repeat: Infinity }}
              className="inline-flex rounded-full h-2.5 w-2.5 bg-amber-400 shrink-0"
            />
            <span className="text-amber-300">Paused</span>
          </>
        )}
        {effective === 'stopped' && (
          <>
            <span className="inline-flex rounded-full h-2.5 w-2.5 bg-slate-500 shrink-0" />
            <span className="text-slate-400">Stopped</span>
          </>
        )}
        {effective === 'error' && (
          <>
            <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
            <span className="text-rose-400">Error</span>
          </>
        )}
      </motion.span>
    </AnimatePresence>
  );
};

function formatRam(mb: number): string {
  if (mb >= 1024) {
    const gb = mb / 1024;
    return Number.isInteger(gb) ? `${gb} GB` : `${gb.toFixed(1)} GB`;
  }
  return `${mb} MB`;
}

export const InstancesView: React.FC<Props> = ({
  isAdmin,
  instances,
  diagnostics,
  onOpenConsole,
  onDeployNew,
  onInstanceUpdated,
  onDelete,
  onNotify,
}) => {
  const [filter, setFilter] = useState<'all' | 'running' | 'stopped' | 'paused' | 'proxmox'>('all');
  const [search, setSearch] = useState('');
  const [busyMap, setBusyMap] = useState<Record<string, boolean>>({});
  const [resizeTarget, setResizeTarget] = useState<VpsInstance | null>(null);
  const [resizeVcpu, setResizeVcpu] = useState(4);
  const [resizeRamGb, setResizeRamGb] = useState(4);
  const resizeRamMb = Math.max(512, Math.round((Number(resizeRamGb) || 0.5) * 1024));
  const [resizeDiskGb, setResizeDiskGb] = useState(60);
  const [resizeCpuModel, setResizeCpuModel] = useState(CPU_MODEL_PRESETS[0]);
  const [resizing, setResizing] = useState(false);

  const [members, setMembers] = useState<MemberAccount[]>([]);
  const [assignTarget, setAssignTarget] = useState<VpsInstance | null>(null);
  const [assignEmailInput, setAssignEmailInput] = useState('');
  const [assigning, setAssigning] = useState(false);

  // Password Change Modal (Available to both Members & Admin)
  const [passwordTarget, setPasswordTarget] = useState<VpsInstance | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [changingPassword, setChangingPassword] = useState(false);

  // Red Reinstall OS Modal (Available to both Members & Admin)
  const [reinstallTarget, setReinstallTarget] = useState<VpsInstance | null>(null);
  const [reinstallOsId, setReinstallOsId] = useState<OsId>('ubuntu-24.04');
  const [reinstallPassword, setReinstallPassword] = useState('');
  const [reinstalling, setReinstalling] = useState(false);
  const [copiedSshId, setCopiedSshId] = useState<string | null>(null);
  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState<VpsInstance | null>(null);
  const [metricsHistory, setMetricsHistory] = useState<Record<string, VpsMetricSample[]>>({});

  useEffect(() => {
    setMetricsHistory((prev) => {
      const next: Record<string, VpsMetricSample[]> = {};
      const now = Date.now();
      for (const vm of instances) {
        if (vm.status !== 'running' || vm.cpuUsagePct === undefined || vm.ramUsedMb === undefined) continue;
        const existing = prev[vm.id];
        if (!existing || existing.length === 0) {
          next[vm.id] = seedVpsMetricHistory(vm, 12, 4000);
        } else {
          const sample = createMetricSample(vm, now);
          const last = existing[existing.length - 1];
          if (
            last &&
            last.time === sample.time &&
            last.cpuPct === sample.cpuPct &&
            last.ramUsedMb === sample.ramUsedMb
          ) {
            next[vm.id] = existing;
          } else {
            next[vm.id] = [...existing.slice(-19), sample];
          }
        }
      }
      return next;
    });
  }, [instances]);

  const copyCardText = async (text: string, key: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedSshId(key);
      onNotify(`${label} copied to clipboard`, 'success');
      setTimeout(() => setCopiedSshId(null), 1800);
    } catch {
      onNotify('Failed to copy', 'error');
    }
  };

  useEffect(() => {
    if (!isAdmin) return;
    void fetchMembers()
      .then(setMembers)
      .catch(() => {
        // ignore
      });
  }, [isAdmin]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return instances.filter((vm) => {
      const osInfo = getOsOption(vm.osId);
      if (filter === 'running' && vm.status !== 'running') return false;
      if (filter === 'stopped' && vm.status !== 'stopped') return false;
      if (filter === 'paused' && vm.status !== 'paused') return false;
      if (filter === 'proxmox' && osInfo.family !== 'proxmox') return false;
      if (q) {
        const hay = `${vm.vmid} ${vm.name} ${vm.hostname} ${osInfo.label} ${vm.cpuModel} ${vm.ipAddress}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [instances, filter, search]);

  const totals = useMemo(() => {
    return {
      running: instances.filter((v) => v.status === 'running').length,
      vcpu: instances.reduce((s, v) => s + v.vcpu, 0),
      ramMb: instances.reduce((s, v) => s + v.ramMb, 0),
      diskGb: instances.reduce((s, v) => s + v.diskGb, 0),
    };
  }, [instances]);

  const handlePower = async (
    vm: VpsInstance,
    action: 'start' | 'stop' | 'reboot' | 'pause' | 'resume'
  ) => {
    setBusyMap((prev) => ({ ...prev, [vm.id]: true }));
    try {
      const updated = await powerVps(vm.id, action);
      onInstanceUpdated(updated);
      const label = action === 'reboot' ? 'restart' : action;
      onNotify(`${vm.name}: ${label} completed`, 'success');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Action failed', 'error');
    } finally {
      setBusyMap((prev) => ({ ...prev, [vm.id]: false }));
    }
  };

  const handleSsh = async (vm: VpsInstance) => {
    setBusyMap((prev) => ({ ...prev, [vm.id]: true }));
    try {
      const updated = await startSshTunnel(vm.id);
      onInstanceUpdated(updated);
      if (updated.publicSsh?.command) {
        onNotify(`Public SSH ready: ${updated.publicSsh.command}`, 'success');
      }
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'SSH tunnel failed', 'error');
    } finally {
      setBusyMap((prev) => ({ ...prev, [vm.id]: false }));
    }
  };

  const handleRemove = async (vm: VpsInstance) => {
    setBusyMap((prev) => ({ ...prev, [vm.id]: true }));
    try {
      await deleteVps(vm.id);
      await onDelete(vm.id);
      onNotify(`Deleted ${vm.name}`, 'info');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Delete failed', 'error');
    } finally {
      setBusyMap((prev) => ({ ...prev, [vm.id]: false }));
    }
  };

  const openResize = (vm: VpsInstance) => {
    setResizeTarget(vm);
    setResizeVcpu(vm.vcpu);
    setResizeRamGb(Number((vm.ramMb / 1024).toFixed(2)));
    setResizeDiskGb(vm.diskGb);
    setResizeCpuModel(vm.cpuModel);
  };

  const submitResize = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resizeTarget) return;
    setResizing(true);
    try {
      const updated = await resizeVps(resizeTarget.id, {
        vcpu: resizeVcpu,
        ramMb: resizeRamMb,
        diskGb: resizeDiskGb,
        cpuModel: resizeCpuModel,
      });
      onInstanceUpdated(updated);
      onNotify(`Live resized ${updated.name} hardware`, 'success');
      setResizeTarget(null);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Resize failed', 'error');
    } finally {
      setResizing(false);
    }
  };

  const openAssignModal = (vm: VpsInstance) => {
    setAssignTarget(vm);
    setAssignEmailInput(vm.ownerEmail || '');
  };

  const submitAssign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assignTarget) return;
    setAssigning(true);
    try {
      const updated = await assignVpsToGmail(assignTarget.id, assignEmailInput.trim());
      onInstanceUpdated(updated);
      onNotify(
        updated.ownerEmail
          ? `Assigned ${updated.name} to ${updated.ownerEmail}`
          : `Reassigned ${updated.name} to Admin`,
        'success'
      );
      setAssignTarget(null);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to assign VPS', 'error');
    } finally {
      setAssigning(false);
    }
  };

  const openPasswordModal = (vm: VpsInstance) => {
    setPasswordTarget(vm);
    setNewPasswordInput('');
  };

  const submitPasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordTarget) return;
    setChangingPassword(true);
    try {
      const updated = await changeVpsRootPassword(passwordTarget.id, newPasswordInput.trim());
      onInstanceUpdated(updated);
      onNotify(`Root password updated for ${updated.name}`, 'success');
      setPasswordTarget(null);
      setNewPasswordInput('');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Password change failed', 'error');
    } finally {
      setChangingPassword(false);
    }
  };

  const openReinstallModal = (vm: VpsInstance) => {
    setReinstallTarget(vm);
    setReinstallOsId(vm.osId);
    setReinstallPassword('');
  };

  const submitReinstallOs = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reinstallTarget) return;
    setReinstalling(true);
    try {
      const updated = await reinstallVpsOs(reinstallTarget.id, {
        osId: reinstallOsId,
        rootPassword: reinstallPassword.trim() || undefined,
      });
      onInstanceUpdated(updated);
      const osInfo = getOsOption(updated.osId);
      onNotify(`${updated.name} freshly reinstalled with ${osInfo.label}!`, 'success');
      setReinstallTarget(null);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'OS reinstall failed', 'error');
    } finally {
      setReinstalling(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            {isAdmin ? 'Cloud VPS Dashboard' : 'My Assigned VPS Instances'}
          </h1>
          <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-300 tabular-nums">
            <span>Host {diagnostics?.hostHostname || 'killora-node'}</span>
            <span aria-hidden="true">·</span>
            <span>{totals.running} of {instances.length} Running</span>
          </div>
        </div>

        {isAdmin && (
          <button
            type="button"
            onClick={onDeployNew}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Create New VPS
          </button>
        )}
      </div>

      {/* Glass Summary Metric Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-card rounded-2xl p-4">
          <div className="text-xs text-slate-300">Active Instances</div>
          <div className="mt-1.5 text-2xl font-bold text-white tabular-nums">
            {totals.running}
            <span className="text-xs font-normal text-slate-400 ml-1.5">/ {instances.length}</span>
          </div>
        </div>
        <div className="glass-card rounded-2xl p-4">
          <div className="text-xs text-slate-300">Total vCPU Allocated</div>
          <div className="mt-1.5 text-2xl font-bold text-white tabular-nums">
            {totals.vcpu}
            <span className="text-xs font-normal text-slate-400 ml-1.5">cores</span>
          </div>
        </div>
        <div className="glass-card rounded-2xl p-4">
          <div className="text-xs text-slate-300">Total RAM Pool</div>
          <div className="mt-1.5 text-2xl font-bold text-white tabular-nums">
            {formatRam(totals.ramMb)}
          </div>
        </div>
        <div className="glass-card rounded-2xl p-4">
          <div className="text-xs text-slate-300">Total NVMe Storage</div>
          <div className="mt-1.5 text-2xl font-bold text-white tabular-nums">
            {totals.diskGb} GB
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="glass-card rounded-2xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 bg-black/35 rounded-xl overflow-x-auto">
          {(
            [
              ['all', 'All VPS'],
              ['running', 'Running'],
              ['stopped', 'Stopped'],
              ['paused', 'Paused'],
              ['proxmox', 'Proxmox 8/9'],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setFilter(key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                filter === key
                  ? 'bg-sky-500 text-slate-950 font-semibold'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search VPS name, OS, processor, IP..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl glass-input"
          />
        </div>
      </div>

      {/* Glass VPS Cards Grid */}
      {filtered.length === 0 ? (
        <div className="glass-panel rounded-2xl p-12 text-center space-y-3">
          <p className="text-sm font-semibold text-white">No VPS instances found</p>
          <p className="text-xs text-slate-300">
            {isAdmin
              ? 'Open the VPS Creator to deploy Ubuntu, Debian, or Proxmox VE 8/9 with AMD EPYC, Ryzen, or Intel Xeon processors.'
              : 'No VPS has been assigned to your Gmail account yet. Ask the Administrator to assign a VPS to your Gmail.'}
          </p>
          {isAdmin && (
            <button
              type="button"
              onClick={onDeployNew}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Launch VPS Creator
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <AnimatePresence initial={false}>
            {filtered.map((vm) => {
              const osInfo = getOsOption(vm.osId);
              const isBusy = Boolean(busyMap[vm.id]);
              return (
                <motion.div
                  key={vm.id}
                  layout
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.97 }}
                  transition={{ duration: 0.18 }}
                  className="glass-card rounded-2xl p-5 space-y-4"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2.5 flex-wrap">
                        <h2 className="text-base font-semibold text-white truncate">{vm.name}</h2>
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wide ${
                            osInfo.family === 'proxmox'
                              ? 'bg-orange-500/25 text-orange-300 border border-orange-500/40'
                              : osInfo.family === 'debian'
                                ? 'bg-rose-500/25 text-rose-300 border border-rose-500/40'
                                : 'bg-amber-500/25 text-amber-300 border border-amber-500/40'
                          }`}
                        >
                          {osInfo.family === 'proxmox' ? 'Proxmox VE' : osInfo.family === 'debian' ? 'Debian' : 'Ubuntu'}
                        </span>
                        <AnimatedVmStatus status={vm.status} busy={isBusy} />
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-300 tabular-nums">
                        <span className={osInfo.family === 'proxmox' ? 'text-orange-400 font-medium' : 'text-sky-300'}>
                          {osInfo.label}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono">{vm.ipAddress}</span>
                        <span aria-hidden="true">·</span>
                        <span className="truncate max-w-[220px]">{vm.cpuModel}</span>
                      </div>
                      {isAdmin && vm.ownerEmail && (
                        <div className="mt-1.5 inline-flex items-center gap-1.5 text-[11px] font-mono text-emerald-300">
                          <Mail className="w-3 h-3 shrink-0" />
                          <span className="truncate">Owner: {vm.ownerEmail}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Specs Strip */}
                  <div className="grid grid-cols-3 gap-3 border-y border-white/[0.08] py-3 text-xs tabular-nums">
                    <div>
                      <div className="text-slate-300 flex items-center gap-1">
                        <Cpu className="w-3 h-3 text-sky-400" />
                        vCPU
                      </div>
                      <div className="mt-0.5 font-mono text-white font-medium">{vm.vcpu} Cores</div>
                    </div>
                    <div>
                      <div className="text-slate-300 flex items-center gap-1">
                        <MemoryStick className="w-3 h-3 text-emerald-400" />
                        RAM
                      </div>
                      <div className="mt-0.5 font-mono text-white font-medium">{formatRam(vm.ramMb)}</div>
                    </div>
                    <div>
                      <div className="text-slate-300 flex items-center gap-1">
                        <HardDrive className="w-3 h-3 text-indigo-400" />
                        NVMe
                      </div>
                      <div className="mt-0.5 font-mono text-white font-medium">{vm.diskGb} GB</div><div className="text-xs text-slate-400">{vm.diskUsedMb === undefined ? "Usage unavailable" : `${(vm.diskUsedMb / 1024).toFixed(2)} GB runtime usage`}</div>
                    </div>
                  </div>

                  {/* Live CPU & Memory Graphs for Active VPS */}
                  {vm.status === 'running' && vm.cpuUsagePct !== undefined && vm.ramUsedMb !== undefined && (
                    <VpsMetricsChart
                      vm={vm}
                      history={metricsHistory[vm.id] ?? []}
                    />
                  )}

                  {vm.publicSsh?.active && (
                    <div className="p-3 rounded-xl bg-emerald-950/35 border border-emerald-400/40 space-y-2 w-full max-w-full overflow-hidden">
                      <div className="flex items-center justify-between gap-2 text-[11px] font-semibold text-emerald-300">
                        <span className="inline-flex items-center gap-1.5">
                          <Globe className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          Public SSH Active ({vm.publicSsh.provider})
                        </span>
                        <span className="font-mono text-emerald-300/80">Port {vm.publicSsh.port}</span>
                      </div>
                      <div className="px-2.5 py-2 rounded-lg bg-black/60 border border-white/10 font-mono text-xs text-emerald-200 break-all select-all">
                        {vm.publicSsh.command}
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            void copyCardText(
                              vm.publicSsh!.command,
                              `ssh-${vm.id}`,
                              'SSH command'
                            )
                          }
                          className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold cursor-pointer"
                        >
                          {copiedSshId === `ssh-${vm.id}` ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Copied SSH!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy SSH</span>
                            </>
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            void copyCardText(
                              vm.rootPassword,
                              `pass-${vm.id}`,
                              'Root password'
                            )
                          }
                          className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 border border-white/15 text-slate-100 text-xs font-semibold cursor-pointer"
                        >
                          {copiedSshId === `pass-${vm.id}` ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Copied Pass!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy Pass</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* VM Controls: Start, Restart, Stop, Change Password, Red Reinstall OS, Console */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-1.5">
                      {vm.status !== 'running' ? (
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() =>
                            void handlePower(vm, vm.status === 'paused' ? 'resume' : 'start')
                          }
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 cursor-pointer disabled:opacity-50"
                        >
                          <Play className="w-3.5 h-3.5" />
                          {vm.status === 'paused' ? 'Resume' : 'Start'}
                        </button>
                      ) : (
                        <>
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => void handlePower(vm, 'reboot')}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-slate-100 cursor-pointer disabled:opacity-50"
                          >
                            <RotateCw className="w-3.5 h-3.5 text-sky-400" />
                            Restart
                          </button>
                          {isAdmin && (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => void handlePower(vm, 'pause')}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-slate-100 cursor-pointer disabled:opacity-50"
                            >
                              <Pause className="w-3.5 h-3.5 text-amber-400" />
                              Pause
                            </button>
                          )}
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => void handlePower(vm, 'stop')}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-slate-100 cursor-pointer disabled:opacity-50"
                          >
                            <Square className="w-3.5 h-3.5 text-rose-400" />
                            Stop
                          </button>
                        </>
                      )}

                      {/* Change Password Button */}
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => openPasswordModal(vm)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-slate-100 cursor-pointer disabled:opacity-50"
                        title="Change VPS Root Password"
                      >
                        <KeyRound className="w-3.5 h-3.5 text-amber-300" />
                        Password
                      </button>

                      {/* Red Reinstall OS Button */}
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => openReinstallModal(vm)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-rose-600 hover:bg-rose-500 text-white shadow-sm cursor-pointer disabled:opacity-50"
                        title="Fresh OS Reinstall"
                      >
                        <RefreshCcw className="w-3.5 h-3.5" />
                        Reinstall OS
                      </button>

                      {isAdmin && (
                        <button
                          type="button"
                          disabled={isBusy || vm.status !== 'running'}
                          onClick={() => void handleSsh(vm)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-slate-100 cursor-pointer disabled:opacity-50"
                        >
                          <Globe className="w-3.5 h-3.5 text-emerald-400" />
                          SSH
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      {isAdmin && (
                        <>
                          <button
                            type="button"
                            onClick={() => openAssignModal(vm)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-400/30 text-emerald-200 cursor-pointer"
                            title="Assign / Give VPS to Member Gmail"
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                            Assign
                          </button>
                          <button
                            type="button"
                            onClick={() => openResize(vm)}
                            className="p-2 rounded-lg bg-white/[0.05] hover:bg-white/[0.12] border border-white/10 text-slate-200 cursor-pointer"
                            title="Live Hardware Resize"
                          >
                            <Sliders className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}

                      <button
                        type="button"
                        onClick={() => onOpenConsole(vm.id)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 cursor-pointer"
                      >
                        <Terminal className="w-3.5 h-3.5" />
                        Console
                      </button>

                      {isAdmin && (
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => setDeleteConfirmTarget(vm)}
                          className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/15 cursor-pointer"
                          title="Delete VPS"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}

      {/* Change VPS Root Password Modal (Members & Admin) */}
      <AnimatePresence>
        {passwordTarget && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.form
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              onSubmit={submitPasswordChange}
              className="w-full max-w-md glass-panel rounded-2xl p-6 space-y-5"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-semibold text-white flex items-center gap-2">
                    <KeyRound className="w-4 h-4 text-amber-300" />
                    Change VPS Root Password
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">{passwordTarget.name} ({passwordTarget.ipAddress})</p>
                </div>
                <button
                  type="button"
                  onClick={() => setPasswordTarget(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <label className="block space-y-1.5">
                <span className="text-xs text-slate-300">New Root Password (min 4 characters)</span>
                <input
                  type="password"
                  required
                  minLength={4}
                  maxLength={64}
                  value={newPasswordInput}
                  onChange={(e) => setNewPasswordInput(e.target.value)}
                  placeholder="Enter new root password"
                  className="w-full px-3.5 py-2.5 text-sm font-mono rounded-xl glass-input"
                  autoFocus
                />
              </label>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPasswordTarget(null)}
                  className="px-4 py-2 text-xs font-medium rounded-xl border border-white/15 text-slate-300 hover:bg-white/10 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={changingPassword}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 cursor-pointer"
                >
                  {changingPassword && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  Save Password
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Red Reinstall OS Modal — Choose New OS & Fresh Format VPS (Members & Admin) */}
      <AnimatePresence>
        {reinstallTarget && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.form
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              onSubmit={submitReinstallOs}
              className="w-full max-w-xl glass-panel rounded-2xl p-6 space-y-5 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <RefreshCcw className="w-4 h-4 text-rose-400" />
                    Reinstall Operating System — {reinstallTarget.name}
                  </h3>
                  <p className="text-xs text-rose-200/90 mt-0.5">
                    Select which OS to install. This wipes old files on this VPS and provisions a 100% fresh system.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setReinstallTarget(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* OS Selection Grid */}
              <div className="space-y-2">
                <span className="text-xs font-semibold text-slate-200">
                  Choose New Operating System:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {OS_CATALOG.map((item) => {
                    const selected = reinstallOsId === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setReinstallOsId(item.id)}
                        className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer ${
                          selected
                            ? 'bg-rose-500/20 border-rose-400 text-white'
                            : 'bg-black/35 border-white/[0.08] hover:border-white/25 text-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-semibold">{item.label}</span>
                          {selected ? (
                            <Check className="w-4 h-4 text-rose-400 shrink-0" />
                          ) : (
                            <span
                              className={`text-[10px] font-mono ${
                                item.family === 'proxmox' ? 'text-orange-400' : 'text-sky-300'
                              }`}
                            >
                              {item.codename}
                            </span>
                          )}
                        </div>
                        <p className="mt-1 text-[11px] text-slate-400 line-clamp-2">
                          {item.description}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              <label className="block space-y-1.5">
                <span className="text-xs text-slate-300">
                  New Root Password (optional — leave blank to keep current password)
                </span>
                <input
                  type="password"
                  value={reinstallPassword}
                  onChange={(e) => setReinstallPassword(e.target.value)}
                  placeholder="Keep current root password or type a new one"
                  className="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl glass-input"
                />
              </label>

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setReinstallTarget(null)}
                  className="px-4 py-2 text-xs font-medium rounded-xl border border-white/15 text-slate-300 hover:bg-white/10 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={reinstalling}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl bg-rose-600 hover:bg-rose-500 text-white cursor-pointer disabled:opacity-50"
                >
                  {reinstalling ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <RefreshCcw className="w-3.5 h-3.5" />
                  )}
                  {reinstalling ? 'Reinstalling Fresh OS...' : 'Confirm & Reinstall OS'}
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Glass Live Hardware Resize Modal (Admin Only) */}
      <AnimatePresence>
        {isAdmin && resizeTarget && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.form
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              onSubmit={submitResize}
              className="w-full max-w-md glass-panel rounded-2xl p-6 space-y-5"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-semibold text-white">Live Hardware Resize</h3>
                  <p className="text-xs text-slate-400 mt-0.5">{resizeTarget.name}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setResizeTarget(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <label className="space-y-1.5">
                  <span className="text-xs text-slate-300">vCPU (Unlimited)</span>
                  <input
                    type="number"
                    min={1}
                    value={resizeVcpu}
                    onChange={(e) => setResizeVcpu(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-mono rounded-xl glass-input"
                  />
                </label>
                <label className="space-y-1.5">
                  <span className="text-xs text-slate-300 flex items-center justify-between gap-1">
                    <span>RAM (GB)</span>
                    <span className="text-[10px] font-mono text-emerald-400 tabular-nums">
                      = {resizeRamMb.toLocaleString()} MB
                    </span>
                  </span>
                  <input
                    type="number"
                    min={0.5}
                    step="any"
                    value={resizeRamGb}
                    onChange={(e) => setResizeRamGb(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-mono rounded-xl glass-input"
                  />
                </label>
                <label className="space-y-1.5">
                  <span className="text-xs text-slate-300">Disk (GB, Unlimited)</span>
                  <input
                    type="number"
                    min={1}
                    value={resizeDiskGb}
                    onChange={(e) => setResizeDiskGb(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-mono rounded-xl glass-input"
                  />
                </label>
              </div>

              <label className="block space-y-1.5">
                <span className="text-xs text-slate-300">Processor Model</span>
                <select
                  value={resizeCpuModel}
                  onChange={(e) => setResizeCpuModel(e.target.value)}
                  className="w-full px-3 py-2.5 text-xs rounded-xl glass-input"
                >
                  {CPU_MODEL_PRESETS.map((model) => (
                    <option key={model} value={model} className="bg-slate-950 text-white">
                      {model}
                    </option>
                  ))}
                </select>
              </label>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setResizeTarget(null)}
                  className="px-4 py-2 text-xs font-medium rounded-xl border border-white/15 text-slate-300 hover:bg-white/10 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={resizing}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 cursor-pointer"
                >
                  {resizing && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  Apply Changes
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Admin Assign VPS to Member Gmail Modal */}
      <AnimatePresence>
        {isAdmin && assignTarget && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.form
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              onSubmit={submitAssign}
              className="w-full max-w-md glass-panel rounded-2xl p-6 space-y-5"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-semibold text-white">Assign VPS to Member Gmail</h3>
                  <p className="text-xs text-slate-400 mt-0.5">{assignTarget.name}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setAssignTarget(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {members.length > 0 && (
                <label className="block space-y-1.5">
                  <span className="text-xs text-slate-300">Pick Member Account</span>
                  <select
                    value={members.some((m) => m.email === assignEmailInput) ? assignEmailInput : ''}
                    onChange={(e) => setAssignEmailInput(e.target.value)}
                    className="w-full px-3 py-2.5 text-xs font-mono rounded-xl glass-input"
                  >
                    <option value="" className="bg-slate-950">
                      -- Select a Member Gmail (or type below) --
                    </option>
                    {members.map((m) => (
                      <option key={m.id} value={m.email} className="bg-slate-950">
                        {m.email} ({m.displayName})
                      </option>
                    ))}
                  </select>
                </label>
              )}

              <label className="block space-y-1.5">
                <span className="text-xs text-slate-300">Member Gmail (leave blank to reclaim to Admin)</span>
                <input
                  type="email"
                  value={assignEmailInput}
                  onChange={(e) => setAssignEmailInput(e.target.value)}
                  placeholder="member@gmail.com"
                  className="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl glass-input"
                />
              </label>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setAssignTarget(null)}
                  className="px-4 py-2 text-xs font-medium rounded-xl border border-white/15 text-slate-300 hover:bg-white/10 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={assigning}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 cursor-pointer"
                >
                  {assigning && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  Assign VPS
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deleteConfirmTarget && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              className="w-full max-w-md glass-panel rounded-2xl p-6 space-y-5"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-semibold text-white flex items-center gap-2">
                    <Trash2 className="w-5 h-5 text-rose-400" />
                    Confirm VPS Deletion
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Are you sure you want to delete <span className="text-white font-mono font-bold">{deleteConfirmTarget.name}</span>? This action is permanent and cannot be undone.
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setDeleteConfirmTarget(null)}
                  className="px-4 py-2 text-xs font-medium rounded-xl border border-white/15 text-slate-300 hover:bg-white/10 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    const target = deleteConfirmTarget;
                    setDeleteConfirmTarget(null);
                    if (target) {
                      await handleRemove(target);
                    }
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-rose-600 hover:bg-rose-500 text-white cursor-pointer"
                >
                  Yes, Delete VPS
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
