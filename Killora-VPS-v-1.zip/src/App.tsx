import {TcgAdmin} from './components/TcgAdmin';
import React, { useCallback, useEffect, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';
import {
  Menu,
  X,
  Server,
  Plus,
  Terminal,
  UserPlus,
  Globe,
  Cloud,
  LogOut,
  Loader2,
  ShieldCheck,
  Palette,
  Key,
  Bot,
} from 'lucide-react';
import { auth, googleProvider } from './lib/firebase';
import {
  deleteVpsFromCloud,
  ensureUserProfileInCloud,
  fetchCloudVpsInstances,
  syncVpsToCloud,
} from './lib/cloudSync';
import { keepAlive, type KeepAliveSnapshot } from './lib/keepAlive';
import {
  DEFAULT_SITE_SETTINGS,
  fetchCurrentSessionUser,
  fetchHostDiagnostics,
  fetchSiteSettings,
  fetchVpsList,
  getStoredSessionUser,
  logoutServerSession,
  restoreCloudVps,
  setSessionToken,
  type SiteSettings,
} from './lib/api';
import type {
  AuthSessionUser,
  HostDiagnostics,
  VpsInstance,
} from './types/vps';
import { AuthGate } from './components/AuthGate';
import { BackgroundStage } from './components/BackgroundStage';
import { InstancesView } from './components/InstancesView';
import { DeployVpsView } from './components/DeployVpsView';
import { TerminalPanel } from './components/TerminalPanel';
import { CloudflareTunnelView } from './components/CloudflareTunnelView';
import { MembersView } from './components/MembersView';
import { UptimeCloudView } from './components/UptimeCloudView';
import { PanelSettingsView } from './components/PanelSettingsView';
import { SshKeysView } from './components/SshKeysView';
import { DiscordBotView } from './components/DiscordBotView';

type TabId =
  | 'instances'
  | 'deploy'
  | 'console'
  | 'ssh-keys'
  | 'discord'
  | 'members'
  | 'tunnels'
  | 'uptime'
  | 'settings';

interface ToastMessage {
  id: number;
  text: string;
  tone: 'info' | 'success' | 'error';
}

export const App: React.FC = () => {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [credentialUser, setCredentialUser] = useState<AuthSessionUser | null>(() =>
    getStoredSessionUser()
  );
  const [authReady, setAuthReady] = useState<boolean>(() => Boolean(getStoredSessionUser()));

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<TabId>('instances');
  const [instances, setInstances] = useState<VpsInstance[]>([]);
  const [diagnostics, setDiagnostics] = useState<HostDiagnostics | null>(null);
  const [consoleVpsId, setConsoleVpsId] = useState<string | null>(null);
  const [lastCloudSyncAt, setLastCloudSyncAt] = useState<string | null>(null);
  const [heartbeat, setHeartbeat] = useState<KeepAliveSnapshot>({
    online: true,
    lastPingAt: null,
    latencyMs: null,
    serverUptimeSec: 0,
    consecutiveFailures: 0,
    totalPings: 0,
  });
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(DEFAULT_SITE_SETTINGS);

  useEffect(() => {
    void fetchSiteSettings()
      .then(setSiteSettings)
      .catch(() => {
        // keep defaults
      });
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    const alpha = Math.max(0.1, Math.min(0.88, siteSettings.glassOpacity / 100));
    root.style.setProperty('--kc-glass-alpha', alpha.toFixed(2));
    root.style.setProperty('--kc-glass-card-alpha', Math.max(0.08, alpha * 0.84).toFixed(2));
    root.style.setProperty('--kc-glass-header-alpha', Math.min(0.92, alpha + 0.08).toFixed(2));
    root.style.setProperty('--kc-glass-drawer-alpha', Math.min(0.94, alpha + 0.18).toFixed(2));
    root.style.setProperty('--kc-glass-blur', `${siteSettings.glassBlur}px`);
    root.classList.toggle('kc-glass-off', !siteSettings.glassEnabled);
    document.title = siteSettings.siteName || 'KilloraVPS';
  }, [siteSettings]);

  const activeSession: AuthSessionUser | null = credentialUser
    ? credentialUser
    : firebaseUser
      ? {
          uid: firebaseUser.uid,
          username: firebaseUser.email?.split('@')[0] || 'admin',
          displayName: firebaseUser.displayName || 'Administrator',
          email: firebaseUser.email || '',
          role: 'admin',
          isAdmin: true,
          authMode: 'firebase-google',
        }
      : null;

  const notify = useCallback((text: string, tone: 'info' | 'success' | 'error' = 'info') => {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    setToasts((prev) => [...prev.slice(-3), { id, text, tone }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  useEffect(() => {
    let active = true;
    const stored = getStoredSessionUser();
    if (stored) {
      setCredentialUser(stored);
      setAuthReady(true);
    }
    void fetchCurrentSessionUser().then((verifiedUser) => {
      if (!active) return;
      if (verifiedUser) {
        setCredentialUser(verifiedUser);
      }
      setAuthReady(true);
    });

    const unsub = onAuthStateChanged(auth, (fbUser) => {
      if (!active) return;
      setFirebaseUser(fbUser);
      setAuthReady(true);
    });
    return () => {
      active = false;
      unsub();
    };
  }, []);

  const refreshAll = useCallback(
    async (restoreFromCloudFirst = false) => {
      try {
        const [vpsRes, diagRes] = await Promise.all([
          fetchVpsList(),
          fetchHostDiagnostics(),
        ]);

        const liveList = Array.isArray(vpsRes?.instances)
          ? vpsRes.instances.filter(Boolean)
          : [];

        setInstances(liveList);
        if (diagRes?.diagnostics) {
          setDiagnostics(diagRes.diagnostics);
        }
        setConsoleVpsId((prev) => prev || liveList[0]?.id || null);

      } catch (err) {
        notify(err instanceof Error ? err.message : 'Failed to load VPS data', 'error');
      }
    },
    [firebaseUser, notify]
  );

  useEffect(() => {
    if (!activeSession) return;
    let mounted = true;

    const bootstrap = async () => {
      if (firebaseUser) {
        await ensureUserProfileInCloud(firebaseUser);
      }
      if (mounted) {
        await refreshAll(Boolean(firebaseUser));
      }
    };
    void bootstrap();

    keepAlive.setOnWake(() => {
      void refreshAll(Boolean(firebaseUser));
    });
    const unsubKeepAlive = keepAlive.subscribe(setHeartbeat);
    keepAlive.start();

    const poll = setInterval(() => {
      void fetchVpsList()
        .then((res) => {
          if (mounted && Array.isArray(res?.instances)) {
            setInstances(res.instances.filter(Boolean));
          }
        })
        .catch(() => {
          // ignore transient poll errors
        });
    }, 4000);

    return () => {
      mounted = false;
      clearInterval(poll);
      unsubKeepAlive();
      keepAlive.stop();
    };
  }, [activeSession?.uid, firebaseUser, refreshAll]);

  const handleInstanceUpdated = useCallback(
    (updated: VpsInstance) => {
      if (!updated || !updated.id) return;
      setInstances((prev) => {
        const list = Array.isArray(prev) ? prev.filter(Boolean) : [];
        const exists = list.some((v) => v.id === updated.id);
        return exists
          ? list.map((v) => (v.id === updated.id ? updated : v))
          : [...list, updated];
      });
      if (firebaseUser) {
        void syncVpsToCloud(firebaseUser.uid, updated)
          .then(() => setLastCloudSyncAt(new Date().toISOString()))
          .catch(() => {
            // handled via structured Firestore error handler
          });
      }
    },
    [firebaseUser]
  );

  const handleDelete = useCallback(
    async (vpsId: string) => {
      setInstances((prev) =>
        (Array.isArray(prev) ? prev.filter(Boolean) : []).filter((v) => v.id !== vpsId)
      );
      setConsoleVpsId((prev) => (prev === vpsId ? null : prev));
      if (firebaseUser) {
        await deleteVpsFromCloud(firebaseUser.uid, vpsId);
      }
    },
    [firebaseUser]
  );

  const handleLogout = async () => {
    await logoutServerSession();
    setCredentialUser(null);
    setDrawerOpen(false);
    setInstances([]);
    if (firebaseUser) {
      await signOut(auth);
    }
  };

  const hasCustomBg = Boolean(
    siteSettings.backgroundUrl && siteSettings.backgroundMode !== 'none'
  );

  if (!authReady) {
    return (
      <div className="min-h-screen kc-atmosphere flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-sky-400" />
      </div>
    );
  }

  if (!activeSession) {
    return (
      <>
        <BackgroundStage settings={siteSettings} />
        <div className="relative z-10">
          <AuthGate
            siteSettings={siteSettings}
            onCredentialLogin={(u) => {
              setCredentialUser(u);
              setActiveTab('instances');
            }}
          />
        </div>
      </>
    );
  }

  const allDrawerItems: Array<{
    id: TabId;
    label: string;
    subtitle: string;
    icon: React.ComponentType<{ className?: string }>;
    adminOnly?: boolean;
  }> = [
    {
      id: 'instances',
      label: activeSession.isAdmin ? 'VPS Dashboard' : 'My VPS List',
      subtitle: activeSession.isAdmin
        ? 'Manage instances & power controls'
        : 'Start, restart, stop, password & reinstall OS',
      icon: Server,
    },
    {
      id: 'deploy',
      label: 'VPS Creator',
      subtitle: 'Ubuntu, Debian, Proxmox 8/9 & 29 CPUs',
      icon: Plus,
      adminOnly: true,
    },
    {
      id: 'console',
      label: activeSession.isAdmin ? 'Console & Public SSH' : 'VPS Console',
      subtitle: 'Live real-time streaming shell',
      icon: Terminal,
    },
    {
      id: 'ssh-keys',
      label: 'SSH Keys',
      subtitle: 'Manage public SSH keys for passwordless access',
      icon: Key,
    },
    {
      id: 'discord',
      label: 'Discord Bot Integration',
      subtitle: 'Bot token, server ID & slash commands',
      icon: Bot,
      adminOnly: true,
    },
    {
      id: 'members',
      label: 'Member Account Creator',
      subtitle: 'Create member Gmail logins & quotas',
      icon: UserPlus,
      adminOnly: true,
    },
    {
      id: 'tunnels',
      label: 'Cloudflare Tunnel',
      subtitle: 'Custom domain URL for this panel',
      icon: Globe,
      adminOnly: true,
    },
    {
      id: 'uptime',
      label: '24/7 Host Keep-Alive',
      subtitle: 'Anti-pause heartbeat & Cloud Sync',
      icon: Cloud,
      adminOnly: true,
    },
    {
      id: 'settings',
      label: 'Panel Branding & Theme',
      subtitle: 'Hosting name, Logo, Glass ON/OFF & BG media',
      icon: Palette,
      adminOnly: true,
    },
  ];

  const drawerItems = allDrawerItems.filter(
    (item) => !item.adminOnly || activeSession.isAdmin,
  );

  const safeInstances = Array.isArray(instances) ? instances.filter(Boolean) : [];
  const activeConsoleInstance =
    safeInstances.find((v) => v?.id === consoleVpsId) ?? safeInstances[0] ?? null;

  const navigate = (tab: TabId) => {
    setActiveTab(tab);
    setDrawerOpen(false);
  };

  return (
    <>
      <BackgroundStage settings={siteSettings} />
      <div
        className={`relative z-10 min-h-screen text-slate-100 flex flex-col ${
          hasCustomBg ? 'kc-has-custom-bg' : 'kc-atmosphere'
        }`}
      >
      {/* Frosted Glass Top Bar with Original 3-Lines (☰) Drawer Trigger */}
      <header className="sticky top-0 z-30 h-16 px-4 sm:px-6 glass-header flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => setDrawerOpen(true)}
            aria-label="Open navigation menu"
            className="p-2.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.13] border border-white/10 text-white transition-colors cursor-pointer shrink-0"
          >
            <Menu className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => navigate('instances')}
            className="inline-flex items-center gap-2.5 text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            {siteSettings.logoUrl ? (
              <img
                src={siteSettings.logoUrl}
                alt={siteSettings.siteName || 'Hosting Logo'}
                className="w-8 h-8 rounded-lg object-contain bg-white/5 border border-white/10"
              />
            ) : (
              <span className="w-8 h-8 rounded-lg bg-sky-500/15 border border-sky-400/30 flex items-center justify-center text-sky-300">
                <Server className="w-4 h-4" />
              </span>
            )}
            <span>{siteSettings.siteName || 'KilloraVPS'}</span>
          </button>
        </div>

        <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-slate-300">
          {drawerItems.slice(0, 5).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => navigate(item.id)}
              className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeTab === item.id
                  ? 'text-sky-300 font-semibold'
                  : 'hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          {activeSession.isAdmin ? (
            <button
              type="button"
              onClick={() => navigate('deploy')}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              VPS Creator
            </button>
          ) : (
            <button
              type="button"
              onClick={() => navigate('console')}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Terminal className="w-3.5 h-3.5" />
              Open Console
            </button>
          )}
        </div>
      </header>

      {/* Slide-Out 3-Lines Frosted Glass Drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDrawerOpen(false)}
              className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs"
            />
            <motion.aside
              initial={{ x: -320 }}
              animate={{ x: 0 }}
              exit={{ x: -320 }}
              transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
              className="fixed top-0 left-0 bottom-0 z-50 w-80 max-w-[86vw] glass-drawer flex flex-col"
            >
              <div className="h-16 px-5 border-b border-white/[0.08] flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  {siteSettings.logoUrl ? (
                    <img
                      src={siteSettings.logoUrl}
                      alt={siteSettings.siteName || 'Hosting Logo'}
                      className="w-8 h-8 rounded-lg object-contain bg-white/5 border border-white/10 shrink-0"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-lg bg-sky-500/15 border border-sky-400/30 flex items-center justify-center text-sky-300 shrink-0">
                      <Server className="w-4 h-4" />
                    </div>
                  )}
                  <span className="text-base font-bold text-white tracking-tight truncate">
                    {siteSettings.siteName || 'KilloraVPS'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setDrawerOpen(false)}
                  aria-label="Close navigation menu"
                  className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-3.5 space-y-1.5">
                {drawerItems.map((item) => {
                  const Icon = item.icon;
                  const active = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => navigate(item.id)}
                      className={`w-full text-left px-3.5 py-3 rounded-xl flex items-start gap-3 transition-colors cursor-pointer ${
                        active
                          ? 'bg-sky-500/18 border border-sky-400/40 text-white'
                          : 'border border-transparent hover:bg-white/[0.06] text-slate-200'
                      }`}
                    >
                      <Icon
                        className={`w-4 h-4 mt-0.5 shrink-0 ${
                          active ? 'text-sky-300' : 'text-slate-400'
                        }`}
                      />
                      <div className="min-w-0">
                        <div className="text-xs font-semibold truncate">{item.label}</div>
                        <div className="text-[11px] text-slate-400 truncate mt-0.5">
                          {item.subtitle}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="p-4 border-t border-white/[0.08] space-y-3">
                <div className="flex items-center gap-2.5 text-xs">
                  <div className="w-8 h-8 rounded-xl bg-sky-500/15 border border-sky-400/30 flex items-center justify-center text-sky-300 shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-semibold text-white truncate">
                      {activeSession.displayName}
                    </div>
                    <div className="text-[11px] text-slate-400 truncate font-mono">
                      {activeSession.isAdmin ? 'Admin' : 'Member'} · @{activeSession.username}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => void handleLogout()}
                  className="w-full inline-flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-white/[0.06] hover:bg-rose-500/20 border border-white/10 hover:border-rose-500/40 text-xs font-medium text-slate-200 hover:text-rose-200 transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Sign Out
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Glass Workspace Viewport */}
      <main className="flex-1 w-full max-w-[1440px] mx-auto px-4 sm:px-6 py-7">
        {activeTab === 'instances' && (
          <InstancesView
            isAdmin={activeSession.isAdmin}
            instances={instances}
            diagnostics={diagnostics}
            onOpenConsole={(id) => {
              setConsoleVpsId(id);
              setActiveTab('console');
            }}
            onDeployNew={() => setActiveTab('deploy')}
            onInstanceUpdated={handleInstanceUpdated}
            onDelete={handleDelete}
            onNotify={notify}
          />
        )}

        {activeTab === 'deploy' && activeSession.isAdmin && <TcgAdmin />}
        {activeTab === 'deploy' && activeSession.isAdmin && (
          <DeployVpsView
            isAdmin={activeSession.isAdmin}
            onDeployed={(created) => {
              handleInstanceUpdated(created);
              setConsoleVpsId(created.id);
              setActiveTab('instances');
            }}
            onNotify={notify}
          />
        )}

        {activeTab === 'console' && (
          <TerminalPanel
            instance={activeConsoleInstance}
            allInstances={instances}
            onSelectInstance={(id) => setConsoleVpsId(id)}
            onInstanceUpdated={handleInstanceUpdated}
            onNotify={notify}
          />
        )}

        {activeTab === 'ssh-keys' && (
          <SshKeysView onNotify={notify} />
        )}

        {activeTab === 'discord' && activeSession.isAdmin && (
          <DiscordBotView
            settings={siteSettings}
            onSettingsChanged={setSiteSettings}
            onNotify={notify}
          />
        )}

        {activeTab === 'members' && activeSession.isAdmin && (
          <MembersView
            currentEmail={activeSession.email || activeSession.username}
            instances={instances}
            onNotify={notify}
          />
        )}

        {activeTab === 'tunnels' && activeSession.isAdmin && (
          <CloudflareTunnelView isAdmin={activeSession.isAdmin} onNotify={notify} />
        )}

        {activeTab === 'uptime' && activeSession.isAdmin && (
          <UptimeCloudView
            heartbeat={heartbeat}
            diagnostics={diagnostics}
            instances={instances}
            lastCloudSyncAt={lastCloudSyncAt}
            googleLinked={Boolean(firebaseUser)}
            onLinkGoogleSync={async () => {
              try {
                setSessionToken(null);
                setCredentialUser(null);
                await signInWithPopup(auth, googleProvider);
                notify('Google Firestore 24/7 Cloud Sync connected', 'success');
              } catch (err) {
                notify(err instanceof Error ? err.message : 'Google link failed', 'error');
              }
            }}
            onForceCloudSync={async () => {
              await refreshAll(true);
              notify('Cloud vault synchronized & restored', 'success');
            }}
            onForcePing={async () => {
              const ok = await keepAlive.pingNow();
              notify(ok ? 'Keep-alive ping succeeded' : 'Heartbeat failed', ok ? 'success' : 'error');
            }}
          />
        )}
        {activeTab === 'settings' && activeSession.isAdmin && (
          <PanelSettingsView
            settings={siteSettings}
            onSettingsChanged={setSiteSettings}
            onNotify={notify}
          />
        )}
      </main>

      {/* Glass Toast Stack */}
      <div className="fixed bottom-4 inset-x-3 sm:left-auto sm:right-4 z-50 space-y-2 sm:max-w-sm">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`px-4 py-3 rounded-xl backdrop-blur-xl border text-xs flex items-center justify-between gap-3 shadow-2xl ${
              toast.tone === 'error'
                ? 'bg-rose-950/85 border-rose-500/40 text-rose-100'
                : toast.tone === 'success'
                  ? 'bg-emerald-950/85 border-emerald-500/40 text-emerald-100'
                  : 'bg-slate-900/85 border-white/15 text-slate-100'
            }`}
          >
            <span className="break-all min-w-0">{toast.text}</span>
            <button
              type="button"
              onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
              className="text-slate-400 hover:text-white shrink-0 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
      </div>
    </>
  );
};

export default App;
