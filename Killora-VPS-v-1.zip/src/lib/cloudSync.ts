import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  setDoc,
  where,
  type Unsubscribe,
} from 'firebase/firestore';
import type { User } from 'firebase/auth';
import { db, handleFirestoreError, OperationType } from './firebase';
import type { CloudflareTunnel, TeamMember, VpsInstance } from '../types/vps';

const ADMIN_EMAIL = 'binad5215@gmail.com';

function clip(val: string | undefined, max: number, fallback = ''): string {
  return (val ?? fallback).trim().slice(0, max);
}

export async function ensureUserProfileInCloud(user: User): Promise<void> {
  const userPath = `users/${user.uid}`;
  const ref = doc(db, 'users', user.uid);
  try {
    const snap = await getDoc(ref);
    const now = new Date().toISOString();
    if (!snap.exists()) {
      const isBootstrapAdmin =
        user.emailVerified && (user.email || '').toLowerCase() === ADMIN_EMAIL;
      await setDoc(ref, {
        uid: user.uid,
        email: clip(user.email || 'user@killoracloud.local', 254),
        displayName: clip(user.displayName || user.email?.split('@')[0] || 'Operator', 120),
        photoURL: clip(user.photoURL || '', 512),
        role: isBootstrapAdmin ? 'admin' : 'operator',
        createdAt: now,
        updatedAt: now,
      });
    } else {
      await setDoc(
        ref,
        {
          displayName: clip(user.displayName || snap.data().displayName || 'Operator', 120),
          photoURL: clip(user.photoURL || snap.data().photoURL || '', 512),
          updatedAt: now,
        },
        { merge: true }
      );
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, userPath);
  }
}

export async function syncVpsToCloud(uid: string, inst: VpsInstance): Promise<void> {
  const docPath = `users/${uid}/vps_instances/${inst.id}`;
  const now = new Date().toISOString();
  const payload = {
    id: clip(inst.id, 64),
    ownerId: uid,
    vmid: Math.max(100, Math.min(999999, Math.floor(inst.vmid || 100))),
    name: clip(inst.name, 80, `vm-${inst.vmid}`),
    hostname: clip(inst.hostname, 80, `vm-${inst.vmid}`),
    osId: inst.osId,
    status: inst.status,
    vcpu: Math.max(1, Math.floor(inst.vcpu || 4)),
    ramMb: Math.max(256, Math.floor(inst.ramMb || 4096)),
    diskGb: Math.max(1, Math.floor(inst.diskGb || 60)),
    cpuModel: clip(inst.cpuModel, 120, 'AMD EPYC 9654 96-Core Processor'),
    ipAddress: clip(inst.ipAddress, 64, '10.10.10.2'),
    rootPassword: "",
    nodeName: clip(inst.nodeName, 64, 'pve-node-01'),
    runtimeTier: clip(inst.runtimeTier, 40, 'node-workspace'),
    createdAt: clip(inst.createdAt, 40, now),
    updatedAt: now,
  };
  try {
    await setDoc(doc(db, 'users', uid, 'vps_instances', inst.id), payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, docPath);
  }
}

export async function deleteVpsFromCloud(uid: string, vpsId: string): Promise<void> {
  const docPath = `users/${uid}/vps_instances/${vpsId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'vps_instances', vpsId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, docPath);
  }
}

export async function fetchCloudVpsInstances(uid: string): Promise<Partial<VpsInstance>[]> {
  const colPath = `users/${uid}/vps_instances`;
  try {
    const q = query(collection(db, 'users', uid, 'vps_instances'), where('ownerId', '==', uid));
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as Partial<VpsInstance>);
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, colPath);
  }
}

export function subscribeCloudTunnels(
  uid: string,
  onData: (tunnels: CloudflareTunnel[]) => void
): Unsubscribe {
  const colPath = `users/${uid}/tunnels`;
  const q = query(collection(db, 'users', uid, 'tunnels'), where('ownerId', '==', uid));
  return onSnapshot(
    q,
    (snap) => {
      const items = snap.docs.map((d) => d.data() as CloudflareTunnel);
      onData(items.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, colPath);
    }
  );
}

export async function saveCloudTunnel(uid: string, tunnel: CloudflareTunnel): Promise<void> {
  const docPath = `users/${uid}/tunnels/${tunnel.id}`;
  const now = new Date().toISOString();
  try {
    await setDoc(doc(db, 'users', uid, 'tunnels', tunnel.id), {
      id: clip(tunnel.id, 64),
      ownerId: uid,
      vpsId: clip(tunnel.vpsId, 64),
      name: clip(tunnel.name, 80, 'tunnel'),
      hostname: clip(tunnel.hostname, 160),
      localPort: Math.max(1, Math.min(65535, Math.floor(tunnel.localPort))),
      protocol: tunnel.protocol,
      enabled: Boolean(tunnel.enabled),
      createdAt: clip(tunnel.createdAt, 40, now),
      updatedAt: now,
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, docPath);
  }
}

export async function removeCloudTunnel(uid: string, tunnelId: string): Promise<void> {
  const docPath = `users/${uid}/tunnels/${tunnelId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'tunnels', tunnelId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, docPath);
  }
}

export function subscribeTeamMembers(
  uid: string,
  onData: (members: TeamMember[]) => void
): Unsubscribe {
  const colPath = `users/${uid}/members`;
  const q = query(collection(db, 'users', uid, 'members'), where('ownerId', '==', uid));
  return onSnapshot(
    q,
    (snap) => {
      const items = snap.docs.map((d) => d.data() as TeamMember);
      onData(items.sort((a, b) => a.createdAt.localeCompare(b.createdAt)));
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, colPath);
    }
  );
}

export async function saveTeamMember(uid: string, member: TeamMember): Promise<void> {
  const docPath = `users/${uid}/members/${member.id}`;
  const now = new Date().toISOString();
  try {
    await setDoc(doc(db, 'users', uid, 'members', member.id), {
      id: clip(member.id, 64),
      ownerId: uid,
      email: clip(member.email, 254),
      displayName: clip(member.displayName, 100),
      role: member.role,
      createdAt: clip(member.createdAt, 40, now),
      updatedAt: now,
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, docPath);
  }
}

export async function removeTeamMember(uid: string, memberId: string): Promise<void> {
  const docPath = `users/${uid}/members/${memberId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'members', memberId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, docPath);
  }
}
