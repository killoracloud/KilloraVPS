import { auth } from './firebase';
import type {
  AuthSessionUser,
  CloudflareTunnel,
  ClusterTaskLog,
  CreateVpsPayload,
  HostDiagnostics,
  MemberAccount,
  OsId,
  ResizeVpsPayload,
  VpsInstance,
} from '../types/vps';

const TOKEN_STORAGE_KEY = 'kc_session_token_v1';
const USER_STORAGE_KEY = 'kc_session_user_v1';

let inMemorySessionToken: string | null = (() => {
  try {
    return typeof window !== 'undefined' ? window.localStorage.getItem(TOKEN_STORAGE_KEY) : null;
  } catch {
    return null;
  }
})();

export function setSessionToken(token: string | null, user?: AuthSessionUser | null): void {
  inMemorySessionToken = token;
  try {
    if (typeof window === 'undefined') return;
    if (token) {
      window.localStorage.setItem(TOKEN_STORAGE_KEY, token);
      if (user) {
        window.localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
      }
    } else {
      window.localStorage.removeItem(TOKEN_STORAGE_KEY);
      window.localStorage.removeItem(USER_STORAGE_KEY);
    }
  } catch {
    // ignore storage access errors
  }
}

export function getSessionToken(): string | null {
  if (inMemorySessionToken) return inMemorySessionToken;
  try {
    if (typeof window !== 'undefined') {
      inMemorySessionToken = window.localStorage.getItem(TOKEN_STORAGE_KEY);
    }
  } catch {
    // ignore
  }
  return inMemorySessionToken;
}

export function getStoredSessionUser(): AuthSessionUser | null {
  try {
    if (typeof window === 'undefined') return null;
    const token = getSessionToken();
    const rawUser = window.localStorage.getItem(USER_STORAGE_KEY);
    if (!token || !rawUser) return null;
    const parsed = JSON.parse(rawUser) as AuthSessionUser;
    return parsed && typeof parsed.uid === 'string' ? parsed : null;
  } catch {
    return null;
  }
}

async function authHeaders(): Promise<Record<string, string>> {
  const token = getSessionToken();
  if (token) {
    return {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    };
  }
  const user = auth.currentUser;
  if (!user) throw new Error('Sign in required');
  const fbToken = await user.getIdToken();
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${fbToken}`,
  };
}

async function apiRequest<T>(url: string, init?: RequestInit): Promise<T> {
  const headers = await authHeaders();
  const res = await fetch(url, {
    ...init,
    credentials: 'include',
    headers: {
      ...headers,
      ...(init?.headers ?? {}),
    },
  });
  const text = await res.text();
  let data: unknown = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    if (res.ok) {
      throw new Error('Unexpected non-JSON response from server');
    }
  }
  if (!res.ok) {
    throw new Error((data as { error?: string })?.error || `Request failed (${res.status})`);
  }
  return data as T;
}

async function publicRequest<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
  });
  const text = await res.text();
  let data: unknown = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    if (res.ok) {
      throw new Error('Unexpected non-JSON response from server');
    }
  }
  if (!res.ok) {
    throw new Error((data as { error?: string })?.error || `Request failed (${res.status})`);
  }
  return data as T;
}

// Auth Endpoints (Single Unified Login for .env Admin + Admin-created Members)
export async function fetchAuthStatus(): Promise<{
  adminConfigured: boolean;
  usesEnvPasscode: boolean;
  adminUsername: string;
  adminEmail: string;
  memberCount: number;
}> {
  return publicRequest('/api/auth/status');
}

export async function setupFirstRunAdmin(
  username: string,
  password: string,
  email?: string
): Promise<{ token: string; user: AuthSessionUser }> {
  const res = await publicRequest<{ token: string; user: AuthSessionUser }>('/api/auth/admin/setup', {
    method: 'POST',
    body: JSON.stringify({ username, password, email }),
  });
  setSessionToken(res.token, res.user);
  return res;
}

export async function loginUnified(
  identifier: string,
  password: string
): Promise<{ token: string; user: AuthSessionUser }> {
  const res = await publicRequest<{ token: string; user: AuthSessionUser }>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ identifier, password }),
  });
  setSessionToken(res.token, res.user);
  return res;
}

export async function fetchCurrentSessionUser(): Promise<AuthSessionUser | null> {
  try {
    const res = await apiRequest<{ user?: AuthSessionUser }>('/api/auth/me');
    if (res?.user && typeof res.user.uid === 'string') {
      const token = getSessionToken();
      if (token) setSessionToken(token, res.user);
      return res.user;
    }
    return null;
  } catch {
    return null;
  }
}

export async function logoutServerSession(): Promise<void> {
  setSessionToken(null);
  try {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
  } catch {
    // ignore
  }
}

// Panel Branding, Glass Effect & Custom Background Settings
export type BackgroundMediaMode = 'auto' | 'none' | 'image' | 'video' | 'embed';

export interface SiteSettings {
  siteName: string;
  siteTagline: string;
  logoUrl: string;
  glassEnabled: boolean;
  glassOpacity: number;
  glassBlur: number;
  backgroundMode: BackgroundMediaMode;
  backgroundUrl: string;
  backgroundDim: number;
  backgroundBlur: number;
  backgroundMuted: boolean;
  discordBotToken: string;
  discordGuildId: string;
  discordAdminRoleId: string;
  updatedAt: string;
}

export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  siteName: 'KilloraCloud',
  siteTagline: '24/7 Cloud VPS Control Panel',
  logoUrl: '',
  glassEnabled: true,
  glassOpacity: 34,
  glassBlur: 18,
  backgroundMode: 'auto',
  backgroundUrl: '',
  backgroundDim: 42,
  backgroundBlur: 0,
  backgroundMuted: true,
  discordBotToken: '',
  discordGuildId: '',
  discordAdminRoleId: '',
  updatedAt: '',
};

export async function fetchSiteSettings(): Promise<SiteSettings> {
  const res = await publicRequest<{ settings?: Partial<SiteSettings> }>('/api/site-settings');
  return res?.settings ? { ...DEFAULT_SITE_SETTINGS, ...res.settings } : DEFAULT_SITE_SETTINGS;
}

export async function saveSiteSettings(patch: Partial<SiteSettings>): Promise<SiteSettings> {
  const res = await apiRequest<{ settings?: Partial<SiteSettings> }>('/api/site-settings', {
    method: 'PUT',
    body: JSON.stringify(patch),
  });
  return res?.settings ? { ...DEFAULT_SITE_SETTINGS, ...res.settings } : { ...DEFAULT_SITE_SETTINGS, ...patch };
}

export async function uploadBackgroundMedia(file: File): Promise<{
  url: string;
  mediaKind: 'image' | 'video';
  settings: SiteSettings;
}> {
  const headers = await authHeaders();
  const res = await fetch('/api/site-settings/upload-bg', {
    method: 'POST',
    headers: {
      Authorization: headers.Authorization,
      'Content-Type': file.type || 'application/octet-stream',
    },
    body: file,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `Upload failed (${res.status})`);
  }
  return data as { url: string; mediaKind: 'image' | 'video'; settings: SiteSettings };
}

export async function uploadLogoMedia(file: File): Promise<{
  url: string;
  settings: SiteSettings;
}> {
  const headers = await authHeaders();
  const res = await fetch('/api/site-settings/upload-logo', {
    method: 'POST',
    headers: {
      Authorization: headers.Authorization,
      'Content-Type': file.type || 'application/octet-stream',
    },
    body: file,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `Logo upload failed (${res.status})`);
  }
  return data as { url: string; settings: SiteSettings };
}

// Member Account Creator CRUD (Admin only — members strictly have Gmail + role 'member')
export async function fetchMembers(): Promise<MemberAccount[]> {
  const res = await apiRequest<{ members?: MemberAccount[] }>('/api/members');
  return Array.isArray(res?.members) ? res.members.filter(Boolean) : [];
}

export async function createMember(payload: {
  email: string;
  username?: string;
  password: string;
  displayName?: string;
  maxVps: number;
  maxVcpu: number;
  maxRamMb: number;
  maxDiskGb: number;
}): Promise<MemberAccount> {
  const res = await apiRequest<{ member: MemberAccount }>('/api/members', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return res.member;
}

export async function updateMember(
  memberId: string,
  payload: Partial<{
    displayName: string;
    email: string;
    password: string;
    active: boolean;
    maxVps: number;
    maxVcpu: number;
    maxRamMb: number;
    maxDiskGb: number;
  }>
): Promise<MemberAccount> {
  const res = await apiRequest<{ member: MemberAccount }>(`/api/members/${memberId}`, {
    method: 'PATCH',
    body: JSON.stringify(payload),
  });
  return res.member;
}

export async function deleteMember(memberId: string): Promise<void> {
  await apiRequest<{ ok: boolean }>(`/api/members/${memberId}`, {
    method: 'DELETE',
  });
}

// Real Panel Cloudflare Tunnel (Custom Domain & Quick Tunnel for this website/panel)
export interface PanelTunnelStatus {
  status: 'idle' | 'installing' | 'connecting' | 'connected' | 'error';
  mode: 'token' | 'quick' | null;
  publicUrl: string | null;
  customUrl: string;
  targetUrl: string;
  connectedAt: string | null;
  edgeConnections: number;
  usesEnvToken: boolean;
  binaryReady: boolean;
  error: string | null;
  logs: string[];
}

export async function fetchPanelTunnelStatus(): Promise<PanelTunnelStatus> {
  const res = await apiRequest<{ tunnel: PanelTunnelStatus }>('/api/panel-tunnel/status');
  return res.tunnel;
}

export async function startPanelCloudflareTunnel(payload: {
  mode: 'token' | 'quick';
  token?: string;
  customUrl?: string;
}): Promise<PanelTunnelStatus> {
  const res = await apiRequest<{ tunnel: PanelTunnelStatus }>('/api/panel-tunnel/start', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return res.tunnel;
}

export async function stopPanelCloudflareTunnel(): Promise<PanelTunnelStatus> {
  const res = await apiRequest<{ tunnel: PanelTunnelStatus }>('/api/panel-tunnel/stop', {
    method: 'POST',
  });
  return res.tunnel;
}

// Cloudflare Tunnels (server-side persisted)
export async function fetchServerTunnels(): Promise<CloudflareTunnel[]> {
  const res = await apiRequest<{ tunnels?: CloudflareTunnel[] }>('/api/tunnels');
  return Array.isArray(res?.tunnels) ? res.tunnels.filter(Boolean) : [];
}

export async function createServerTunnel(payload: {
  vpsId: string;
  name: string;
  hostname: string;
  localPort: number;
  protocol: 'http' | 'https' | 'tcp';
}): Promise<CloudflareTunnel> {
  const res = await apiRequest<{ tunnel: CloudflareTunnel }>('/api/tunnels', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return res.tunnel;
}

export async function toggleServerTunnel(
  id: string,
  enabled: boolean
): Promise<CloudflareTunnel> {
  const res = await apiRequest<{ tunnel: CloudflareTunnel }>(`/api/tunnels/${id}`, {
    method: 'PATCH',
    body: JSON.stringify({ enabled }),
  });
  return res.tunnel;
}

export async function deleteServerTunnel(id: string): Promise<void> {
  await apiRequest<{ ok: boolean }>(`/api/tunnels/${id}`, {
    method: 'DELETE',
  });
}

// VPS & Host Diagnostics Endpoints
export async function fetchVpsList(): Promise<{
  instances: VpsInstance[];
  tasks: ClusterTaskLog[];
}> {
  const res = await apiRequest<{
    instances?: VpsInstance[];
    tasks?: ClusterTaskLog[];
  }>('/api/vps');
  return {
    instances: Array.isArray(res?.instances) ? res.instances.filter(Boolean) : [],
    tasks: Array.isArray(res?.tasks) ? res.tasks.filter(Boolean) : [],
  };
}

export async function fetchHostDiagnostics(): Promise<{
  diagnostics: HostDiagnostics;
  tasks: ClusterTaskLog[];
}> {
  return apiRequest('/api/host/diagnostics');
}

export async function createVps(payload: CreateVpsPayload): Promise<VpsInstance> {
  const res = await apiRequest<{ instance: VpsInstance }>('/api/vps', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return res.instance;
}

export async function assignVpsToGmail(
  vpsId: string,
  ownerEmail: string
): Promise<VpsInstance> {
  const res = await apiRequest<{ instance: VpsInstance }>(`/api/vps/${vpsId}/assign`, {
    method: 'PATCH',
    body: JSON.stringify({ ownerEmail }),
  });
  return res.instance;
}

export async function restoreCloudVps(
  instances: Partial<VpsInstance>[]
): Promise<VpsInstance[]> {
  const res = await apiRequest<{ instances?: VpsInstance[] }>('/api/cloud/restore', {
    method: 'POST',
    body: JSON.stringify({ instances }),
  });
  return Array.isArray(res?.instances) ? res.instances.filter(Boolean) : [];
}

export async function powerVps(
  vpsId: string,
  action: 'start' | 'stop' | 'reboot' | 'pause' | 'resume'
): Promise<VpsInstance> {
  const res = await apiRequest<{ instance: VpsInstance }>(`/api/vps/${vpsId}/power`, {
    method: 'POST',
    body: JSON.stringify({ action }),
  });
  return res.instance;
}

export async function resizeVps(
  vpsId: string,
  payload: ResizeVpsPayload
): Promise<VpsInstance> {
  const res = await apiRequest<{ instance: VpsInstance }>(`/api/vps/${vpsId}/resize`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return res.instance;
}

export async function deleteVps(vpsId: string): Promise<void> {
  await apiRequest<{ ok: boolean }>(`/api/vps/${vpsId}`, {
    method: 'DELETE',
  });
}

export async function changeVpsRootPassword(
  vpsId: string,
  password: string
): Promise<VpsInstance> {
  const res = await apiRequest<{ instance: VpsInstance }>(`/api/vps/${vpsId}/password`, {
    method: 'POST',
    body: JSON.stringify({ password }),
  });
  return res.instance;
}

export async function reinstallVpsOs(
  vpsId: string,
  payload: { osId: OsId; rootPassword?: string }
): Promise<VpsInstance> {
  const res = await apiRequest<{ instance: VpsInstance }>(`/api/vps/${vpsId}/reinstall`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return res.instance;
}

export async function execVpsCommand(
  vpsId: string,
  command: string
): Promise<{ output: string; exitCode: number }> {
  return apiRequest(`/api/vps/${vpsId}/exec`, {
    method: 'POST',
    body: JSON.stringify({ command }),
  });
}

export async function requestWsTicket(vpsId: string): Promise<string> {
  const res = await apiRequest<{ ticket: string }>(`/api/vps/${vpsId}/ws-ticket`, {
    method: 'POST',
  });
  return res.ticket;
}

export async function startSshTunnel(vpsId: string): Promise<VpsInstance> {
  const res = await apiRequest<{ instance: VpsInstance }>(
    `/api/vps/${vpsId}/ssh-tunnel/start`,
    { method: 'POST' }
  );
  return res.instance;
}

export async function stopSshTunnel(vpsId: string): Promise<VpsInstance> {
  const res = await apiRequest<{ instance: VpsInstance }>(
    `/api/vps/${vpsId}/ssh-tunnel/stop`,
    { method: 'POST' }
  );
  return res.instance;
}

export interface SshKeyRecord {
  id: string;
  userEmail: string;
  name: string;
  publicKey: string;
  createdAt: string;
}

export async function fetchSshKeys(): Promise<SshKeyRecord[]> {
  const res = await apiRequest<{ keys: SshKeyRecord[] }>('/api/ssh-keys');
  return res.keys || [];
}

export async function addSshKey(name: string, publicKey: string): Promise<SshKeyRecord> {
  const res = await apiRequest<{ key: SshKeyRecord }>('/api/ssh-keys', {
    method: 'POST',
    body: JSON.stringify({ name, publicKey }),
  });
  return res.key;
}

export async function deleteSshKey(id: string): Promise<void> {
  await apiRequest<{ ok: boolean }>(`/api/ssh-keys/${id}`, {
    method: 'DELETE',
  });
}

export async function startSshxSessionApi(vpsId: string): Promise<VpsInstance> {
  const res = await apiRequest<{ instance: VpsInstance }>(
    `/api/vps/${vpsId}/sshx/start`,
    { method: 'POST' }
  );
  return res.instance;
}

export async function stopSshxSessionApi(vpsId: string): Promise<VpsInstance> {
  const res = await apiRequest<{ instance: VpsInstance }>(
    `/api/vps/${vpsId}/sshx/stop`,
    { method: 'POST' }
  );
  return res.instance;
}

export interface DiscordBotConfigStatus {
  configured: boolean;
  online: boolean;
  botTag: string | null;
  botId: string | null;
  guildCount: number;
  commandsSynced: boolean;
  lastError: string | null;
  linkedUsersCount: number;
  discordGuildId: string;
  discordAdminRoleId: string;
}

export async function fetchDiscordBotConfig(): Promise<DiscordBotConfigStatus> {
  return apiRequest<DiscordBotConfigStatus>('/api/discord/config');
}

export async function saveDiscordBotConfig(payload: {
  discordBotToken?: string;
  discordGuildId?: string;
  discordAdminRoleId?: string;
  clearToken?: boolean;
}): Promise<DiscordBotConfigStatus> {
  return apiRequest<DiscordBotConfigStatus>('/api/discord/config', {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
}


export async function fetchProvisioningNodes():Promise<string[]>{const r=await fetch("/api/provisioning-nodes",{headers:await authHeaders()});if(!r.ok)throw Error("Node list unavailable");return (await r.json()).nodes;}
