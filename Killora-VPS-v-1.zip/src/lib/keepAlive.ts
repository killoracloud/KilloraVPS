export interface KeepAliveSnapshot {
  online: boolean;
  lastPingAt: string | null;
  latencyMs: number | null;
  serverUptimeSec: number;
  consecutiveFailures: number;
  totalPings: number;
}

type Listener = (snapshot: KeepAliveSnapshot) => void;

class KeepAliveEngine {
  private timer: ReturnType<typeof setInterval> | null = null;
  private worker: Worker | null = null;
  private listeners = new Set<Listener>();
  private onWakeCallback: (() => void) | null = null;
  private state: KeepAliveSnapshot = {
    online: true,
    lastPingAt: null,
    latencyMs: null,
    serverUptimeSec: 0,
    consecutiveFailures: 0,
    totalPings: 0,
  };

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    listener({ ...this.state });
    return () => {
      this.listeners.delete(listener);
    };
  }

  setOnWake(cb: () => void): void {
    this.onWakeCallback = cb;
  }

  private emit(): void {
    const snap = { ...this.state };
    for (const fn of this.listeners) {
      fn(snap);
    }
  }

  async pingNow(): Promise<boolean> {
    const t0 = performance.now();
    const wasOffline = !this.state.online;
    try {
      const res = await fetch('/api/ping', {
        method: 'GET',
        cache: 'no-store',
        headers: { 'x-keepalive': '1' },
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { ok?: boolean; uptimeSec?: number };
      const latency = Math.round(performance.now() - t0);
      this.state = {
        online: Boolean(data.ok),
        lastPingAt: new Date().toISOString(),
        latencyMs: latency,
        serverUptimeSec: Number(data.uptimeSec || 0),
        consecutiveFailures: 0,
        totalPings: this.state.totalPings + 1,
      };
      this.emit();
      if (wasOffline && this.onWakeCallback) {
        this.onWakeCallback();
      }
      return true;
    } catch {
      this.state = {
        ...this.state,
        online: false,
        consecutiveFailures: this.state.consecutiveFailures + 1,
        totalPings: this.state.totalPings + 1,
      };
      this.emit();
      return false;
    }
  }

  start(): void {
    if (this.timer || this.worker) return;
    void this.pingNow();

    // Use a lightweight inline Web Worker timer so background browser tab throttling never pauses heartbeats
    try {
      const blob = new Blob(
        [
          `setInterval(() => { postMessage('tick'); }, 25000);`,
        ],
        { type: 'application/javascript' }
      );
      const workerUrl = URL.createObjectURL(blob);
      this.worker = new Worker(workerUrl);
      this.worker.onmessage = () => {
        void this.pingNow();
      };
    } catch {
      this.timer = setInterval(() => {
        void this.pingNow();
      }, 25000);
    }

    document.addEventListener('visibilitychange', this.handleVisibility);
    window.addEventListener('online', this.handleOnline);
  }

  stop(): void {
    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
    }
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    document.removeEventListener('visibilitychange', this.handleVisibility);
    window.removeEventListener('online', this.handleOnline);
  }

  private handleVisibility = (): void => {
    if (document.visibilityState === 'visible') {
      void this.pingNow();
    }
  };

  private handleOnline = (): void => {
    void this.pingNow();
  };
}

export const keepAlive = new KeepAliveEngine();
