export type OsId =
  | 'proxmox-9'
  | 'proxmox-8'
  | 'ubuntu-24.04'
  | 'ubuntu-22.04'
  | 'debian-13'
  | 'debian-12';

export type OsFamily = 'proxmox' | 'ubuntu' | 'debian';

export interface OsOption {
  id: OsId;
  label: string;
  prettyName: string;
  family: OsFamily;
  versionId: string;
  codename: string;
  ociImage: string;
  kernelLabel: string;
  description: string;
}

export interface CpuPresetOption {
  model: string;
  vendor: 'AMD' | 'Intel';
  series: string;
  clockHint: string;
  arch: string;
}

export const DEFAULT_CPU_MODEL = 'AMD EPYC 9654 96-Core Processor';

export const CPU_MODEL_CATALOG: CpuPresetOption[] = [
  // AMD EPYC Zen 5 (Turin)
  { model: 'AMD EPYC 9965 192-Core Processor', vendor: 'AMD', series: 'EPYC 9005 Turin', clockHint: '3.7 GHz Boost', arch: 'Zen 5c' },
  { model: 'AMD EPYC 9655 96-Core Processor', vendor: 'AMD', series: 'EPYC 9005 Turin', clockHint: '4.5 GHz Boost', arch: 'Zen 5' },
  { model: 'AMD EPYC 9575F 64-Core Processor', vendor: 'AMD', series: 'EPYC 9005 Turin', clockHint: '5.0 GHz Boost', arch: 'Zen 5' },
  { model: 'AMD EPYC 9R45 192-Core Processor', vendor: 'AMD', series: 'EPYC 9005 Cloud', clockHint: '4.1 GHz Boost', arch: 'Zen 5' },
  { model: 'AMD EPYC 9J45 192-Core Processor', vendor: 'AMD', series: 'EPYC 9005 Cloud', clockHint: '4.0 GHz Boost', arch: 'Zen 5' },
  // AMD EPYC Zen 4 (Genoa)
  { model: 'AMD EPYC 9654 96-Core Processor', vendor: 'AMD', series: 'EPYC 9004 Genoa', clockHint: '3.7 GHz Boost', arch: 'Zen 4' },
  { model: 'AMD EPYC 9554 64-Core Processor', vendor: 'AMD', series: 'EPYC 9004 Genoa', clockHint: '3.75 GHz Boost', arch: 'Zen 4' },
  { model: 'AMD EPYC 9354 32-Core Processor', vendor: 'AMD', series: 'EPYC 9004 Genoa', clockHint: '3.8 GHz Boost', arch: 'Zen 4' },
  // AMD EPYC Zen 3 (Milan)
  { model: 'AMD EPYC 7763 64-Core Processor', vendor: 'AMD', series: 'EPYC 7003 Milan', clockHint: '3.5 GHz Boost', arch: 'Zen 3' },
  { model: 'AMD EPYC 7713 64-Core Processor', vendor: 'AMD', series: 'EPYC 7003 Milan', clockHint: '3.67 GHz Boost', arch: 'Zen 3' },
  { model: 'AMD EPYC 7543 32-Core Processor', vendor: 'AMD', series: 'EPYC 7003 Milan', clockHint: '3.7 GHz Boost', arch: 'Zen 3' },
  { model: 'AMD EPYC 7513 32-Core Processor', vendor: 'AMD', series: 'EPYC 7003 Milan', clockHint: '3.65 GHz Boost', arch: 'Zen 3' },
  { model: 'AMD EPYC 7443 24-Core Processor', vendor: 'AMD', series: 'EPYC 7003 Milan', clockHint: '4.0 GHz Boost', arch: 'Zen 3' },
  // AMD Ryzen High-Clock
  { model: 'AMD Ryzen 9 9950X 16-Core Processor', vendor: 'AMD', series: 'Ryzen 9000', clockHint: '5.7 GHz Boost', arch: 'Zen 5' },
  { model: 'AMD Ryzen 9 9900X 12-Core Processor', vendor: 'AMD', series: 'Ryzen 9000', clockHint: '5.6 GHz Boost', arch: 'Zen 5' },
  { model: 'AMD Ryzen 9 7950X 16-Core Processor', vendor: 'AMD', series: 'Ryzen 7000', clockHint: '5.7 GHz Boost', arch: 'Zen 4' },
  { model: 'AMD Ryzen 9 5950X 16-Core Processor', vendor: 'AMD', series: 'Ryzen 5000', clockHint: '4.9 GHz Boost', arch: 'Zen 3' },
  { model: 'AMD Ryzen 9 5900X 12-Core Processor', vendor: 'AMD', series: 'Ryzen 5000', clockHint: '4.8 GHz Boost', arch: 'Zen 3' },
  { model: 'AMD Ryzen 7 5800X 8-Core Processor', vendor: 'AMD', series: 'Ryzen 5000', clockHint: '4.7 GHz Boost', arch: 'Zen 3' },
  { model: 'AMD Ryzen 5 5600X 6-Core Processor', vendor: 'AMD', series: 'Ryzen 5000', clockHint: '4.6 GHz Boost', arch: 'Zen 3' },
  // Intel Xeon Scalable
  { model: 'Intel(R) Xeon(R) 6975P-B 128-Core Processor', vendor: 'Intel', series: 'Xeon 6 Granite Rapids', clockHint: '3.9 GHz Turbo', arch: 'P-Core' },
  { model: 'Intel(R) Xeon(R) Platinum 8592+', vendor: 'Intel', series: 'Xeon 5th Gen', clockHint: '3.9 GHz Turbo', arch: 'Emerald Rapids' },
  { model: 'Intel(R) Xeon(R) Platinum 8480+', vendor: 'Intel', series: 'Xeon 4th Gen', clockHint: '3.8 GHz Turbo', arch: 'Sapphire Rapids' },
  { model: 'Intel(R) Xeon(R) Gold 6430', vendor: 'Intel', series: 'Xeon 4th Gen', clockHint: '3.4 GHz Turbo', arch: 'Sapphire Rapids' },
  { model: 'Intel(R) Xeon(R) Gold 6338', vendor: 'Intel', series: 'Xeon 3rd Gen', clockHint: '3.2 GHz Turbo', arch: 'Ice Lake' },
  { model: 'Intel(R) Xeon(R) Silver 4416+', vendor: 'Intel', series: 'Xeon 4th Gen', clockHint: '3.9 GHz Turbo', arch: 'Sapphire Rapids' },
  // Intel Core High-Clock
  { model: 'Intel(R) Core(TM) i9-14900K', vendor: 'Intel', series: 'Core 14th Gen', clockHint: '6.0 GHz Turbo', arch: 'Raptor Lake-R' },
  { model: 'Intel(R) Core(TM) i9-13900K', vendor: 'Intel', series: 'Core 13th Gen', clockHint: '5.8 GHz Turbo', arch: 'Raptor Lake' },
  { model: 'Intel(R) Core(TM) i7-14700K', vendor: 'Intel', series: 'Core 14th Gen', clockHint: '5.6 GHz Turbo', arch: 'Raptor Lake-R' },
];

export const CPU_MODEL_PRESETS: string[] = CPU_MODEL_CATALOG.map((c) => c.model);

export const OS_CATALOG: OsOption[] = [
  {
    id: 'ubuntu-24.04',
    label: 'Ubuntu 24.04 LTS',
    prettyName: 'Ubuntu 24.04.2 LTS',
    family: 'ubuntu',
    versionId: '24.04',
    codename: 'noble',
    ociImage: 'ubuntu:24.04',
    kernelLabel: '6.8.0-49-generic',
    description: 'Noble Numbat long-term support server image with modern APT repositories.',
  },
  {
    id: 'ubuntu-22.04',
    label: 'Ubuntu 22.04 LTS',
    prettyName: 'Ubuntu 22.04.5 LTS',
    family: 'ubuntu',
    versionId: '22.04',
    codename: 'jammy',
    ociImage: 'ubuntu:22.04',
    kernelLabel: '6.8.0-49-generic',
    description: 'Jammy Jellyfish battle-tested LTS server environment.',
  },
  {
    id: 'debian-13',
    label: 'Debian 13',
    prettyName: 'Debian GNU/Linux 13 (trixie)',
    family: 'debian',
    versionId: '13',
    codename: 'trixie',
    ociImage: 'debian:13',
    kernelLabel: '6.1.0-28-amd64',
    description: 'Next-generation Debian 13 Trixie minimal server footprint.',
  },
  {
    id: 'debian-12',
    label: 'Debian 12',
    prettyName: 'Debian GNU/Linux 12 (bookworm)',
    family: 'debian',
    versionId: '12',
    codename: 'bookworm',
    ociImage: 'debian:12',
    kernelLabel: '6.1.0-28-amd64',
    description: 'Stable Debian 12 Bookworm minimal Linux environment.',
  },
  {
    id: 'proxmox-9',
    label: 'Proxmox VE 9',
    prettyName: 'Proxmox VE 9 (Debian 13 Trixie)',
    family: 'proxmox',
    versionId: '9',
    codename: 'trixie',
    ociImage: 'debian:13',
    kernelLabel: '6.14.8-2-pve',
    description: 'Real Proxmox VE 9 identity with PVE 9 kernel, pveversion, and orange X-logo screenfetch.',
  },
  {
    id: 'proxmox-8',
    label: 'Proxmox VE 8',
    prettyName: 'Proxmox VE 8.3 (Debian 12 Bookworm)',
    family: 'proxmox',
    versionId: '8',
    codename: 'bookworm',
    ociImage: 'debian:12',
    kernelLabel: '6.8.12-4-pve',
    description: 'Enterprise Proxmox VE 8.3 (Bookworm) with PVE 8 kernel and orange X-logo screenfetch.',
  },
];

export function getOsOption(osId?: string): OsOption {
  const found = OS_CATALOG.find((item) => item.id === osId);
  return found ?? OS_CATALOG[0];
}

export type VpsStatus =
  | 'running'
  | 'stopped'
  | 'paused'
  | 'provisioning'
  | 'rebooting'
  | 'error';

export type HostRuntimeTier =
  | 'tcg'
  | 'kvm'
  | 'lxc'
  | 'docker'
  | 'native-chroot'
  | 'python-sandbox'
  | 'java-sandbox'
  | 'proot'
  | 'node-workspace' | 'unavailable';

export interface PublicSshTunnel {
  active: boolean;
  provider: 'pinggy' | 'bore';
  host: string;
  port: number;
  command: string;
  startedAt: string;
  error?: string;
}

export interface SshxSession {
  active: boolean;
  url: string;
  startedAt: string;
  error?: string;
}

export interface VpsInstance {
  id: string;
  ownerId: string;
  ownerEmail?: string;
  vmid: number;
  name: string;
  hostname: string;
  osId: OsId;
  status: VpsStatus;
  vcpu: number;
  ramMb: number;
  diskGb: number;
  cpuModel: string;
  ipAddress: string;
  rootPassword: string;
  localSshPort: number;
  nodeName: string;
  runtimeTier: HostRuntimeTier;
  createdAt: string;
  updatedAt: string;
  expiresAt?: string;
  uptimeStartedAt?: string;
  publicSsh?: PublicSshTunnel | null;
  sshxSession?: SshxSession | null;
  cpuUsagePct?: number;
  ramUsedMb?: number;
  diskUsedMb?: number;
  metricsSampledAt?: string;
  netRxKb?: number;
  netTxKb?: number;
}

export interface HostDiagnostics {
  hostHostname: string;
  hostCpuCount: number;
  hostTotalRamMb: number;
  hostFreeRamMb: number;
  hostUptimeSec: number;
  platform: string;
  arch: string;
  runtimeTier: HostRuntimeTier;
  nativeRootfsSupported: boolean;
  activeTunnels: number;
  runningVpsCount: number;
  totalVpsCount: number;
}

export interface CloudflareTunnel {
  id: string;
  ownerId: string;
  vpsId: string;
  name: string;
  hostname: string;
  localPort: number;
  protocol: 'http' | 'https' | 'tcp';
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface TeamMember {
  id: string;
  ownerId: string;
  email: string;
  displayName: string;
  role: 'admin' | 'operator' | 'viewer';
  createdAt: string;
  updatedAt: string;
}

export interface MemberAccount {
  id: string;
  username: string;
  displayName: string;
  email: string;
  role: 'member';
  active: boolean;
  maxVps: number;
  maxVcpu: number;
  maxRamMb: number;
  maxDiskGb: number;
  createdAt: string;
  updatedAt: string;
}

export interface AuthSessionUser {
  uid: string;
  username: string;
  displayName: string;
  email: string;
  role: 'admin' | 'member';
  isAdmin: boolean;
  authMode: 'admin-password' | 'member-password' | 'firebase-google';
  quotas?: {
    maxVps: number;
    maxVcpu: number;
    maxRamMb: number;
    maxDiskGb: number;
  };
}

export interface ClusterTaskLog {
  id: string;
  vmid: number;
  vmName: string;
  action: string;
  status: 'ok' | 'running' | 'error';
  message: string;
  timestamp: string;
}

export interface CreateVpsPayload {
  name: string;
  hostname?: string;
  osId: OsId;
  vcpu: number;
  ramMb: number;
  diskGb: number;
  cpuModel?: string;
  rootPassword?: string;
  nodeName?: string;
  assignToEmail?: string;
  expiresAt?: string;
}

export interface ResizeVpsPayload {
  vcpu: number;
  ramMb: number;
  diskGb: number;
  cpuModel?: string;
}
