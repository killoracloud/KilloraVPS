import crypto from 'crypto';
import type { Request, Response, NextFunction } from 'express';
import fs from 'fs';
import path from 'path';
import type { AuthSessionUser, MemberAccount } from '../types/vps.ts';

export interface AuthenticatedUser {
  uid: string;
  username: string;
  displayName: string;
  email: string;
  emailVerified: boolean;
  isAdmin: boolean;
  authMode: 'admin-password' | 'member-password' | 'firebase-google';
  quotas?: {
    maxVps: number;
    maxVcpu: number;
    maxRamMb: number;
    maxDiskGb: number;
  };
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthenticatedUser;
    }
  }
}

interface StoredMemberRecord extends MemberAccount {
  passwordHash: string;
}

interface AuthStoreData {
  adminUsername: string;
  adminEmail: string;
  adminPasswordHash: string | null;
  members: StoredMemberRecord[];
}

const DATA_ROOT = path.resolve(process.cwd(), '.killoracloud-data');
const AUTH_STORE_FILE = path.join(DATA_ROOT, 'auth-store.json');
const SESSION_KEY_FILE = path.join(DATA_ROOT, 'session-secret.key');
const DEFAULT_ADMIN_EMAIL = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const CERT_URL =
  'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';

function getOrCreatePersistentSessionSecret(): string {
  if (process.env.SESSION_SECRET && process.env.SESSION_SECRET.trim().length >= 16) {
    return process.env.SESSION_SECRET.trim();
  }
  try {
    fs.mkdirSync(DATA_ROOT, { recursive: true, mode: 0o755 });
    if (fs.existsSync(SESSION_KEY_FILE)) {
      const existing = fs.readFileSync(SESSION_KEY_FILE, 'utf8').trim();
      if (existing.length >= 32) return existing;
    }
    const generated = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(SESSION_KEY_FILE, generated, { mode: 0o600 });
    return generated;
  } catch {
    throw new Error('Cannot initialize persistent session secret');
  }
}

const SESSION_SECRET = getOrCreatePersistentSessionSecret();

let cachedCerts: Record<string, string> = {};
let certsExpireAt = 0;

function getEnvAdminConfig(): {
  email: string;
  username: string;
  password: string;
  hasEnvPassword: boolean;
} {
  const password = (process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSCODE || '').trim();
  const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const username = (process.env.ADMIN_USERNAME || '').trim().toLowerCase();
  return {
    email,
    username,
    password,
    hasEnvPassword: password.length > 0,
  };
}

function ensureAuthDir(): void {
  fs.mkdirSync(DATA_ROOT, { recursive: true, mode: 0o755 });
}

function loadAuthStore(): AuthStoreData {
  ensureAuthDir();
  if (!fs.existsSync(AUTH_STORE_FILE)) {
    return {
      adminUsername: 'admin',
      adminEmail: DEFAULT_ADMIN_EMAIL,
      adminPasswordHash: null,
      members: [],
    };
  }
  try {
    const parsed = JSON.parse(fs.readFileSync(AUTH_STORE_FILE, 'utf8')) as Partial<AuthStoreData>;
    const rawMembers = Array.isArray(parsed.members) ? parsed.members : [];
    const normalizedMembers: StoredMemberRecord[] = rawMembers
      .filter((m): m is StoredMemberRecord => Boolean(m && typeof m === 'object'))
      .map((m) => ({
        ...m,
        id: String(m.id || `mem-${crypto.randomBytes(4).toString('hex')}`),
        username: String(m.username || (m.email ? m.email.split('@')[0] : 'member')).toLowerCase(),
        email: String(m.email || `${m.username || 'member'}@gmail.com`).toLowerCase(),
        role: 'member',
      }));
    return {
      adminUsername: (parsed.adminUsername || 'admin').toLowerCase(),
      adminEmail: (parsed.adminEmail || DEFAULT_ADMIN_EMAIL).toLowerCase(),
      adminPasswordHash: parsed.adminPasswordHash ?? null,
      members: normalizedMembers,
    };
  } catch {
    return {
      adminUsername: 'admin',
      adminEmail: DEFAULT_ADMIN_EMAIL,
      adminPasswordHash: null,
      members: [],
    };
  }
}

function saveAuthStore(data: AuthStoreData): void {
  ensureAuthDir();
  fs.writeFileSync(AUTH_STORE_FILE, JSON.stringify(data, null, 2), { mode: 0o600 });
}

export function getEffectiveAdminIdentity(): { username: string; email: string } {
  const envCfg = getEnvAdminConfig();
  const store = loadAuthStore();
  return {
    username: envCfg.username || store.adminUsername || 'admin',
    email: envCfg.email || store.adminEmail || DEFAULT_ADMIN_EMAIL,
  };
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const [, salt, keyHex] = parts;
  const expected = Buffer.from(keyHex, 'hex');
  const actual = crypto.scryptSync(password, salt, 64);
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}

function safeTimingEqual(aStr: string, bStr: string): boolean {
  const a = Buffer.from(aStr, 'utf8');
  const b = Buffer.from(bStr, 'utf8');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export function getAuthSetupStatus(): {
  adminConfigured: boolean;
  usesEnvPasscode: boolean;
  adminUsername: string;
  adminEmail: string;
  memberCount: number;
} {
  const envCfg = getEnvAdminConfig();
  const store = loadAuthStore();
  const identity = getEffectiveAdminIdentity();
  return {
    adminConfigured: Boolean(envCfg.hasEnvPassword || store.adminPasswordHash),
    usesEnvPasscode: envCfg.hasEnvPassword,
    adminUsername: identity.username,
    adminEmail: identity.email,
    memberCount: store.members.length,
  };
}

export function claimFirstRunAdminPassword(
  username: string,
  password: string,
  email?: string
): { token: string; user: AuthSessionUser } {
  const envCfg = getEnvAdminConfig();
  if (envCfg.hasEnvPassword) {
    throw new Error('Admin account is locked to server .env credentials (ADMIN_EMAIL / ADMIN_USERNAME / ADMIN_PASSWORD).');
  }
  const store = loadAuthStore();
  if (store.adminPasswordHash) {
    throw new Error('Admin account is already configured. Please sign in with your username or Gmail and password.');
  }
  const cleanUser =
    username.trim().toLowerCase().replace(/[^a-z0-9._-]/g, '').slice(0, 40) || 'admin';
  const cleanEmail =
    (email || envCfg.email || DEFAULT_ADMIN_EMAIL).trim().toLowerCase().slice(0, 160);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    throw new Error('Please enter a valid Admin Gmail address.');
  }
  if (password.length < 12) {
    throw new Error('Admin password must be at least 12 characters.');
  }
  store.adminUsername = cleanUser;
  store.adminEmail = cleanEmail;
  store.adminPasswordHash = hashPassword(password);
  saveAuthStore(store);

  const sessionUser: AuthSessionUser = {
    uid: 'admin-root',
    username: cleanUser,
    displayName: 'Panel Administrator',
    email: cleanEmail,
    role: 'admin',
    isAdmin: true,
    authMode: 'admin-password',
  };
  return { token: signSessionToken(sessionUser), user: sessionUser };
}

function buildAdminSession(): { token: string; user: AuthSessionUser } {
  const identity = getEffectiveAdminIdentity();
  const sessionUser: AuthSessionUser = {
    uid: 'admin-root',
    username: identity.username,
    displayName: 'Panel Administrator',
    email: identity.email,
    role: 'admin',
    isAdmin: true,
    authMode: 'admin-password',
  };
  return { token: signSessionToken(sessionUser), user: sessionUser };
}

function buildMemberSession(found: StoredMemberRecord): { token: string; user: AuthSessionUser } {
  const sessionUser: AuthSessionUser = {
    uid: found.id,
    username: found.username,
    displayName: found.displayName,
    email: found.email,
    role: 'member',
    isAdmin: false,
    authMode: 'member-password',
    quotas: {
      maxVps: found.maxVps,
      maxVcpu: found.maxVcpu,
      maxRamMb: found.maxRamMb,
      maxDiskGb: found.maxDiskGb,
    },
  };
  return { token: signSessionToken(sessionUser), user: sessionUser };
}

/**
 * Unified single login for both the single .env Admin and Admin-created Members.
 * Entering the single Admin username or Gmail + Admin password opens the Admin Panel.
 * Entering a Member's username or Gmail + Member password opens their Member Panel.
 */
export function authenticateUnifiedLogin(
  identifier: string,
  password: string
): { token: string; user: AuthSessionUser } {
  const normalized = (identifier || '').trim().toLowerCase();
  if (!normalized || !password) {
    throw new Error('Enter your username or Gmail and password.');
  }

  const envCfg = getEnvAdminConfig();
  const store = loadAuthStore();
  const adminIdentity = getEffectiveAdminIdentity();

  const matchesAdminId =
    normalized === adminIdentity.username.toLowerCase() ||
    normalized === adminIdentity.email.toLowerCase();

  // 1. Check the single Admin account first
  if (matchesAdminId) {
    if (envCfg.hasEnvPassword) {
      if (safeTimingEqual(envCfg.password, password)) {
        return buildAdminSession();
      }
      throw new Error('Invalid username/Gmail or password.');
    }
    if (store.adminPasswordHash) {
      if (verifyPassword(password, store.adminPasswordHash)) {
        return buildAdminSession();
      }
      throw new Error('Invalid username/Gmail or password.');
    }
    throw new Error('Admin password has not been set up yet. Set ADMIN_PASSWORD in .env or complete first-time setup.');
  }

  // 2. Check Member accounts by username OR Gmail
  const membersList = Array.isArray(store.members) ? store.members : [];
  const found = membersList.find(
    (m) =>
      m &&
      ((m.username && m.username.toLowerCase() === normalized) ||
        (m.email && m.email.toLowerCase() === normalized))
  );
  if (!found || !verifyPassword(password, found.passwordHash)) {
    throw new Error('Invalid username/Gmail or password.');
  }
  if (!found.active) {
    throw new Error('This member account has been suspended by the administrator.');
  }

  return buildMemberSession(found);
}

// Keep backward-compatible wrappers
export function authenticateAdminPassword(
  username: string,
  password: string
): { token: string; user: AuthSessionUser } {
  const res = authenticateUnifiedLogin(username, password);
  if (!res.user.isAdmin) {
    throw new Error('Invalid admin credentials');
  }
  return res;
}

export function authenticateMemberPassword(
  username: string,
  password: string
): { token: string; user: AuthSessionUser } {
  return authenticateUnifiedLogin(username, password);
}

function toPublicMember(rec: StoredMemberRecord): MemberAccount {
  const { passwordHash: _omit, ...rest } = rec;
  return { ...rest, role: 'member' };
}

export function listMemberAccounts(): MemberAccount[] {
  const store = loadAuthStore();
  return store.members.map(toPublicMember);
}

export function findMemberByEmailOrId(query: string): MemberAccount | null {
  const clean = query.trim().toLowerCase();
  if (!clean) return null;
  const store = loadAuthStore();
  const membersList = Array.isArray(store.members) ? store.members : [];
  const found = membersList.find(
    (m) =>
      m &&
      ((m.id && m.id.toLowerCase() === clean) ||
        (m.email && m.email.toLowerCase() === clean) ||
        (m.username && m.username.toLowerCase() === clean))
  );
  return found ? toPublicMember(found) : null;
}

export function createMemberAccount(input: {
  username?: string;
  password: string;
  displayName?: string;
  email: string;
  maxVps?: number;
  maxVcpu?: number;
  maxRamMb?: number;
  maxDiskGb?: number;
}): MemberAccount {
  const store = loadAuthStore();
  const adminIdentity = getEffectiveAdminIdentity();

  const email = (input.email || '').trim().toLowerCase().slice(0, 160);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error('A valid Member Gmail address is required (e.g. member@gmail.com).');
  }
  if (email === adminIdentity.email.toLowerCase()) {
    throw new Error('This Gmail belongs to the single Panel Administrator.');
  }
  if (store.members.some((m) => m.email.toLowerCase() === email)) {
    throw new Error(`A member account with Gmail "${email}" already exists.`);
  }

  const rawUsername = (input.username && input.username.trim()) || email.split('@')[0] || '';
  const username = rawUsername
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]/g, '')
    .slice(0, 40);
  if (!username || username.length < 3) {
    throw new Error('Username must be at least 3 alphanumeric characters.');
  }
  if (username === adminIdentity.username.toLowerCase()) {
    throw new Error(`Username "${username}" is reserved for the Panel Administrator.`);
  }
  if (store.members.some((m) => m.username.toLowerCase() === username)) {
    throw new Error(`Member username "${username}" already exists.`);
  }
  if (!input.password || input.password.length < 12) {
    throw new Error('Password must be at least 12 characters.');
  }

  const now = new Date().toISOString();
  const rec: StoredMemberRecord = {
    id: `mem-${crypto.randomBytes(5).toString('hex')}`,
    username,
    displayName: (input.displayName || username).trim().slice(0, 80),
    email,
    role: 'member', // Strictly member — only 1 Admin exists (.env)
    active: true,
    maxVps: Math.max(1, Math.round(Number(input.maxVps) || 5)),
    maxVcpu: Math.max(1, Math.round(Number(input.maxVcpu) || 32)),
    maxRamMb: Math.max(512, Math.round(Number(input.maxRamMb) || 32768)),
    maxDiskGb: Math.max(1, Math.round(Number(input.maxDiskGb) || 500)),
    passwordHash: hashPassword(input.password),
    createdAt: now,
    updatedAt: now,
  };

  store.members.unshift(rec);
  saveAuthStore(store);
  return toPublicMember(rec);
}

export function updateMemberAccount(
  memberId: string,
  updates: Partial<{
    displayName: string;
    email: string;
    password: string;
    active: boolean;
    maxVps: number;
    maxVcpu: number;
    maxRamMb: number;
    maxDiskGb: number;
  }>
): MemberAccount {
  const store = loadAuthStore();
  const adminIdentity = getEffectiveAdminIdentity();
  const rec = store.members.find((m) => m.id === memberId);
  if (!rec) throw new Error('Member account not found');

  if (typeof updates.displayName === 'string' && updates.displayName.trim()) {
    rec.displayName = updates.displayName.trim().slice(0, 80);
  }
  if (typeof updates.email === 'string' && updates.email.trim()) {
    const nextEmail = updates.email.trim().toLowerCase().slice(0, 160);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(nextEmail)) {
      throw new Error('Invalid member Gmail address');
    }
    if (nextEmail === adminIdentity.email.toLowerCase()) {
      throw new Error('Cannot use the Admin Gmail for a member account');
    }
    if (store.members.some((m) => m.id !== rec.id && m.email.toLowerCase() === nextEmail)) {
      throw new Error(`Gmail "${nextEmail}" is already assigned to another member`);
    }
    rec.email = nextEmail;
  }
  if (typeof updates.password === 'string' && updates.password.length > 0) {
    if (updates.password.trim().length < 12) throw Error('Password must be at least 12 characters');
    rec.passwordHash = hashPassword(updates.password.trim());
  }
  rec.role = 'member';
  if (typeof updates.active === 'boolean') {
    rec.active = updates.active;
  }
  if (typeof updates.maxVps === 'number') {
    rec.maxVps = Math.max(1, Math.round(updates.maxVps));
  }
  if (typeof updates.maxVcpu === 'number') {
    rec.maxVcpu = Math.max(1, Math.round(updates.maxVcpu));
  }
  if (typeof updates.maxRamMb === 'number') {
    rec.maxRamMb = Math.max(512, Math.round(updates.maxRamMb));
  }
  if (typeof updates.maxDiskGb === 'number') {
    rec.maxDiskGb = Math.max(1, Math.round(updates.maxDiskGb));
  }
  rec.updatedAt = new Date().toISOString();
  saveAuthStore(store);
  return toPublicMember(rec);
}

export function deleteMemberAccount(memberId: string): void {
  const store = loadAuthStore();
  store.members = store.members.filter((m) => m.id !== memberId);
  saveAuthStore(store);
}

// HMAC-SHA256 Session Tokens (prefixed with "kc.")
function encodeB64Url(buf: Buffer | string): string {
  return Buffer.from(buf)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

function decodeBase64Url(input: string): Buffer {
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  const padLen = (4 - (normalized.length % 4)) % 4;
  return Buffer.from(normalized + '='.repeat(padLen), 'base64');
}

export function credentialVersion(uid: string): string {
  const store = loadAuthStore();
  const value = uid === 'admin-root' ? (getEnvAdminConfig().password || store.adminPasswordHash || '') : (() => { const m = store.members.find(x => x.id === uid); return m ? JSON.stringify([m.passwordHash,m.active,m.updatedAt]) : 'missing'; })();
  return crypto.createHmac('sha256', SESSION_SECRET).update(value).digest('hex');
}

export function signSessionToken(user: AuthSessionUser): string {
  const payload = {
    ...user,
    credentialVersion: credentialVersion(user.uid),
    exp: Math.floor(Date.now() / 1000) + 60 * 60 * 8, // eight-hour session
  };
  const body = encodeB64Url(JSON.stringify(payload));
  const sig = encodeB64Url(
    crypto.createHmac('sha256', SESSION_SECRET).update(body).digest()
  );
  return `kc.${body}.${sig}`;
}

export function verifyLocalSessionToken(token: string): AuthenticatedUser {
  const parts = token.split('.');
  if (parts.length !== 3 || parts[0] !== 'kc') {
    throw new Error('Invalid session token');
  }
  const [, body, sig] = parts;
  const expectedSig = encodeB64Url(
    crypto.createHmac('sha256', SESSION_SECRET).update(body).digest()
  );
  if (!safeTimingEqual(sig, expectedSig)) {
    throw new Error('Invalid session signature');
  }
  const payload = JSON.parse(decodeBase64Url(body).toString('utf8')) as AuthSessionUser & {
    exp?: number;
    credentialVersion?: string;
  };
  if (payload.credentialVersion !== credentialVersion(payload.uid)) throw Error("Session revoked");
  if (!payload.exp || payload.exp <= Math.floor(Date.now() / 1000)) {
    throw new Error('Session expired');
  }

  // Re-verify active status & fresh quotas for member sessions
  if (payload.authMode === 'member-password') {
    const store = loadAuthStore();
    const membersList = Array.isArray(store.members) ? store.members : [];
    const member = membersList.find((m) => m && m.id === payload.uid);
    if (!member || !member.active) {
      throw new Error('Member account is no longer active');
    }
    return {
      uid: member.id,
      username: member.username,
      displayName: member.displayName,
      email: member.email,
      emailVerified: true,
      isAdmin: false,
      authMode: 'member-password',
      quotas: {
        maxVps: member.maxVps,
        maxVcpu: member.maxVcpu,
        maxRamMb: member.maxRamMb,
        maxDiskGb: member.maxDiskGb,
      },
    };
  }

  const adminIdentity = getEffectiveAdminIdentity();
  return {
    uid: 'admin-root',
    username: adminIdentity.username,
    displayName: 'Panel Administrator',
    email: adminIdentity.email,
    emailVerified: true,
    isAdmin: true,
    authMode: 'admin-password',
  };
}

function getFirebaseProjectId(): string {
  try {
    const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    if (fs.existsSync(configPath)) {
      const parsed = JSON.parse(fs.readFileSync(configPath, 'utf8')) as { projectId?: string };
      if (parsed.projectId) return parsed.projectId;
    }
  } catch {
    // ignore
  }
  return 'neon-equator-cwjrd';
}

async function fetchGooglePublicCerts(): Promise<Record<string, string>> {
  const now = Date.now();
  if (Object.keys(cachedCerts).length > 0 && now < certsExpireAt) {
    return cachedCerts;
  }

  const res = await fetch(CERT_URL);
  if (!res.ok) {
    throw new Error(`Failed to fetch Firebase public keys (${res.status})`);
  }
  const cacheControl = res.headers.get('cache-control') || '';
  const maxAgeMatch = cacheControl.match(/max-age=(\d+)/i);
  const maxAgeSec = maxAgeMatch ? Math.max(60, parseInt(maxAgeMatch[1], 10)) : 3600;
  cachedCerts = (await res.json()) as Record<string, string>;
  certsExpireAt = now + maxAgeSec * 1000;
  return cachedCerts;
}

export async function verifyFirebaseIdToken(token: string): Promise<AuthenticatedUser> {
  const parts = token.split('.');
  if (parts.length !== 3) {
    throw new Error('Malformed bearer token');
  }

  const [headerB64, payloadB64, signatureB64] = parts;
  const header = JSON.parse(decodeBase64Url(headerB64).toString('utf8')) as {
    alg?: string;
    kid?: string;
  };
  const payload = JSON.parse(decodeBase64Url(payloadB64).toString('utf8')) as {
    aud?: string;
    iss?: string;
    sub?: string;
    name?: string;
    email?: string;
    email_verified?: boolean;
    exp?: number;
  };

  if (header.alg !== 'RS256' || !header.kid) {
    throw new Error('Unsupported JWT algorithm');
  }

  const projectId = getFirebaseProjectId();
  const expectedIssuer = `https://securetoken.google.com/${projectId}`;
  const nowSec = Math.floor(Date.now() / 1000);

  if (payload.aud !== projectId) throw new Error('Invalid token audience');
  if (payload.iss !== expectedIssuer) throw new Error('Invalid token issuer');
  if (!payload.exp || payload.exp <= nowSec) throw new Error('Token expired');
  if (!payload.sub || typeof payload.sub !== 'string') throw new Error('Missing subject');

  const certs = await fetchGooglePublicCerts();
  let certPem = certs[header.kid];
  if (!certPem) {
    certsExpireAt = 0;
    const refreshed = await fetchGooglePublicCerts();
    certPem = refreshed[header.kid];
  }
  if (!certPem) throw new Error('Unknown signing key');

  const signingInput = Buffer.from(`${headerB64}.${payloadB64}`, 'utf8');
  const signature = decodeBase64Url(signatureB64);
  if (!crypto.verify('RSA-SHA256', signingInput, certPem, signature)) {
    throw new Error('Invalid token signature');
  }

  const email = (payload.email || '').toLowerCase();
  const emailVerified = Boolean(payload.email_verified);
  const adminIdentity = getEffectiveAdminIdentity();
  const isAdmin = emailVerified && !!adminIdentity.email && email === adminIdentity.email.toLowerCase();

  return {
    uid: payload.sub,
    username: email.split('@')[0] || 'user',
    displayName: payload.name || email.split('@')[0] || 'User',
    email,
    emailVerified,
    isAdmin,
    authMode: 'firebase-google',
  };
}

function extractCookieToken(cookieHeader: string | undefined): string {
  if (!cookieHeader) return '';
  for (const part of cookieHeader.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === 'kc_session') {
      try {
        return decodeURIComponent(v.join('=')).trim();
      } catch {
        return v.join('=').trim();
      }
    }
  }
  return '';
}

export async function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  const authHeader = req.headers.authorization || '';
  const bearerToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  const cookieToken = extractCookieToken(req.headers.cookie);
  const token = bearerToken || cookieToken;

  if (!token) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  try {
    if (token.startsWith('kc.')) {
      req.user = verifyLocalSessionToken(token);
    } else {
      req.user = await verifyFirebaseIdToken(token);
    }
    next();
  } catch (err) {
    res.status(401).json({
      error: err instanceof Error ? err.message : 'Invalid or expired authentication token',
    });
  }
}

export function requireAdmin(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  if (!req.user?.isAdmin) {
    res.status(403).json({ error: 'Administrator permission required' });
    return;
  }
  next();
}

// Short-lived in-memory signed tickets for WebSocket console connections
interface WsTicketEntry {
  vpsId: string;
  uid: string;
  email: string;
  isAdmin: boolean;
  expiresAt: number;
  version: string;
}

const wsTickets = new Map<string, WsTicketEntry>();

export function issueWsTicket(vpsId: string, user: AuthenticatedUser): string {
  const now = Date.now();
  for (const [k, entry] of wsTickets.entries()) {
    if (entry.expiresAt < now) wsTickets.delete(k);
  }
  const ticket = crypto.randomBytes(24).toString('hex');
  wsTickets.set(ticket, {
    vpsId,
    uid: user.uid,
    email: user.email,
    isAdmin: user.isAdmin,
    expiresAt: now + 60_000,
    version: credentialVersion(user.uid),
  });
  return ticket;
}

export function consumeWsTicket(ticket: string, vpsId: string): WsTicketEntry | null {
  const entry = wsTickets.get(ticket);
  if (!entry) return null;
  wsTickets.delete(ticket);
  if (entry.expiresAt < Date.now() || entry.vpsId !== vpsId || entry.version !== credentialVersion(entry.uid)) {
    return null;
  }
  return entry;
}
