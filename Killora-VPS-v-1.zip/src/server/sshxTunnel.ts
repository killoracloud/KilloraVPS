import type {ChildProcess} from 'node:child_process';
import type {SshxSession} from '../types/vps.ts';
const sessions=new Map<string,{proc:ChildProcess,info:SshxSession,stop:()=>void}>();
const pending=new Set<string>();
const cancellations=new Map<string,()=>void>();
export function getSshxSession(id:string){return sessions.get(id)?.info??null;}
export function stopSshxSession(id:string){cancellations.get(id)?.();const s=sessions.get(id);if(s){sessions.delete(id);s.stop();s.proc.kill();}}
export function stopAllSshxSessions(){for(const id of new Set([...sessions.keys(),...pending]))stopSshxSession(id);}
export async function startGuestSshx(id:string,launch:()=>ChildProcess,stop:()=>void):Promise<SshxSession>{
 const old=getSshxSession(id);if(old)return old;if(pending.has(id))throw Error('SSHX starting');pending.add(id);
 try{return await new Promise((resolve,reject)=>{const proc=launch();let output='',settled=false;const fail=()=>{if(settled)return;settled=true;clearTimeout(timer);stop();proc.kill();reject(Error('Guest SSHX failed to start'));};const timer=setTimeout(fail,20000);cancellations.set(id,fail);
 const read=(d:Buffer)=>{if(settled)return;output=(output+d.toString()).slice(-8192);const m=output.match(/https:\/\/sshx\.io\/s\/[A-Za-z0-9_-]+(?:#[A-Za-z0-9_-]+)?/);if(m){settled=true;clearTimeout(timer);const info={active:true,url:m[0],startedAt:new Date().toISOString()};sessions.set(id,{proc,info,stop});resolve(info);}};
 proc.stdout?.on('data',read);proc.stderr?.on('data',read);proc.on('error',fail);proc.on('close',()=>{if(sessions.get(id)?.proc===proc)sessions.delete(id);fail();});});}finally{pending.delete(id);cancellations.delete(id);}
}
