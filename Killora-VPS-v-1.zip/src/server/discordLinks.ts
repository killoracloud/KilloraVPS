import fs from 'fs';
import path from 'path';

export interface DiscordLinkRecord {
  discordUserId: string;
  discordTag: string;
  panelEmail: string;
  linkedAt: string;
}

const DATA_ROOT = path.resolve(process.cwd(), '.killoracloud-data');
const LINKS_FILE = path.join(DATA_ROOT, 'discord-links.json');

function ensureDir(): void {
  fs.mkdirSync(DATA_ROOT, { recursive: true, mode: 0o755 });
}

export function loadDiscordLinks(): DiscordLinkRecord[] {
  try {
    ensureDir();
    if (fs.existsSync(LINKS_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(LINKS_FILE, 'utf8'));
      return Array.isArray(parsed) ? parsed : [];
    }
  } catch {
    // ignore
  }
  return [];
}

export function saveDiscordLinks(links: DiscordLinkRecord[]): void {
  try {
    ensureDir();
    fs.writeFileSync(LINKS_FILE, JSON.stringify(links, null, 2), 'utf8');
  } catch {
    // ignore
  }
}

export function getLinkedEmailForDiscord(discordUserId: string): string | null {
  const links = loadDiscordLinks();
  const found = links.find((l) => l.discordUserId === discordUserId);
  return found ? found.panelEmail : null;
}

export function linkDiscordUser(discordUserId: string, discordTag: string, panelEmail: string): void {
  const links = loadDiscordLinks();
  const normalizedEmail = panelEmail.trim().toLowerCase();
  const index = links.findIndex((l) => l.discordUserId === discordUserId);
  if (index >= 0) {
    links[index] = {
      discordUserId,
      discordTag,
      panelEmail: normalizedEmail,
      linkedAt: new Date().toISOString(),
    };
  } else {
    links.push({
      discordUserId,
      discordTag,
      panelEmail: normalizedEmail,
      linkedAt: new Date().toISOString(),
    });
  }
  saveDiscordLinks(links);
}
