import net from 'net';
import { Client as SshClient, type ClientChannel } from 'ssh2';
import type { PublicSshTunnel } from '../types/vps.ts';

interface ActiveTunnelHandle {
  vpsId: string;
  info: PublicSshTunnel;
  close: () => void;
}

const activeTunnels = new Map<string, ActiveTunnelHandle>();

export function getPublicSshTunnel(vpsId: string): PublicSshTunnel | null {
  return activeTunnels.get(vpsId)?.info ?? null;
}

export function getActiveTunnelCount(): number {
  return activeTunnels.size;
}

export function stopPublicSshTunnel(vpsId: string): void {
  const existing = activeTunnels.get(vpsId);
  if (!existing) return;
  activeTunnels.delete(vpsId);
  try {
    existing.close();
  } catch {
    // ignore cleanup error
  }
}

export function stopAllPublicSshTunnels(): void {
  for (const vpsId of Array.from(activeTunnels.keys())) {
    stopPublicSshTunnel(vpsId);
  }
}

function stripAnsi(input: string): string {
  return input.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, '');
}

/**
 * Connects directly to Pinggy (`free.pinggy.io:443` or `a.pinggy.io:443`) via pure Node.js `ssh2`.
 * Avoids host `/usr/bin/ssh` dependency and avoids `BatchMode=yes` permission-denied errors by
 * properly completing empty password / keyboard-interactive authentication.
 */
function connectPinggyViaSsh2(
  vpsId: string,
  pinggyHost: string,
  localSshPort: number,
  timeoutMs = 12000
): Promise<ActiveTunnelHandle> {
  return new Promise((resolve, reject) => {
    const conn = new SshClient();
    let settled = false;
    let shellStream: ClientChannel | null = null;
    let outputBuffer = '';

    const fail = (err: Error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try {
        conn.end();
      } catch {
        // ignore
      }
      reject(err);
    };

    const timer = setTimeout(() => {
      fail(new Error(`Timed out waiting for ${pinggyHost} to allocate a public TCP address`));
    }, timeoutMs);

    conn.on('keyboard-interactive', (_name, _instructions, _lang, prompts, finish) => {
      finish(prompts.map(() => ''));
    });

    conn.on('tcp connection', (_info, accept) => {
      const remoteStream = accept();
      const localSocket = net.connect(localSshPort, '127.0.0.1');

      remoteStream.pipe(localSocket);
      localSocket.pipe(remoteStream);

      const cleanup = () => {
        remoteStream.destroy();
        localSocket.destroy();
      };
      remoteStream.on('error', cleanup);
      localSocket.on('error', cleanup);
      remoteStream.on('close', () => localSocket.end());
      localSocket.on('close', () => remoteStream.end());
    });

    conn.on('ready', () => {
      conn.forwardIn('0.0.0.0', 0, (fwdErr) => {
        if (fwdErr) {
          fail(new Error(`Pinggy reverse forward failed: ${fwdErr.message}`));
          return;
        }

        conn.shell({ term: 'xterm-256color', cols: 120, rows: 30 }, (shellErr, stream) => {
          if (shellErr) {
            fail(new Error(`Pinggy control shell failed: ${shellErr.message}`));
            return;
          }
          shellStream = stream;

          const inspectOutput = (chunk: Buffer) => {
            outputBuffer += stripAnsi(chunk.toString('utf8'));
            // Pinggy prints: tcp://<host>:<port>
            const match = outputBuffer.match(/tcp:\/\/([a-zA-Z0-9.-]+):(\d{2,5})/);
            if (match && !settled) {
              settled = true;
              clearTimeout(timer);
              const host = match[1];
              const port = Number(match[2]);
              const info: PublicSshTunnel = {
                active: true,
                provider: 'pinggy',
                host,
                port,
                command: `ssh root@${host} -p ${port}`,
                startedAt: new Date().toISOString(),
              };

              const handle: ActiveTunnelHandle = {
                vpsId,
                info,
                close: () => {
                  try {
                    shellStream?.end();
                  } catch {
                    // ignore
                  }
                  try {
                    conn.end();
                  } catch {
                    // ignore
                  }
                },
              };

              conn.on('close', () => {
                if (activeTunnels.get(vpsId) === handle) {
                  activeTunnels.delete(vpsId);
                }
              });

              resolve(handle);
            }
          };

          stream.on('data', inspectOutput);
          stream.stderr?.on('data', inspectOutput);
          stream.on('close', () => {
            if (!settled) {
              fail(
                new Error(
                  `Pinggy (${pinggyHost}) closed before allocating an address: ${outputBuffer
                    .trim()
                    .slice(0, 180)}`
                )
              );
            }
          });
        });
      });
    });

    conn.on('error', (err) => {
      fail(new Error(`Pinggy (${pinggyHost}) SSH error: ${err.message}`));
    });

    conn.on('close', () => {
      if (!settled) {
        fail(new Error(`Pinggy (${pinggyHost}) connection closed before allocation`));
      }
    });

    conn.connect({
      host: pinggyHost,
      port: 443,
      username: 'tcp',
      password: '',
      tryKeyboard: true,
      readyTimeout: timeoutMs,
      keepaliveInterval: 15_000,
      keepaliveCountMax: 4,
      hostVerifier: () => true,
    });
  });
}

/**
 * Pure TCP fallback using `bore.pub:7835` null-delimited JSON protocol:
 *   Client -> {"Hello":0}\0
 *   Server -> {"Hello":<remotePort>}\0
 *   Server -> {"Accept":"<uuid>"}\0  (client opens new socket -> {"Accept":"<uuid>"}\0 and pipes to localhost)
 */
function connectBoreFallback(
  vpsId: string,
  localSshPort: number,
  timeoutMs = 10000
): Promise<ActiveTunnelHandle> {
  return new Promise((resolve, reject) => {
    const boreHost = 'bore.pub';
    const boreControlPort = 7835;
    const controlSocket = net.connect(boreControlPort, boreHost);
    let settled = false;
    let buffer = '';
    const dataSockets = new Set<net.Socket>();

    const fail = (err: Error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      controlSocket.destroy();
      reject(err);
    };

    const timer = setTimeout(() => {
      fail(new Error('Timed out waiting for bore.pub TCP tunnel allocation'));
    }, timeoutMs);

    controlSocket.setKeepAlive(true, 15_000);

    controlSocket.on('connect', () => {
      controlSocket.write('{"Hello":0}\0');
    });

    controlSocket.on('data', (chunk) => {
      buffer += chunk.toString('utf8');
      let nulIdx = buffer.indexOf('\0');
      while (nulIdx !== -1) {
        const rawMsg = buffer.slice(0, nulIdx).trim();
        buffer = buffer.slice(nulIdx + 1);
        nulIdx = buffer.indexOf('\0');
        if (!rawMsg) continue;

        let msg: Record<string, unknown>;
        try {
          msg = JSON.parse(rawMsg) as Record<string, unknown>;
        } catch {
          continue;
        }

        if (typeof msg.Hello === 'number' && !settled) {
          settled = true;
          clearTimeout(timer);
          const remotePort = msg.Hello;
          const info: PublicSshTunnel = {
            active: true,
            provider: 'bore',
            host: boreHost,
            port: remotePort,
            command: `ssh root@${boreHost} -p ${remotePort}`,
            startedAt: new Date().toISOString(),
          };
          const handle: ActiveTunnelHandle = {
            vpsId,
            info,
            close: () => {
              controlSocket.destroy();
              for (const s of dataSockets) {
                s.destroy();
              }
              dataSockets.clear();
            },
          };
          controlSocket.on('close', () => {
            if (activeTunnels.get(vpsId) === handle) {
              activeTunnels.delete(vpsId);
            }
          });
          resolve(handle);
        } else if (typeof msg.Accept === 'string') {
          const uuid = msg.Accept;
          const remoteConn = net.connect(boreControlPort, boreHost);
          const localConn = net.connect(localSshPort, '127.0.0.1');
          dataSockets.add(remoteConn);
          dataSockets.add(localConn);

          remoteConn.on('connect', () => {
            remoteConn.write(`${JSON.stringify({ Accept: uuid })}\0`);
            remoteConn.pipe(localConn);
            localConn.pipe(remoteConn);
          });

          const cleanup = () => {
            dataSockets.delete(remoteConn);
            dataSockets.delete(localConn);
            remoteConn.destroy();
            localConn.destroy();
          };
          remoteConn.on('error', cleanup);
          localConn.on('error', cleanup);
          remoteConn.on('close', cleanup);
          localConn.on('close', cleanup);
        } else if (typeof msg.Error === 'string' && !settled) {
          fail(new Error(`bore.pub rejected tunnel: ${msg.Error}`));
        }
      }
    });

    controlSocket.on('error', (err) => {
      fail(new Error(`bore.pub connection error: ${err.message}`));
    });

    controlSocket.on('close', () => {
      if (!settled) {
        fail(new Error('bore.pub closed before allocating a public port'));
      }
    });
  });
}

/**
 * Allocates a public SSH tunnel for a VPS local SSH port with automatic 3-tier failover:
 * 1. `free.pinggy.io:443` via pure Node.js `ssh2`
 * 2. `a.pinggy.io:443` via pure Node.js `ssh2`
 * 3. `bore.pub:7835` via pure TCP null-delimited JSON protocol
 */
export async function startPublicSshTunnel(params: {
  vpsId: string;
  localSshPort: number;
}): Promise<PublicSshTunnel> {
  stopPublicSshTunnel(params.vpsId);

  const errors: string[] = [];

  try {
    const handle = await connectPinggyViaSsh2(params.vpsId, 'free.pinggy.io', params.localSshPort);
    activeTunnels.set(params.vpsId, handle);
    return handle.info;
  } catch (err) {
    errors.push(err instanceof Error ? err.message : String(err));
  }

  try {
    const handle = await connectPinggyViaSsh2(params.vpsId, 'a.pinggy.io', params.localSshPort);
    activeTunnels.set(params.vpsId, handle);
    return handle.info;
  } catch (err) {
    errors.push(err instanceof Error ? err.message : String(err));
  }

  try {
    const handle = await connectBoreFallback(params.vpsId, params.localSshPort);
    activeTunnels.set(params.vpsId, handle);
    return handle.info;
  } catch (err) {
    errors.push(err instanceof Error ? err.message : String(err));
  }

  throw new Error(`All public SSH tunnel providers failed (${errors.join(' | ')})`);
}
