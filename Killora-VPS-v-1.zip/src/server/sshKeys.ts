import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface SshKeyRecord {
  id: string;
  userEmail: string;
  name: string;
  publicKey: string;
  createdAt: string;
}

const DATA_ROOT = path.resolve(process.cwd(), '.killoracloud-data');
const SSH_KEYS_FILE = path.join(DATA_ROOT, 'ssh-keys.json');

function ensureDir(): void {
  fs.mkdirSync(DATA_ROOT, { recursive: true, mode: 0o755 });
}

export function loadAllSshKeys(): SshKeyRecord[] {
  try {
    ensureDir();
    if (fs.existsSync(SSH_KEYS_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(SSH_KEYS_FILE, 'utf8'));
      return Array.isArray(parsed) ? parsed : [];
    }
  } catch {
    // ignore
  }
  return [];
}

export function saveAllSshKeys(keys: SshKeyRecord[]): void {
  try {
    ensureDir();
    fs.writeFileSync(SSH_KEYS_FILE, JSON.stringify(keys, null, 2), 'utf8');
  } catch {
    // ignore
  }
}

export function getSshKeys(userEmail: string): SshKeyRecord[] {
  const normalized = (userEmail || '').trim().toLowerCase();
  const all = loadAllSshKeys();
  if (!normalized || normalized === 'admin' || normalized.includes('admin')) {
    // Admin sees all or global admin keys
    return all;
  }
  return all.filter((k) => k.userEmail.toLowerCase() === normalized);
}

export function addSshKey(userEmail: string, name: string, publicKey: string): SshKeyRecord {
  const trimmedKey = (publicKey || '').trim();
  const trimmedName = (name || '').trim() || 'Default Key';
  const email = (userEmail || 'admin').trim().toLowerCase();

  if (!trimmedKey) {
    throw new Error('Public SSH key cannot be empty.');
  }

  // Basic validation for ssh-rsa, ssh-ed25519, ecdsa-sha2-...
  if (!/^(ssh-(rsa|ed25519|dss)|ecdsa-sha2-nistp(256|384|521))\s+[A-Za-z0-9+/=]+/i.test(trimmedKey)) {
    throw new Error('Invalid public SSH key format. Must start with ssh-rsa, ssh-ed25519, ecdsa-*, etc.');
  }

  const all = loadAllSshKeys();
  const record: SshKeyRecord = {
    id: crypto.randomBytes(6).toString('hex'),
    userEmail: email,
    name: trimmedName.slice(0, 40),
    publicKey: trimmedKey.slice(0, 2000),
    createdAt: new Date().toISOString(),
  };

  all.push(record);
  saveAllSshKeys(all);
  return record;
}

export function deleteSshKey(userEmail: string, keyId: string): void {
  const email = (userEmail || '').trim().toLowerCase();
  const all = loadAllSshKeys();
  const filtered = all.filter((k) => {
    if (k.id !== keyId) return true;
    if (email === 'admin' || email.includes('admin') || k.userEmail.toLowerCase() === email) {
      return false; // delete
    }
    return true; // keep if unauthorized
  });
  saveAllSshKeys(filtered);
}

export function getAuthorizedKeysForUser(userEmail: string): string {
  const keys = getSshKeys(userEmail);
  return keys.map((k) => k.publicKey).join('\n') + (keys.length > 0 ? '\n' : '');
}
