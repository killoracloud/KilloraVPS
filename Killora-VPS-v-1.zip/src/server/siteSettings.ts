import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

export type BackgroundMediaMode = 'auto' | 'none' | 'image' | 'video' | 'embed';

export interface SiteSettings {
  siteName: string;
  siteTagline: string;
  logoUrl: string;
  glassEnabled: boolean;
  glassOpacity: number; // 12 to 85 (%)
  glassBlur: number; // 4 to 32 (px)
  backgroundMode: BackgroundMediaMode;
  backgroundUrl: string;
  backgroundDim: number; // 0 to 85 (%)
  backgroundBlur: number; // 0 to 20 (px)
  backgroundMuted: boolean;
  discordBotToken: string;
  discordGuildId: string;
  discordAdminRoleId: string;
  updatedAt: string;
}

const DATA_ROOT = path.resolve(process.cwd(), '.killoracloud-data');
const SETTINGS_FILE = path.join(DATA_ROOT, 'site-settings.json');
export const MEDIA_DIR = path.join(DATA_ROOT, 'media');

const DEFAULT_SETTINGS: SiteSettings = {
  siteName: 'KilloraVPS',
  siteTagline: '24/7 Cloud VPS Control Panel',
  logoUrl: '',
  glassEnabled: true,
  glassOpacity: 34,
  glassBlur: 18,
  backgroundMode: 'auto',
  backgroundUrl: '',
  backgroundDim: 42,
  backgroundBlur: 0,
  backgroundMuted: true,
  discordBotToken: '',
  discordGuildId: '',
  discordAdminRoleId: '',
  updatedAt: new Date().toISOString(),
};

const ALLOWED_UPLOAD_MIME: Record<string, { ext: string; mediaKind: 'image' | 'video' }> = {
  'image/png': { ext: '.png', mediaKind: 'image' },
  'image/jpeg': { ext: '.jpg', mediaKind: 'image' },
  'image/jpg': { ext: '.jpg', mediaKind: 'image' },
  'image/gif': { ext: '.gif', mediaKind: 'image' },
  'image/webp': { ext: '.webp', mediaKind: 'image' },
  'image/avif': { ext: '.avif', mediaKind: 'image' },
  'video/mp4': { ext: '.mp4', mediaKind: 'video' },
  'video/webm': { ext: '.webm', mediaKind: 'video' },
  'video/ogg': { ext: '.ogv', mediaKind: 'video' },
  'video/quicktime': { ext: '.mov', mediaKind: 'video' },
};

function ensureStorageDirs(): void {
  fs.mkdirSync(DATA_ROOT, { recursive: true, mode: 0o755 });
  fs.mkdirSync(MEDIA_DIR, { recursive: true, mode: 0o755 });
}

export function sanitizeBackgroundUrl(raw: string): string {
  const trimmed = (raw || '').trim();
  if (!trimmed) return '';
  if (/[<>"'`\s]/.test(trimmed)) {
    throw new Error('Media URL contains invalid characters.');
  }
  // Allow safe server-uploaded media paths
  if (/^\/media\/[a-z0-9_-]+\.(png|jpg|gif|webp|avif|mp4|webm|ogv|mov)$/i.test(trimmed)) {
    return trimmed;
  }
  const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  let parsed: URL;
  try {
    parsed = new URL(withScheme);
  } catch {
    throw new Error('Invalid URL format.');
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    throw new Error('Only http:// and https:// URLs are allowed.');
  }
  return parsed.toString().slice(0, 1000);
}

export function sanitizeLogoUrl(raw: string): string {
  const trimmed = (raw || '').trim();
  if (!trimmed) return '';
  if (/[<>"'`\s]/.test(trimmed)) {
    throw new Error('Logo URL contains invalid characters.');
  }
  if (/^\/media\/[a-z0-9_-]+\.(png|jpg|gif|webp|avif)$/i.test(trimmed)) {
    return trimmed;
  }
  const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  let parsed: URL;
  try {
    parsed = new URL(withScheme);
  } catch {
    throw new Error('Invalid logo URL format.');
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    throw new Error('Only http:// and https:// URLs are allowed for logos.');
  }
  return parsed.toString().slice(0, 1000);
}

export function getSiteSettings(): SiteSettings {
  ensureStorageDirs();
  if (!fs.existsSync(SETTINGS_FILE)) {
    return { ...DEFAULT_SETTINGS };
  }
  try {
    const parsed = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')) as Partial<SiteSettings>;
    return {
      siteName:
        typeof parsed.siteName === 'string' && parsed.siteName.trim()
          ? parsed.siteName.trim().slice(0, 60)
          : DEFAULT_SETTINGS.siteName,
      siteTagline:
        typeof parsed.siteTagline === 'string'
          ? parsed.siteTagline.trim().slice(0, 120)
          : DEFAULT_SETTINGS.siteTagline,
      logoUrl: typeof parsed.logoUrl === 'string' ? parsed.logoUrl : '',
      glassEnabled:
        typeof parsed.glassEnabled === 'boolean'
          ? parsed.glassEnabled
          : DEFAULT_SETTINGS.glassEnabled,
      glassOpacity:
        typeof parsed.glassOpacity === 'number'
          ? Math.max(10, Math.min(88, Math.round(parsed.glassOpacity)))
          : DEFAULT_SETTINGS.glassOpacity,
      glassBlur:
        typeof parsed.glassBlur === 'number'
          ? Math.max(4, Math.min(34, Math.round(parsed.glassBlur)))
          : DEFAULT_SETTINGS.glassBlur,
      backgroundMode: ['auto', 'none', 'image', 'video', 'embed'].includes(
        String(parsed.backgroundMode)
      )
        ? (parsed.backgroundMode as BackgroundMediaMode)
        : 'auto',
      backgroundUrl: typeof parsed.backgroundUrl === 'string' ? parsed.backgroundUrl : '',
      backgroundDim:
        typeof parsed.backgroundDim === 'number'
          ? Math.max(0, Math.min(85, Math.round(parsed.backgroundDim)))
          : DEFAULT_SETTINGS.backgroundDim,
      backgroundBlur:
        typeof parsed.backgroundBlur === 'number'
          ? Math.max(0, Math.min(20, Math.round(parsed.backgroundBlur)))
          : DEFAULT_SETTINGS.backgroundBlur,
      backgroundMuted:
        typeof parsed.backgroundMuted === 'boolean'
          ? parsed.backgroundMuted
          : DEFAULT_SETTINGS.backgroundMuted,
      discordBotToken:
        typeof parsed.discordBotToken === 'string'
          ? parsed.discordBotToken.trim().slice(0, 300)
          : DEFAULT_SETTINGS.discordBotToken,
      discordGuildId:
        typeof parsed.discordGuildId === 'string'
          ? parsed.discordGuildId.trim().slice(0, 60)
          : DEFAULT_SETTINGS.discordGuildId,
      discordAdminRoleId:
        typeof parsed.discordAdminRoleId === 'string'
          ? parsed.discordAdminRoleId.trim().slice(0, 60)
          : DEFAULT_SETTINGS.discordAdminRoleId,
      updatedAt: typeof parsed.updatedAt === 'string' ? parsed.updatedAt : DEFAULT_SETTINGS.updatedAt,
    };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function updateSiteSettings(patch: Partial<SiteSettings>): SiteSettings {
  ensureStorageDirs();
  const current = getSiteSettings();

  const nextName =
    typeof patch.siteName === 'string' && patch.siteName.trim()
      ? patch.siteName.trim().slice(0, 60)
      : current.siteName;

  const nextTagline =
    typeof patch.siteTagline === 'string'
      ? patch.siteTagline.trim().slice(0, 120)
      : current.siteTagline;

  const nextLogoUrl =
    typeof patch.logoUrl === 'string' ? sanitizeLogoUrl(patch.logoUrl) : current.logoUrl;

  const nextBgUrl =
    typeof patch.backgroundUrl === 'string'
      ? sanitizeBackgroundUrl(patch.backgroundUrl)
      : current.backgroundUrl;

  const nextMode: BackgroundMediaMode =
    patch.backgroundMode && ['auto', 'none', 'image', 'video', 'embed'].includes(patch.backgroundMode)
      ? patch.backgroundMode
      : current.backgroundMode;

  const updated: SiteSettings = {
    siteName: nextName,
    siteTagline: nextTagline,
    logoUrl: nextLogoUrl,
    glassEnabled:
      typeof patch.glassEnabled === 'boolean' ? patch.glassEnabled : current.glassEnabled,
    glassOpacity:
      typeof patch.glassOpacity === 'number'
        ? Math.max(10, Math.min(88, Math.round(patch.glassOpacity)))
        : current.glassOpacity,
    glassBlur:
      typeof patch.glassBlur === 'number'
        ? Math.max(4, Math.min(34, Math.round(patch.glassBlur)))
        : current.glassBlur,
    backgroundMode: nextBgUrl ? nextMode : 'none',
    backgroundUrl: nextBgUrl,
    backgroundDim:
      typeof patch.backgroundDim === 'number'
        ? Math.max(0, Math.min(85, Math.round(patch.backgroundDim)))
        : current.backgroundDim,
    backgroundBlur:
      typeof patch.backgroundBlur === 'number'
        ? Math.max(0, Math.min(20, Math.round(patch.backgroundBlur)))
        : current.backgroundBlur,
    backgroundMuted:
      typeof patch.backgroundMuted === 'boolean'
        ? patch.backgroundMuted
        : current.backgroundMuted,
    discordBotToken:
      typeof patch.discordBotToken === 'string'
        ? patch.discordBotToken.trim().slice(0, 300)
        : current.discordBotToken,
    discordGuildId:
      typeof patch.discordGuildId === 'string'
        ? patch.discordGuildId.trim().slice(0, 60)
        : current.discordGuildId,
    discordAdminRoleId:
      typeof patch.discordAdminRoleId === 'string'
        ? patch.discordAdminRoleId.trim().slice(0, 60)
        : current.discordAdminRoleId,
    updatedAt: new Date().toISOString(),
  };

  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(updated, null, 2), 'utf8');
  return updated;
}

export function saveUploadedBackgroundMedia(
  contentTypeHeader: string,
  buffer: Buffer
): { url: string; mediaKind: 'image' | 'video' } {
  ensureStorageDirs();
  const mime = (contentTypeHeader || '').split(';')[0].trim().toLowerCase();
  const spec = ALLOWED_UPLOAD_MIME[mime];
  if (!spec) {
    throw new Error('Unsupported file type. Upload PNG, JPG, GIF, WebP, MP4, or WebM.');
  }
  if (!buffer || buffer.length === 0) {
    throw new Error('Uploaded file is empty.');
  }
  if (buffer.length > 25 * 1024 * 1024) {
    throw new Error('File too large (max 25 MB).');
  }

  const fileName = `bg_${Date.now().toString(36)}_${crypto.randomBytes(6).toString('hex')}${spec.ext}`;
  const targetPath = path.resolve(MEDIA_DIR, fileName);
  if (!targetPath.startsWith(MEDIA_DIR + path.sep)) {
    throw new Error('Invalid media path.');
  }
  fs.writeFileSync(targetPath, buffer, { mode: 0o644 });
  return { url: `/media/${fileName}`, mediaKind: spec.mediaKind };
}

export function saveUploadedLogoMedia(
  contentTypeHeader: string,
  buffer: Buffer
): { url: string } {
  ensureStorageDirs();
  const mime = (contentTypeHeader || '').split(';')[0].trim().toLowerCase();
  const spec = ALLOWED_UPLOAD_MIME[mime];
  if (!spec || spec.mediaKind !== 'image') {
    throw new Error('Unsupported logo format. Upload PNG, JPG, GIF, WebP, or AVIF image.');
  }
  if (!buffer || buffer.length === 0) {
    throw new Error('Uploaded logo file is empty.');
  }
  if (buffer.length > 8 * 1024 * 1024) {
    throw new Error('Logo file too large (max 8 MB).');
  }

  const fileName = `logo_${Date.now().toString(36)}_${crypto.randomBytes(6).toString('hex')}${spec.ext}`;
  const targetPath = path.resolve(MEDIA_DIR, fileName);
  if (!targetPath.startsWith(MEDIA_DIR + path.sep)) {
    throw new Error('Invalid logo path.');
  }
  fs.writeFileSync(targetPath, buffer, { mode: 0o644 });
  return { url: `/media/${fileName}` };
}

export function resolveSafeMediaFile(filename: string): { filePath: string; contentType: string } | null {
  if (!/^[a-z0-9_-]+\.(png|jpg|gif|webp|avif|mp4|webm|ogv|mov)$/i.test(filename)) {
    return null;
  }
  const resolved = path.resolve(MEDIA_DIR, filename);
  if (!resolved.startsWith(MEDIA_DIR + path.sep)) {
    return null;
  }
  if (!fs.existsSync(resolved)) {
    return null;
  }
  const ext = path.extname(resolved).toLowerCase();
  const contentTypeMap: Record<string, string> = {
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.avif': 'image/avif',
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.ogv': 'video/ogg',
    '.mov': 'video/quicktime',
  };
  return { filePath: resolved, contentType: contentTypeMap[ext] || 'application/octet-stream' };
}
