import {
  Client,
  GatewayIntentBits,
  Partials,
  REST,
  Routes,
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  type ChatInputCommandInteraction,
  type ButtonInteraction,
  type StringSelectMenuInteraction,
  type ModalSubmitInteraction,
  type AutocompleteInteraction,
  type Message,
  type User as DiscordUser,
  type GuildMember,
  type APIInteractionGuildMember,
} from 'discord.js';
import {
  listVpsInstances,
  getVpsInstance,
  createVpsInstance,
  deleteVpsInstance,
  setVpsPowerState,
  reinstallVpsInstance,
  enableVpsPublicSsh,
  enableVpsSshx,
  renewVpsExpiry,
  assignVpsOwner,
} from './nativeUbuntuEngine.ts';
import {
  OS_CATALOG,
  CPU_MODEL_CATALOG,
  getOsOption,
  type OsId,
  type VpsInstance,
} from '../types/vps.ts';
import { getSiteSettings } from './siteSettings.ts';
import { getLinkedEmailForDiscord, linkDiscordUser, loadDiscordLinks } from './discordLinks.ts';
import {
  authenticateUnifiedLogin,
  createMemberAccount,
  findMemberByEmailOrId,
  getEffectiveAdminIdentity,
} from './authVerify.ts';

let discordClient: Client | null = null;
let botStatusState: {
  online: boolean;
  botTag: string | null;
  botId: string | null;
  guildCount: number;
  commandsSynced: boolean;
  lastError: string | null;
} = {
  online: false,
  botTag: null,
  botId: null,
  guildCount: 0,
  commandsSynced: false,
  lastError: null,
};

interface PendingPanelLinkSession {
  step: 'email' | 'username' | 'password';
  email?: string;
  username?: string;
  expiresAt: number;
}

const pendingPanelLinks = new Map<string, PendingPanelLinkSession>();

export function getDiscordBotStatus() {
  const settings = getSiteSettings();
  const hasToken = Boolean(
    (settings.discordBotToken && settings.discordBotToken.trim()) ||
      (process.env.DISCORD_BOT_TOKEN &&
        process.env.DISCORD_BOT_TOKEN.trim() &&
        process.env.DISCORD_BOT_TOKEN !== 'your_discord_bot_token_here')
  );
  return {
    configured: hasToken,
    online: botStatusState.online,
    botTag: botStatusState.botTag,
    botId: botStatusState.botId,
    guildCount: discordClient?.guilds.cache.size ?? botStatusState.guildCount,
    commandsSynced: botStatusState.commandsSynced,
    lastError: botStatusState.lastError,
    linkedUsersCount: loadDiscordLinks().length,
  };
}

function getMemberRoleIds(member: GuildMember | APIInteractionGuildMember | null): string[] {
  if (!member) return [];
  const roles = member.roles;
  if (Array.isArray(roles)) {
    return roles;
  }
  if (roles && 'cache' in roles) {
    return Array.from(roles.cache.keys());
  }
  return [];
}

function isDiscordVpsAdmin(
  interaction: ChatInputCommandInteraction | ButtonInteraction | StringSelectMenuInteraction
): boolean {
  const settings = getSiteSettings();
  const adminRoleId = settings.discordAdminRoleId?.trim();
  const adminIdentity = getEffectiveAdminIdentity();
  const linkedEmail = getLinkedEmailForDiscord(interaction.user.id);
  const isPanelAdmin = Boolean(
    linkedEmail && linkedEmail.toLowerCase() === adminIdentity.email.toLowerCase()
  );

  if (isPanelAdmin) return true;

  if (adminRoleId) {
    const roleIds = getMemberRoleIds(interaction.member);
    return roleIds.includes(adminRoleId);
  }

  return Boolean(interaction.memberPermissions?.has(PermissionFlagsBits.Administrator));
}

function canUserControlVps(
  interaction: ChatInputCommandInteraction | ButtonInteraction | StringSelectMenuInteraction,
  vm: VpsInstance
): boolean {
  const discordUserId = interaction.user.id;
  const linkedEmail = getLinkedEmailForDiscord(discordUserId);
  const isAdmin = isDiscordVpsAdmin(interaction);

  if (isAdmin) return true;
  if (vm.ownerId === discordUserId) return true;
  if (linkedEmail && vm.ownerEmail && vm.ownerEmail.toLowerCase() === linkedEmail.toLowerCase()) {
    return true;
  }
  return false;
}

function getUserOwnedVpsList(
  interaction: ChatInputCommandInteraction | ButtonInteraction | StringSelectMenuInteraction,
  targetDiscordUserId?: string,
  targetUsername?: string
): VpsInstance[] {
  const uid = targetDiscordUserId ?? interaction.user.id;
  const linkedEmail = getLinkedEmailForDiscord(uid);
  const all = listVpsInstances('admin-discord', true);

  // If listing for self in /manage and user is Admin, show all if they want to manage cluster or own
  if (!targetDiscordUserId && isDiscordVpsAdmin(interaction)) {
    return all;
  }

  void targetUsername;
  return all.filter((vm) => {
    if (vm.ownerId === uid) return true;
    if (linkedEmail && vm.ownerEmail && vm.ownerEmail.toLowerCase() === linkedEmail.toLowerCase()) {
      return true;
    }
    return false;
  });
}

function formatRam(mb: number): string {
  if (mb >= 1024) {
    const gb = mb / 1024;
    return Number.isInteger(gb) ? `${gb} GB` : `${gb.toFixed(1)} GB`;
  }
  return `${mb} MB`;
}

function buildManageListPayload(ownerDiscordId: string, userVms: VpsInstance[], linkedEmail: string | null) {
  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId(`mngsel:${ownerDiscordId}`)
    .setPlaceholder('Select a VPS to open its control panel...')
    .addOptions(
      userVms.slice(0, 25).map((vm) => {
        const osInfo = getOsOption(vm.osId);
        return {
          label: `${vm.name} (${vm.status.toUpperCase()})`.slice(0, 100),
          description: `${osInfo.label} | ${vm.vcpu} vCPU / ${formatRam(vm.ramMb)} / ${vm.diskGb}GB`.slice(0, 100),
          value: vm.id,
        };
      })
    );

  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu);

  const embed = new EmbedBuilder()
    .setTitle('🖥️ KilloraCloud VPS Management')
    .setColor(0x0ea5e9)
    .setDescription(
      `Owner: <@${ownerDiscordId}>${linkedEmail ? ` (\`${linkedEmail}\`)` : ''}\n` +
        `Found **${userVms.length}** VPS instance${userVms.length === 1 ? '' : 's'}.\n` +
        `Select any VPS from the dropdown below to control it live.`
    )
    .setFooter({ text: 'Only the VPS owner can interact with this panel.' })
    .setTimestamp();

  return { embeds: [embed], components: [row] };
}

function buildVpsControlPanelPayload(ownerDiscordId: string, vm: VpsInstance) {
  const osInfo = getOsOption(vm.osId);
  const statusEmoji =
    vm.status === 'running' ? '🟢 RUNNING' : vm.status === 'paused' ? '🟡 PAUSED' : '🔴 STOPPED';

  const embed = new EmbedBuilder()
    .setTitle(`🖥️ VPS Control Panel — ${vm.name}`)
    .setColor(vm.status === 'running' ? 0x10b981 : vm.status === 'paused' ? 0xf59e0b : 0xef4444)
    .setDescription(`Owner: <@${ownerDiscordId}> | VMID: \`${vm.vmid}\``)
    .addFields(
      { name: 'Live Status', value: `**${statusEmoji}**`, inline: true },
      { name: 'Operating System', value: osInfo.label, inline: true },
      { name: 'Private IP', value: `\`${vm.ipAddress}\``, inline: true },
      { name: 'CPU Model', value: vm.cpuModel, inline: false },
      {
        name: 'Hardware Specs',
        value: `${vm.vcpu} vCPU • ${formatRam(vm.ramMb)} RAM • ${vm.diskGb} GB NVMe`,
        inline: true,
      },
      {
        name: 'Live Load',
        value:
          vm.status === 'running'
            ? `CPU ${vm.cpuUsagePct ?? "N/A"}% • RAM ${vm.ramUsedMb ?? "N/A"}/${vm.ramMb} MB`
            : 'Powered Off',
        inline: true,
      },
      {
        name: 'SSH Tunnel',
        value: vm.publicSsh?.active ? '🟢 Active (Click SSH button)' : '⚪ Inactive (Click SSH)',
        inline: true,
      },
      {
        name: 'SSHX Terminal',
        value: vm.sshxSession?.active ? '🟢 Active (Click SSHX button)' : '⚪ Inactive (Click SSHX)',
        inline: true,
      },
      {
        name: 'Expires',
        value: vm.expiresAt ? `\`${vm.expiresAt}\`` : 'No Expiry',
        inline: true,
      }
    )
    .setFooter({ text: 'Sensitive SSH/SSHX credentials are always delivered privately to the owner.' })
    .setTimestamp();

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`mngbtn:${ownerDiscordId}:start:${vm.id}`)
      .setLabel('Start')
      .setStyle(ButtonStyle.Success)
      .setEmoji('▶️'),
    new ButtonBuilder()
      .setCustomId(`mngbtn:${ownerDiscordId}:stop:${vm.id}`)
      .setLabel('Stop')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('⏹️'),
    new ButtonBuilder()
      .setCustomId(`mngbtn:${ownerDiscordId}:restart:${vm.id}`)
      .setLabel('Restart')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🔄'),
    new ButtonBuilder()
      .setCustomId(`mngbtn:${ownerDiscordId}:refresh:${vm.id}`)
      .setLabel('Refresh')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('📊')
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`mngbtn:${ownerDiscordId}:ssh:${vm.id}`)
      .setLabel('SSH')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('🔐'),
    new ButtonBuilder()
      .setCustomId(`mngbtn:${ownerDiscordId}:sshx:${vm.id}`)
      .setLabel('SSHX')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('🌐'),
    new ButtonBuilder()
      .setCustomId(`mngbtn:${ownerDiscordId}:reinstall:${vm.id}`)
      .setLabel('Reinstall')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('💿'),
    new ButtonBuilder()
      .setCustomId(`mngbtn:${ownerDiscordId}:list:${vm.id}`)
      .setLabel('My VPS List')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('📋')
  );

  return { embeds: [embed], components: [row1, row2] };
}

function buildPanelLinkModal(): ModalBuilder {
  const modal = new ModalBuilder()
    .setCustomId('plink_modal_submit')
    .setTitle('Link / Register Panel Account');

  const emailInput = new TextInputBuilder()
    .setCustomId('panel_email')
    .setLabel('Email Address')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('yourname@gmail.com')
    .setRequired(true);

  const usernameInput = new TextInputBuilder()
    .setCustomId('panel_username')
    .setLabel('Username')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('rahul123')
    .setRequired(true);

  const passwordInput = new TextInputBuilder()
    .setCustomId('panel_password')
    .setLabel('Password (min 4 characters)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Enter a secure password')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(emailInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(usernameInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(passwordInput)
  );

  return modal;
}

function completePanelLink(
  discordUser: DiscordUser,
  emailRaw: string,
  usernameRaw: string,
  passwordRaw: string
): { email: string; username: string; createdNew: boolean; syncedVpsCount: number } {
  const email = emailRaw.trim().toLowerCase();
  const username = usernameRaw.trim().toLowerCase().replace(/[^a-z0-9._-]/g, '');
  const password = passwordRaw.trim();

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error('Please enter a valid email address (e.g. user@gmail.com).');
  }
  if (!username || username.length < 3) {
    throw new Error('Username must be at least 3 characters (letters, numbers, ., _, -).');
  }
  if (!password || password.length < 12) {
    throw new Error('Password must be at least 12 characters long.');
  }

  const adminIdentity = getEffectiveAdminIdentity();
  const existingMember = findMemberByEmailOrId(email);
  const matchesAdmin = email === adminIdentity.email.toLowerCase();

  let createdNew = false;
  let finalUsername = username;

  if (existingMember || matchesAdmin) {
    // Account already exists — verify password so nobody can hijack another account
    const loginResult = authenticateUnifiedLogin(email, password);
    finalUsername = loginResult.user.username;
  } else {
    const created = createMemberAccount({
      email,
      username,
      password,
      displayName: discordUser.username,
    });
    finalUsername = created.username;
    createdNew = true;
  }

  linkDiscordUser(discordUser.id, discordUser.tag, email);

  // Sync any VPS instances already assigned to this Discord user ID so they also show up on the Web Dashboard
  let syncedVpsCount = 0;
  const memberRecord = findMemberByEmailOrId(email);
  const all = listVpsInstances('admin-discord', true);
  for (const vm of all) {
    if (
      vm.ownerId === discordUser.id
    ) {
      assignVpsOwner(vm.id, memberRecord?.id || discordUser.id, email);
      syncedVpsCount++;
    }
  }

  return { email, username: finalUsername, createdNew, syncedVpsCount };
}

export function initDiscordBot(): void {
  const settings = getSiteSettings();
  const token = settings.discordBotToken?.trim() || process.env.DISCORD_BOT_TOKEN?.trim() || '';
  if (!token || token === 'your_discord_bot_token_here') {
    botStatusState = {
      online: false,
      botTag: null,
      botId: null,
      guildCount: 0,
      commandsSynced: false,
      lastError: null,
    };
    console.log('[DiscordBot] Discord bot token not configured. Bot offline.');
    return;
  }

  try {
    // Non-privileged intents only! DirectMessages + Partials.Channel lets us read DM replies
    // and interaction.member.roles already provides role IDs without needing GuildMembers intent.
    discordClient = new Client({
      intents: [GatewayIntentBits.Guilds, GatewayIntentBits.DirectMessages],
      partials: [Partials.Channel],
    });

    discordClient.once('ready', async (client) => {
      console.log(`[DiscordBot] Logged in successfully as ${client.user.tag}!`);
      botStatusState = {
        online: true,
        botTag: client.user.tag,
        botId: client.user.id,
        guildCount: client.guilds.cache.size,
        commandsSynced: false,
        lastError: null,
      };
      await registerDiscordCommands(client, token);
    });

    discordClient.on('error', (err) => {
      console.error('[DiscordBot] Client error:', err);
      botStatusState.lastError = err.message;
    });

    discordClient.on('messageCreate', async (message) => {
      try {
        await handleDirectMessage(message);
      } catch (err) {
        console.error('[DiscordBot] DM handler error:', err);
      }
    });

    discordClient.on('interactionCreate', async (interaction) => {
      try {
        if (interaction.isAutocomplete()) {
          await handleAutocomplete(interaction);
        } else if (interaction.isChatInputCommand()) {
          await handleChatCommand(interaction);
        } else if (interaction.isButton()) {
          await handleButtonInteraction(interaction);
        } else if (interaction.isStringSelectMenu()) {
          await handleSelectMenuInteraction(interaction);
        } else if (interaction.isModalSubmit()) {
          await handleModalSubmit(interaction);
        }
      } catch (err) {
        console.error('[DiscordBot] Interaction error:', err);
        const errText = err instanceof Error ? err.message : 'An unexpected error occurred.';
        const msg = { content: `❌ ${errText}`, ephemeral: true };
        if (interaction.isRepliable()) {
          if (interaction.replied || interaction.deferred) {
            await interaction.followUp(msg).catch(() => {});
          } else {
            await interaction.reply(msg).catch(() => {});
          }
        }
      }
    });

    void discordClient.login(token).catch((err) => {
      console.error('[DiscordBot] Login failed:', err);
      botStatusState = {
        online: false,
        botTag: null,
        botId: null,
        guildCount: 0,
        commandsSynced: false,
        lastError: err instanceof Error ? err.message : 'Discord login failed',
      };
    });
  } catch (err) {
    console.error('[DiscordBot] Failed to initialize discord bot:', err);
    botStatusState.online = false;
    botStatusState.lastError = err instanceof Error ? err.message : 'Initialization error';
  }
}

export function reconfigureDiscordBot(): void {
  if (discordClient) {
    try {
      discordClient.destroy();
    } catch {
      // ignore
    }
    discordClient = null;
  }
  botStatusState = {
    online: false,
    botTag: null,
    botId: null,
    guildCount: 0,
    commandsSynced: false,
    lastError: null,
  };
  initDiscordBot();
}

async function registerDiscordCommands(client: Client<true>, token: string) {
  const clientId = client.user.id;
  const rest = new REST({ version: '10' }).setToken(token);
  const settings = getSiteSettings();
  const guildId = settings.discordGuildId?.trim();

  const vpsCommand = new SlashCommandBuilder()
    .setName('vps')
    .setDescription('KilloraCloud VPS Admin Management Commands');

  vpsCommand.addSubcommand((sub) =>
    sub
      .setName('create')
      .setDescription('Provision a new VPS instance (Admin Role required)')
      .addUserOption((opt) =>
        opt.setName('user').setDescription('Target Discord user').setRequired(true)
      )
      .addIntegerOption((opt) =>
        opt.setName('ram').setDescription('RAM in GB').setMinValue(1).setRequired(true)
      )
      .addIntegerOption((opt) =>
        opt.setName('cpu').setDescription('vCPU Cores').setMinValue(1).setRequired(true)
      )
      .addIntegerOption((opt) =>
        opt.setName('disk').setDescription('Disk in GB').setMinValue(1).setRequired(true)
      )
      .addStringOption((opt) =>
        opt
          .setName('os')
          .setDescription('Operating System')
          .setRequired(true)
          .addChoices(...OS_CATALOG.map((o) => ({ name: o.label.slice(0, 100), value: o.id })))
      )
      .addStringOption((opt) =>
        opt
          .setName('cpu_model')
          .setDescription('CPU Model (select from all panel CPUs)')
          .setRequired(true)
          .setAutocomplete(true)
      )
      .addStringOption((opt) =>
        opt
          .setName('expire')
          .setDescription('Expire date (e.g. 2026-12-31 or 30d)')
          .setRequired(true)
      )
  );

  vpsCommand.addSubcommand((sub) =>
    sub.setName('list').setDescription('List all active VPS instances')
  );

  vpsCommand.addSubcommand((sub) =>
    sub
      .setName('renew')
      .setDescription('Renew expiration date of a user VPS')
      .addUserOption((opt) =>
        opt.setName('user').setDescription('Target Discord user').setRequired(true)
      )
      .addStringOption((opt) =>
        opt.setName('expire').setDescription('New expire date (e.g. 2027-01-31)').setRequired(true)
      )
  );

  vpsCommand.addSubcommand((sub) =>
    sub
      .setName('delete')
      .setDescription('Delete a user VPS instance (with confirmation)')
      .addUserOption((opt) =>
        opt.setName('user').setDescription('Target Discord user').setRequired(true)
      )
  );

  vpsCommand.addSubcommand((sub) =>
    sub
      .setName('suspend')
      .setDescription('Suspend a user VPS instance')
      .addUserOption((opt) =>
        opt.setName('user').setDescription('Target Discord user').setRequired(true)
      )
  );

  const manageCommand = new SlashCommandBuilder()
    .setName('manage')
    .setDescription('Open live VPS management panel for your assigned servers');

  const panelLinkCommand = new SlashCommandBuilder()
    .setName('panel-link')
    .setDescription('Register & connect your Discord account to the web panel via DM');

  const commands = [vpsCommand.toJSON(), manageCommand.toJSON(), panelLinkCommand.toJSON()];

  try {
    if (guildId) {
      // Clear global commands and any other guilds so NO duplicate commands ever show up
      await rest.put(Routes.applicationCommands(clientId), { body: [] });
      for (const gId of client.guilds.cache.keys()) {
        if (gId !== guildId) {
          await rest.put(Routes.applicationGuildCommands(clientId, gId), { body: [] }).catch(() => {});
        }
      }
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      console.log(`[DiscordBot] Slash commands synced cleanly to guild ${guildId} (global cleared, zero duplicates).`);
    } else {
      // Clear per-guild commands on all joined guilds before registering globally so zero duplicates appear
      for (const gId of client.guilds.cache.keys()) {
        await rest.put(Routes.applicationGuildCommands(clientId, gId), { body: [] }).catch(() => {});
      }
      await rest.put(Routes.applicationCommands(clientId), { body: commands });
      console.log('[DiscordBot] Global slash commands synced cleanly (guild overrides cleared, zero duplicates).');
    }
    botStatusState.commandsSynced = true;
    botStatusState.lastError = null;
  } catch (err) {
    console.error('[DiscordBot] Failed to register slash commands:', err);
    botStatusState.lastError = err instanceof Error ? err.message : 'Failed to sync slash commands';
  }
}

async function handleAutocomplete(interaction: AutocompleteInteraction) {
  if (interaction.commandName === 'vps') {
    const focused = interaction.options.getFocused(true);
    if (focused.name === 'cpu_model') {
      const query = focused.value.trim().toLowerCase();
      const matches = CPU_MODEL_CATALOG.filter(
        (c) =>
          !query ||
          c.model.toLowerCase().includes(query) ||
          c.series.toLowerCase().includes(query) ||
          c.vendor.toLowerCase().includes(query)
      )
        .slice(0, 25)
        .map((c) => ({
          name: `${c.model} (${c.clockHint})`.slice(0, 100),
          value: c.model.slice(0, 100),
        }));
      await interaction.respond(matches);
      return;
    }
  }
  await interaction.respond([]);
}

async function handleDirectMessage(message: Message) {
  if (message.author.bot || message.guild) return;

  const session = pendingPanelLinks.get(message.author.id);
  if (!session) return;

  if (Date.now() > session.expiresAt) {
    pendingPanelLinks.delete(message.author.id);
    await message.reply('⏱️ Your `/panel-link` session expired. Please run `/panel-link` again.');
    return;
  }

  const input = message.content.trim();
  if (!input) return;

  if (input.toLowerCase() === 'cancel') {
    pendingPanelLinks.delete(message.author.id);
    await message.reply('❌ Panel linking cancelled.');
    return;
  }

  if (session.step === 'email') {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input)) {
      await message.reply(
        '❌ Invalid email format. Please reply with a valid email address (e.g. `yourname@gmail.com`) or type `cancel`.'
      );
      return;
    }
    session.email = input.toLowerCase();
    session.step = 'username';
    session.expiresAt = Date.now() + 10 * 60_000;
    pendingPanelLinks.set(message.author.id, session);

    await message.reply({
      embeds: [
        new EmbedBuilder()
          .setTitle('🔗 Step 2 of 3 — Enter Username')
          .setColor(0x38bdf8)
          .setDescription(
            `✅ Email saved: \`${session.email}\`\n\nNow reply with your desired **Panel Username** (min 3 characters, e.g. \`rahul123\`).`
          ),
      ],
    });
    return;
  }

  if (session.step === 'username') {
    const cleanUsername = input.toLowerCase().replace(/[^a-z0-9._-]/g, '');
    if (cleanUsername.length < 3) {
      await message.reply(
        '❌ Username must be at least 3 characters (letters, numbers, `.`, `_`, `-`). Please try again:'
      );
      return;
    }
    session.username = cleanUsername;
    session.step = 'password';
    session.expiresAt = Date.now() + 10 * 60_000;
    pendingPanelLinks.set(message.author.id, session);

    await message.reply({
      embeds: [
        new EmbedBuilder()
          .setTitle('🔗 Step 3 of 3 — Enter Password')
          .setColor(0x38bdf8)
          .setDescription(
            `✅ Username saved: \`${session.username}\`\n\nNow reply with your **Panel Password** (minimum 4 characters).`
          ),
      ],
    });
    return;
  }

  if (session.step === 'password') {
    if (input.length < 4) {
      await message.reply('❌ Password must be at least 12 characters long. Please try again:');
      return;
    }

    pendingPanelLinks.delete(message.author.id);
    try {
      const result = completePanelLink(
        message.author,
        session.email || '',
        session.username || '',
        input
      );
      const settings = getSiteSettings();
      await message.reply({
        embeds: [
          new EmbedBuilder()
            .setTitle(
              result.createdNew
                ? '✅ Panel Account Registered & Linked!'
                : '✅ Existing Panel Account Linked!'
            )
            .setColor(0x10b981)
            .setDescription(
              `Your Discord account (**${message.author.tag}**) is now connected to **${settings.siteName || 'KilloraCloud'}**!\n\n` +
                `You can now log into the Web Dashboard using these credentials **AND** control your VPS instances directly from Discord using \`/manage\`.`
            )
            .addFields(
              { name: 'Email', value: `\`${result.email}\``, inline: true },
              { name: 'Username', value: `\`${result.username}\``, inline: true },
              {
                name: 'Synced VPS Instances',
                value: `${result.syncedVpsCount} linked`,
                inline: true,
              }
            )
            .setTimestamp(),
        ],
      });
    } catch (err) {
      await message.reply(
        `❌ Registration / linking failed: ${err instanceof Error ? err.message : 'Unknown error'}\n\nRun \`/panel-link\` again to retry.`
      );
    }
  }
}

async function handleChatCommand(interaction: ChatInputCommandInteraction) {
  const { commandName } = interaction;

  // 1. /panel-link — sends DM step-by-step (Email -> Username -> Password) with Modal fallback
  if (commandName === 'panel-link') {
    pendingPanelLinks.set(interaction.user.id, {
      step: 'email',
      expiresAt: Date.now() + 10 * 60_000,
    });

    const settings = getSiteSettings();
    const dmEmbed = new EmbedBuilder()
      .setTitle(`🔗 Link Your ${settings.siteName || 'KilloraCloud'} Account`)
      .setColor(0x38bdf8)
      .setDescription(
        `Let's register your panel account and connect it to Discord!\n\n` +
          `**Step 1 of 3:** Reply right here with your **Email Address** (e.g. \`yourname@gmail.com\`).\n` +
          `Then I'll ask for your **Username** and **Password**.\n\n` +
          `*(Type \`cancel\` anytime to cancel, or click the button below to fill all 3 fields in a popup form.)*`
      )
      .setTimestamp();

    const quickRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`plink_open_modal:${interaction.user.id}`)
        .setLabel('Fill via Quick Form')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('📝'),
      new ButtonBuilder()
        .setCustomId(`plink_cancel:${interaction.user.id}`)
        .setLabel('Cancel')
        .setStyle(ButtonStyle.Secondary)
    );

    try {
      const dm = await interaction.user.createDM();
      await dm.send({ embeds: [dmEmbed], components: [quickRow] });

      await interaction.reply({
        content:
          '📩 **Check your DMs!** I sent you a private message to enter your **Email**, **Username**, and **Password** to register & link your panel account.',
        ephemeral: true,
      });
    } catch {
      pendingPanelLinks.delete(interaction.user.id);
      const fallbackRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId(`plink_open_modal:${interaction.user.id}`)
          .setLabel('Register & Link Account')
          .setStyle(ButtonStyle.Primary)
          .setEmoji('🔗')
      );
      await interaction.reply({
        content:
          '⚠️ Your Discord DMs appear to be closed! Enable DMs from server members, OR click the button below to register & link your panel account privately right now:',
        components: [fallbackRow],
        ephemeral: true,
      });
    }
    return;
  }

  // 2. /manage — shows user's VPS list in channel, strict owner lock, never deletes panel
  if (commandName === 'manage') {
    const discordUserId = interaction.user.id;
    const linkedEmail = getLinkedEmailForDiscord(discordUserId);
    const userVms = getUserOwnedVpsList(interaction);

    if (userVms.length === 0) {
      const embed = new EmbedBuilder()
        .setTitle('🖥️ VPS Management Panel')
        .setColor(0xef4444)
        .setDescription(
          linkedEmail
            ? `No VPS instances found for **${linkedEmail}**.\nAsk an administrator to create a VPS for you.`
            : `❌ No VPS found and your Discord account is not linked yet!\nRun \`/panel-link\` first to register & connect your panel account.`
        );
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    const payload = buildManageListPayload(discordUserId, userVms, linkedEmail);
    // Sent publicly in channel so panel persists; every click verifies ownership & secrets stay private
    await interaction.reply(payload);
    return;
  }

  // 3. /vps — Admin Role restricted management commands
  if (commandName === 'vps') {
    if (!isDiscordVpsAdmin(interaction)) {
      const settings = getSiteSettings();
      const roleHint = settings.discordAdminRoleId
        ? `You need the configured VPS Admin Role (<@&${settings.discordAdminRoleId}>) to use this command.`
        : 'You need Administrator permissions (or configure an Admin Role ID in the Panel Dashboard) to use this command.';
      await interaction.reply({
        content: `❌ **Permission Denied!** ${roleHint}`,
        ephemeral: true,
      });
      return;
    }

    const sub = interaction.options.getSubcommand();
    const targetUser = interaction.options.getUser('user');

    if (sub === 'create' && targetUser) {
      await interaction.deferReply();

      const ramGb = interaction.options.getInteger('ram', true);
      const vcpu = interaction.options.getInteger('cpu', true);
      const disk = interaction.options.getInteger('disk', true);
      const osId = interaction.options.getString('os', true) as OsId;
      const rawCpuModel = interaction.options.getString('cpu_model', true);
      const expire = interaction.options.getString('expire', true).trim();

      const matchedCpu =
        CPU_MODEL_CATALOG.find(
          (c) => c.model.toLowerCase() === rawCpuModel.trim().toLowerCase()
        )?.model || rawCpuModel.trim();

      const linkedEmail = getLinkedEmailForDiscord(targetUser.id);
      const existingMember = linkedEmail ? findMemberByEmailOrId(linkedEmail) : null;
      const assignEmail = linkedEmail || `${targetUser.username.toLowerCase()}@discord.user`;
      const ownerId = existingMember?.id || targetUser.id;

      const vm = await createVpsInstance(
        ownerId,
        {
          name: `vps-${targetUser.username.toLowerCase().replace(/[^a-z0-9-]/g, '') || 'node'}-${Math.floor(Math.random() * 900 + 100)}`,
          osId,
          vcpu,
          ramMb: ramGb * 1024,
          diskGb: disk,
          cpuModel: matchedCpu,
          expiresAt: expire,
        },
        assignEmail
      );

      // Keep Discord ownerId synced if member existed via email too
      const osInfo = getOsOption(vm.osId);
      let dmSent = false;

      // Send root password and full credentials PRIVATELY to target user's DM (NEVER in public channel!)
      try {
        const dmChannel = await targetUser.createDM();
        await dmChannel.send({
          embeds: [
            new EmbedBuilder()
              .setTitle('🚀 Your New VPS Has Been Provisioned!')
              .setColor(0x38bdf8)
              .setDescription(
                `Your VPS is online and ready! Use \`/manage\` in the server anytime to Start, Stop, Restart, get SSH / SSHX links, or Reinstall OS.` +
                  (linkedEmail
                    ? `\nIt is also synced to your Web Panel account (\`${linkedEmail}\`).`
                    : `\nRun \`/panel-link\` to register your Web Dashboard login and manage this VPS from the website too!`)
              )
              .addFields(
                { name: 'VPS Name', value: `\`${vm.name}\``, inline: true },
                { name: 'OS', value: osInfo.label, inline: true },
                { name: 'Private IP', value: `\`${vm.ipAddress}\``, inline: true },
                { name: 'CPU Model', value: vm.cpuModel, inline: false },
                {
                  name: 'Resources',
                  value: `${vcpu} vCPU • ${ramGb} GB RAM • ${disk} GB NVMe`,
                  inline: false,
                },
                { name: 'Root Password', value: `||\`Set via password reset\`||`, inline: true },
                { name: 'Expires', value: `\`${expire}\``, inline: true }
              )
              .setFooter({ text: 'Keep your root password private. Use /manage -> SSH or SSHX to connect.' })
              .setTimestamp(),
          ],
        });
        dmSent = true;
      } catch {
        dmSent = false;
      }

      // Confirmation message in channel — ZERO passwords or private credentials shown!
      const confirmEmbed = new EmbedBuilder()
        .setTitle('✅ VPS Created Successfully')
        .setColor(0x10b981)
        .addFields(
          { name: 'VPS Name', value: `\`${vm.name}\``, inline: true },
          { name: 'Assigned User', value: `<@${targetUser.id}>`, inline: true },
          { name: 'Operating System', value: osInfo.label, inline: true },
          { name: 'CPU Model', value: vm.cpuModel, inline: false },
          {
            name: 'Allocated Specs',
            value: `${vcpu} vCPU • ${ramGb} GB RAM • ${disk} GB Disk`,
            inline: true,
          },
          { name: 'Expires', value: `\`${expire}\``, inline: true },
          {
            name: 'Credentials Delivery',
            value: dmSent
              ? '📩 VPS details sent privately via DM; reset root password in panel.'
              : '⚠️ Could not DM user (DMs closed). User can manage the VPS and reset the password in the panel.',
            inline: false,
          }
        )
        .setTimestamp();

      await interaction.editReply({ embeds: [confirmEmbed] });
      return;
    }

    if (sub === 'list') {
      const all = listVpsInstances('admin-discord', true);
      const embed = new EmbedBuilder()
        .setTitle('🖥️ KilloraCloud VPS Cluster List')
        .setColor(0x0ea5e9)
        .setDescription(
          all.length === 0 ? 'No VPS instances found.' : `Total VPS Instances: **${all.length}**`
        );

      for (const vm of all.slice(0, 15)) {
        const osInfo = getOsOption(vm.osId);
        embed.addFields({
          name: `${vm.status === 'running' ? '🟢' : '🔴'} ${vm.name} (VMID ${vm.vmid})`,
          value: `OS: ${osInfo.label} | ${vm.vcpu} vCPU / ${formatRam(vm.ramMb)} / ${vm.diskGb}GB | Owner: \`${vm.ownerEmail || vm.ownerId}\`${vm.expiresAt ? ` | Exp: \`${vm.expiresAt}\`` : ''}`,
          inline: false,
        });
      }

      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    if (sub === 'renew' && targetUser) {
      const expire = interaction.options.getString('expire', true).trim();
      const userVms = getUserOwnedVpsList(interaction, targetUser.id, targetUser.username);
      if (userVms.length === 0) {
        await interaction.reply({
          content: `❌ No VPS instances found for <@${targetUser.id}>.`,
          ephemeral: true,
        });
        return;
      }

      const encodedExpire = encodeURIComponent(expire).slice(0, 40);
      const select = new StringSelectMenuBuilder()
        .setCustomId(`admrnw:${interaction.user.id}:${encodedExpire}`)
        .setPlaceholder('Select the VPS to renew...')
        .addOptions(
          userVms.slice(0, 25).map((vm) => ({
            label: `${vm.name} (${vm.status.toUpperCase()})`.slice(0, 100),
            description: `Current expiry: ${vm.expiresAt || 'None'} | ${vm.vcpu} vCPU / ${formatRam(vm.ramMb)}`.slice(0, 100),
            value: vm.id,
          }))
        );

      await interaction.reply({
        content: `📅 Select which VPS belonging to <@${targetUser.id}> to renew until **\`${expire}\`**:`,
        components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select)],
        ephemeral: true,
      });
      return;
    }

    if (sub === 'suspend' && targetUser) {
      const userVms = getUserOwnedVpsList(interaction, targetUser.id, targetUser.username);
      if (userVms.length === 0) {
        await interaction.reply({
          content: `❌ No VPS instances found for <@${targetUser.id}>.`,
          ephemeral: true,
        });
        return;
      }

      const select = new StringSelectMenuBuilder()
        .setCustomId(`admsus:${interaction.user.id}`)
        .setPlaceholder('Select the VPS to suspend...')
        .addOptions(
          userVms.slice(0, 25).map((vm) => ({
            label: `${vm.name} (${vm.status.toUpperCase()})`.slice(0, 100),
            description: `IP: ${vm.ipAddress} | ${vm.vcpu} vCPU / ${formatRam(vm.ramMb)}`.slice(0, 100),
            value: vm.id,
          }))
        );

      await interaction.reply({
        content: `⏸️ Select which VPS belonging to <@${targetUser.id}> you want to **suspend**:`,
        components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select)],
        ephemeral: true,
      });
      return;
    }

    if (sub === 'delete' && targetUser) {
      const userVms = getUserOwnedVpsList(interaction, targetUser.id, targetUser.username);
      if (userVms.length === 0) {
        await interaction.reply({
          content: `❌ No VPS instances found for <@${targetUser.id}>.`,
          ephemeral: true,
        });
        return;
      }

      const select = new StringSelectMenuBuilder()
        .setCustomId(`admdel:${interaction.user.id}`)
        .setPlaceholder('Select the VPS to delete...')
        .addOptions(
          userVms.slice(0, 25).map((vm) => ({
            label: `${vm.name} (${vm.status.toUpperCase()})`.slice(0, 100),
            description: `IP: ${vm.ipAddress} | ${vm.vcpu} vCPU / ${formatRam(vm.ramMb)}`.slice(0, 100),
            value: vm.id,
          }))
        );

      await interaction.reply({
        content: `🗑️ Select which VPS belonging to <@${targetUser.id}> you want to **delete** (confirmation will be required):`,
        components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select)],
        ephemeral: true,
      });
      return;
    }
  }
}

async function handleModalSubmit(interaction: ModalSubmitInteraction) {
  if (interaction.customId === 'plink_modal_submit') {
    const email = interaction.fields.getTextInputValue('panel_email');
    const username = interaction.fields.getTextInputValue('panel_username');
    const password = interaction.fields.getTextInputValue('panel_password');

    pendingPanelLinks.delete(interaction.user.id);

    try {
      const result = completePanelLink(interaction.user, email, username, password);
      const settings = getSiteSettings();
      const embed = new EmbedBuilder()
        .setTitle(
          result.createdNew
            ? '✅ Panel Account Registered & Linked!'
            : '✅ Existing Panel Account Linked!'
        )
        .setColor(0x10b981)
        .setDescription(
          `Your Discord account (**${interaction.user.tag}**) is now connected to **${settings.siteName || 'KilloraCloud'}**!\n\n` +
            `You can now use \`/manage\` on Discord AND sign in on the Web Dashboard.`
        )
        .addFields(
          { name: 'Email', value: `\`${result.email}\``, inline: true },
          { name: 'Username', value: `\`${result.username}\``, inline: true },
          { name: 'Synced VPS', value: `${result.syncedVpsCount}`, inline: true }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (err) {
      await interaction.reply({
        content: `❌ Failed to link account: ${err instanceof Error ? err.message : 'Unknown error'}`,
        ephemeral: true,
      });
    }
  }
}

async function handleSelectMenuInteraction(interaction: StringSelectMenuInteraction) {
  const parts = interaction.customId.split(':');
  const prefix = parts[0];

  // Member /manage VPS selection
  if (prefix === 'mngsel') {
    const ownerDiscordId = parts[1];
    if (interaction.user.id !== ownerDiscordId) {
      await interaction.reply({ content: '❌ This is not your VPS!', ephemeral: true });
      return;
    }

    const vpsId = interaction.values[0];
    const vm = getVpsInstance(vpsId);
    if (!vm) {
      await interaction.reply({ content: '❌ VPS instance no longer exists.', ephemeral: true });
      return;
    }

    if (!canUserControlVps(interaction, vm)) {
      await interaction.reply({ content: '❌ This is not your VPS!', ephemeral: true });
      return;
    }

    await interaction.update(buildVpsControlPanelPayload(ownerDiscordId, vm));
    return;
  }

  // Member Reinstall OS dropdown selection (ephemeral — main /manage panel stays untouched!)
  if (prefix === 'mngreinst') {
    const ownerDiscordId = parts[1];
    const vpsId = parts[2];

    if (interaction.user.id !== ownerDiscordId) {
      await interaction.reply({ content: '❌ This is not your VPS!', ephemeral: true });
      return;
    }

    const vm = getVpsInstance(vpsId);
    if (!vm || !canUserControlVps(interaction, vm)) {
      await interaction.reply({ content: '❌ This is not your VPS!', ephemeral: true });
      return;
    }

    const newOsId = interaction.values[0] as OsId;
    await interaction.deferUpdate();

    const updated = await reinstallVpsInstance(vpsId, newOsId);
    const osInfo = getOsOption(updated.osId);

    await interaction.editReply({
      content: '',
      embeds: [
        new EmbedBuilder()
          .setTitle('✅ OS Reinstalled Successfully')
          .setColor(0x10b981)
          .setDescription(
            `VPS **${updated.name}** has been freshly reinstalled with **${osInfo.label}**.\n` +
              `Click **Refresh** on your \`/manage\` panel to see the updated OS & live status.`
          )
          .addFields(
            { name: 'New OS', value: osInfo.label, inline: true },
            { name: 'Status', value: updated.status.toUpperCase(), inline: true },
            { name: 'Root Password', value: `||\`Set via password reset\`||`, inline: true }
          )
          .setTimestamp(),
      ],
      components: [],
    });
    return;
  }

  // Admin /vps renew selection
  if (prefix === 'admrnw') {
    const adminId = parts[1];
    const expire = decodeURIComponent(parts.slice(2).join(':'));
    if (interaction.user.id !== adminId || !isDiscordVpsAdmin(interaction)) {
      await interaction.reply({ content: '❌ Unauthorized action.', ephemeral: true });
      return;
    }

    const vpsId = interaction.values[0];
    const updated = renewVpsExpiry(vpsId, expire);
    await interaction.update({
      content: `✅ VPS **${updated.name}** renewed! New expiration date: **\`${updated.expiresAt}\`**.`,
      components: [],
    });
    return;
  }

  // Admin /vps suspend selection
  if (prefix === 'admsus') {
    const adminId = parts[1];
    if (interaction.user.id !== adminId || !isDiscordVpsAdmin(interaction)) {
      await interaction.reply({ content: '❌ Unauthorized action.', ephemeral: true });
      return;
    }

    const vpsId = interaction.values[0];
    await interaction.deferUpdate();
    const updated = await setVpsPowerState(vpsId, 'stop');
    await interaction.editReply({
      content: `⏸️ VPS **${updated.name}** has been suspended (powered off).`,
      components: [],
    });
    return;
  }

  // Admin /vps delete selection -> asks for explicit confirmation!
  if (prefix === 'admdel') {
    const adminId = parts[1];
    if (interaction.user.id !== adminId || !isDiscordVpsAdmin(interaction)) {
      await interaction.reply({ content: '❌ Unauthorized action.', ephemeral: true });
      return;
    }

    const vpsId = interaction.values[0];
    const vm = getVpsInstance(vpsId);
    if (!vm) {
      await interaction.update({ content: '❌ VPS not found.', components: [] });
      return;
    }

    const osInfo = getOsOption(vm.osId);
    const confirmEmbed = new EmbedBuilder()
      .setTitle('⚠️ Confirm Permanent VPS Deletion')
      .setColor(0xef4444)
      .setDescription(
        `Are you sure you want to permanently delete **${vm.name}**?\nThis will destroy all container data and cannot be undone.`
      )
      .addFields(
        { name: 'VPS Name', value: `\`${vm.name}\``, inline: true },
        { name: 'OS', value: osInfo.label, inline: true },
        { name: 'Owner', value: `\`${vm.ownerEmail || vm.ownerId}\``, inline: true }
      );

    const confirmRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`admdel_yes:${adminId}:${vm.id}`)
        .setLabel('Yes, Delete Permanently')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('🗑️'),
      new ButtonBuilder()
        .setCustomId(`admdel_no:${adminId}:${vm.id}`)
        .setLabel('Cancel')
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.update({
      content: '',
      embeds: [confirmEmbed],
      components: [confirmRow],
    });
  }
}

async function handleButtonInteraction(interaction: ButtonInteraction) {
  const parts = interaction.customId.split(':');
  const prefix = parts[0];

  // Panel-link modal button / cancel button
  if (prefix === 'plink_open_modal') {
    const targetId = parts[1];
    if (targetId && interaction.user.id !== targetId) {
      await interaction.reply({ content: '❌ Run `/panel-link` yourself to link your account.', ephemeral: true });
      return;
    }
    await interaction.showModal(buildPanelLinkModal());
    return;
  }

  if (prefix === 'plink_cancel') {
    pendingPanelLinks.delete(interaction.user.id);
    await interaction.update({ content: '❌ Panel linking cancelled.', embeds: [], components: [] });
    return;
  }

  // Admin delete confirmation buttons
  if (prefix === 'admdel_yes') {
    const adminId = parts[1];
    const vpsId = parts[2];
    if (interaction.user.id !== adminId || !isDiscordVpsAdmin(interaction)) {
      await interaction.reply({ content: '❌ Unauthorized action.', ephemeral: true });
      return;
    }

    const vm = getVpsInstance(vpsId);
    const vmName = vm?.name || vpsId;
    await interaction.deferUpdate();
    await deleteVpsInstance(vpsId);
    await interaction.editReply({
      content: `🗑️ VPS **${vmName}** has been permanently deleted.`,
      embeds: [],
      components: [],
    });
    return;
  }

  if (prefix === 'admdel_no') {
    const adminId = parts[1];
    if (interaction.user.id !== adminId) {
      await interaction.reply({ content: '❌ Unauthorized action.', ephemeral: true });
      return;
    }
    await interaction.update({
      content: '✅ Deletion cancelled. VPS was not deleted.',
      embeds: [],
      components: [],
    });
    return;
  }

  // Member /manage panel buttons — NEVER delete the panel & strictly enforce ownership!
  if (prefix === 'mngbtn') {
    const ownerDiscordId = parts[1];
    const action = parts[2];
    const vpsId = parts[3];

    // Ownership check #1: must be the user who owns this panel
    if (interaction.user.id !== ownerDiscordId) {
      await interaction.reply({ content: '❌ This is not your VPS!', ephemeral: true });
      return;
    }

    // Back to VPS List
    if (action === 'list') {
      const linkedEmail = getLinkedEmailForDiscord(ownerDiscordId);
      const userVms = getUserOwnedVpsList(interaction);
      if (userVms.length === 0) {
        await interaction.reply({ content: '❌ No VPS instances found.', ephemeral: true });
        return;
      }
      await interaction.update(buildManageListPayload(ownerDiscordId, userVms, linkedEmail));
      return;
    }

    const vm = getVpsInstance(vpsId);
    if (!vm) {
      await interaction.reply({ content: '❌ VPS instance no longer exists.', ephemeral: true });
      return;
    }

    // Ownership check #2: must own this VPS
    if (!canUserControlVps(interaction, vm)) {
      await interaction.reply({ content: '❌ This is not your VPS!', ephemeral: true });
      return;
    }

    // Power & Refresh actions update the panel in-place (panel is NEVER deleted!)
    if (action === 'start' || action === 'stop' || action === 'restart' || action === 'refresh') {
      await interaction.deferUpdate();
      let updatedVm = vm;
      if (action === 'start') {
        updatedVm = await setVpsPowerState(vpsId, 'start');
      } else if (action === 'stop') {
        updatedVm = await setVpsPowerState(vpsId, 'stop');
      } else if (action === 'restart') {
        updatedVm = await setVpsPowerState(vpsId, 'reboot');
      } else {
        updatedVm = getVpsInstance(vpsId) || vm;
      }
      await interaction.editReply(buildVpsControlPanelPayload(ownerDiscordId, updatedVm));
      return;
    }

    // Real SSH (Pinggy / Bore) — sends private ephemeral credentials while panel stays untouched!
    if (action === 'ssh') {
      await interaction.deferReply({ ephemeral: true });
      if (vm.status !== 'running') {
        await interaction.editReply({
          content: '⚠️ Your VPS is currently stopped. Click **▶️ Start** on the panel first, then click **🔐 SSH**.',
        });
        return;
      }

      const updatedVm = vm.publicSsh?.active ? vm : await enableVpsPublicSsh(vpsId);
      const sshCommand = updatedVm.publicSsh?.command || `ssh root@${updatedVm.ipAddress} -p 22`;

      // Update panel status badge safely in background without deleting it
      await interaction.message
        .edit(buildVpsControlPanelPayload(ownerDiscordId, updatedVm))
        .catch(() => {});

      const sshEmbed = new EmbedBuilder()
        .setTitle(`🔐 Direct SSH Access — ${updatedVm.name}`)
        .setColor(0x0ea5e9)
        .setDescription('Copy and paste the real SSH command below into Termius, Termux, or your terminal:')
        .addFields(
          { name: 'SSH Command', value: `\`\`\`bash\n${sshCommand}\n\`\`\``, inline: false },
          { name: 'Host', value: `\`${updatedVm.publicSsh?.host || updatedVm.ipAddress}\``, inline: true },
          { name: 'Port', value: `\`${updatedVm.publicSsh?.port || 22}\``, inline: true },
          { name: 'Username', value: '`root`', inline: true },
          { name: 'Root Password', value: `||\`Set via password reset\`||`, inline: false }
        )
        .setFooter({ text: `Provider: ${updatedVm.publicSsh?.provider || 'direct'} • Only visible to you` })
        .setTimestamp();

      await interaction.editReply({ embeds: [sshEmbed] });
      return;
    }

    // Real SSHX (sshx.io) — launches genuine sshx.io web terminal bound to this VPS shell!
    if (action === 'sshx') {
      await interaction.deferReply({ ephemeral: true });
      if (vm.status !== 'running') {
        await interaction.editReply({
          content: '⚠️ Your VPS is currently stopped. Click **▶️ Start** on the panel first, then click **🌐 SSHX**.',
        });
        return;
      }

      const updatedVm = vm.sshxSession?.active ? vm : await enableVpsSshx(vpsId);
      const sshxUrl = updatedVm.sshxSession?.url;

      // Update panel status badge safely in background without deleting it
      await interaction.message
        .edit(buildVpsControlPanelPayload(ownerDiscordId, updatedVm))
        .catch(() => {});

      if (!sshxUrl) {
        await interaction.editReply({
          content: '❌ Could not obtain sshx.io session URL. Please try again in a moment.',
        });
        return;
      }

      const sshxEmbed = new EmbedBuilder()
        .setTitle(`🌐 Real SSHX Web Terminal — ${updatedVm.name}`)
        .setColor(0x8b5cf6)
        .setDescription(
          `Your live **sshx.io** browser terminal is active and connected directly to \`root@${updatedVm.hostname}\`!\n\n` +
            `**Open Terminal:** ${sshxUrl}`
        )
        .addFields({ name: 'Direct sshx.io URL', value: `\`${sshxUrl}\``, inline: false })
        .setFooter({ text: 'Only visible to you • Powered by sshx.io' })
        .setTimestamp();

      await interaction.editReply({ embeds: [sshxEmbed] });
      return;
    }

    // Reinstall OS — sends private ephemeral OS picker while keeping the main /manage panel untouched!
    if (action === 'reinstall') {
      const osSelect = new StringSelectMenuBuilder()
        .setCustomId(`mngreinst:${ownerDiscordId}:${vm.id}`)
        .setPlaceholder('Choose a new Operating System to install...')
        .addOptions(
          OS_CATALOG.map((o) => ({
            label: o.label.slice(0, 100),
            description: o.description.slice(0, 100),
            value: o.id,
          }))
        );

      await interaction.reply({
        content: `💿 Select the new OS to freshly reinstall on **${vm.name}** *(warning: wipes current VPS files)*:`,
        components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(osSelect)],
        ephemeral: true,
      });
      return;
    }
  }
}
