import { spawn, type ChildProcess } from 'child_process';
import fs from 'fs';
import path from 'path';

export type PanelTunnelMode = 'token' | 'quick';
export type PanelTunnelStatusState = 'idle' | 'installing' | 'connecting' | 'connected' | 'error';

export interface PanelTunnelStatus {
  status: PanelTunnelStatusState;
  mode: PanelTunnelMode | null;
  publicUrl: string | null;
  customUrl: string;
  targetUrl: string;
  connectedAt: string | null;
  edgeConnections: number;
  usesEnvToken: boolean;
  binaryReady: boolean;
  error: string | null;
  logs: string[];
}

interface TunnelPrefs {
  customUrl: string;
}

const DATA_ROOT = path.resolve(process.cwd(), '.killoracloud-data');
const BIN_DIR = path.join(DATA_ROOT, 'bin');
const LOCAL_BIN_PATH = path.join(BIN_DIR, 'cloudflared');
const PREFS_FILE = path.join(DATA_ROOT, 'panel-tunnel-prefs.json');

const PANEL_PORT = Number(process.env.PORT) || 3000;
const PANEL_TARGET_URL = `http://127.0.0.1:${PANEL_PORT}`;

const TOKEN_REGEX = /^[A-Za-z0-9._=-]{20,2048}$/;
const TRYCLOUDFLARE_REGEX = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/i;

let activeChild: ChildProcess | null = null;
let activeTokenSecret: string | null = null;
let status: PanelTunnelStatusState = 'idle';
let mode: PanelTunnelMode | null = null;
let publicUrl: string | null = null;
let connectedAt: string | null = null;
let edgeConnections = 0;
let lastError: string | null = null;
let logs: string[] = [];

function loadPrefs(): TunnelPrefs {
  const envUrl = sanitizePublicUrl(process.env.CLOUDFLARE_CUSTOM_URL || '');
  try {
    if (fs.existsSync(PREFS_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(PREFS_FILE, 'utf8'));
      const savedUrl = sanitizePublicUrl(typeof parsed?.customUrl === 'string' ? parsed.customUrl : '');
      return { customUrl: savedUrl || envUrl };
    }
  } catch {
    // ignore corrupted prefs
  }
  return { customUrl: envUrl };
}

function savePrefs(prefs: TunnelPrefs): void {
  fs.mkdirSync(DATA_ROOT, { recursive: true, mode: 0o755 });
  fs.writeFileSync(PREFS_FILE, JSON.stringify({ customUrl: prefs.customUrl }, null, 2), 'utf8');
}

let customUrl = loadPrefs().customUrl;

export function sanitizePublicUrl(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  try {
    const parsed = new URL(withScheme);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return '';
    if (!parsed.hostname || parsed.hostname.length > 253) return '';
    if (/[<>"'`\s]/.test(parsed.href)) return '';
    return `${parsed.protocol}//${parsed.host}`;
  } catch {
    return '';
  }
}

export function extractAndValidateToken(rawInput: string): string {
  let cleaned = rawInput.trim();
  // Support pasting Cloudflare's full install snippet: `cloudflared service install eyJ...` or `--token eyJ...`
  const installMatch = cleaned.match(/(?:service\s+install|--token)\s+([A-Za-z0-9._=-]{20,2048})/i);
  if (installMatch?.[1]) {
    cleaned = installMatch[1];
  } else if (cleaned.includes(' ')) {
    const parts = cleaned.split(/\s+/).filter(Boolean);
    const candidate = parts[parts.length - 1] || '';
    cleaned = candidate;
  }
  if (!TOKEN_REGEX.test(cleaned)) {
    throw new Error(
      'Invalid Cloudflare Tunnel Token. Paste the token from Cloudflare Zero Trust → Networks → Tunnels.'
    );
  }
  return cleaned;
}

function redactSecrets(line: string): string {
  let safe = line.replace(/\r/g, '').trimEnd();
  if (activeTokenSecret && activeTokenSecret.length > 8) {
    safe = safe.split(activeTokenSecret).join('[REDACTED_TOKEN]');
  }
  const envTok = process.env.CLOUDFLARE_TUNNEL_TOKEN?.trim();
  if (envTok && envTok.length > 8) {
    safe = safe.split(envTok).join('[REDACTED_TOKEN]');
  }
  return safe;
}

function pushLog(line: string): void {
  const clean = redactSecrets(line);
  if (!clean) return;
  logs.push(clean);
  if (logs.length > 40) {
    logs = logs.slice(-40);
  }
}

function findCloudflaredBinary(): string | null {
  if (fs.existsSync(LOCAL_BIN_PATH)) {
    try {
      fs.accessSync(LOCAL_BIN_PATH, fs.constants.X_OK);
      return LOCAL_BIN_PATH;
    } catch {
      // fall through
    }
  }
  for (const candidate of ['/usr/local/bin/cloudflared', '/usr/bin/cloudflared']) {
    if (fs.existsSync(candidate)) return candidate;
  }
  return null;
}

async function ensureCloudflaredBinary(): Promise<string> {
  const existing = findCloudflaredBinary();
  if (existing) return existing;

  status = 'installing';
  pushLog('Downloading official cloudflared binary...');
  fs.mkdirSync(BIN_DIR, { recursive: true, mode: 0o755 });

  const arch = process.arch === 'arm64' ? 'arm64' : 'amd64';
  const downloadUrl = `https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${arch}`;
  const res = await fetch(downloadUrl, { redirect: 'follow' });
  if (!res.ok) {
    throw new Error(`Failed to download cloudflared (${res.status})`);
  }
  const buf = Buffer.from(await res.arrayBuffer());
  const tmpPath = `${LOCAL_BIN_PATH}.tmp`;
  fs.writeFileSync(tmpPath, buf, { mode: 0o755 });
  fs.renameSync(tmpPath, LOCAL_BIN_PATH);
  fs.chmodSync(LOCAL_BIN_PATH, 0o755);
  pushLog('cloudflared installed successfully.');
  return LOCAL_BIN_PATH;
}

export function getPanelTunnelStatus(): PanelTunnelStatus {
  return {
    status,
    mode,
    publicUrl,
    customUrl,
    targetUrl: PANEL_TARGET_URL,
    connectedAt,
    edgeConnections,
    usesEnvToken: Boolean(process.env.CLOUDFLARE_TUNNEL_TOKEN?.trim()),
    binaryReady: Boolean(findCloudflaredBinary()),
    error: lastError,
    logs: [...logs],
  };
}

export function stopPanelTunnel(): PanelTunnelStatus {
  if (activeChild) {
    try {
      activeChild.kill('SIGTERM');
    } catch {
      // ignore
    }
    activeChild = null;
  }
  activeTokenSecret = null;
  status = 'idle';
  mode = null;
  publicUrl = null;
  connectedAt = null;
  edgeConnections = 0;
  lastError = null;
  pushLog('Panel Cloudflare Tunnel stopped.');
  return getPanelTunnelStatus();
}

export async function startPanelTunnel(options: {
  mode: PanelTunnelMode;
  token?: string;
  customUrl?: string;
}): Promise<PanelTunnelStatus> {
  // Stop any existing tunnel process cleanly first
  if (activeChild) {
    try {
      activeChild.kill('SIGTERM');
    } catch {
      // ignore
    }
    activeChild = null;
  }

  lastError = null;
  edgeConnections = 0;
  connectedAt = null;
  publicUrl = null;
  logs = [];

  const targetMode: PanelTunnelMode = options.mode === 'quick' ? 'quick' : 'token';
  mode = targetMode;

  if (typeof options.customUrl === 'string') {
    const cleanedUrl = sanitizePublicUrl(options.customUrl);
    if (options.customUrl.trim() && !cleanedUrl) {
      status = 'error';
      lastError = 'Invalid custom domain URL. Example: https://panel.yourdomain.com';
      throw new Error(lastError);
    }
    customUrl = cleanedUrl;
    savePrefs({ customUrl });
  }

  let tokenToUse: string | null = null;
  if (targetMode === 'token') {
    const provided = typeof options.token === 'string' && options.token.trim()
      ? options.token.trim()
      : (process.env.CLOUDFLARE_TUNNEL_TOKEN || '').trim();
    if (!provided) {
      status = 'error';
      lastError = 'Cloudflare Tunnel Token is required to connect your custom domain.';
      throw new Error(lastError);
    }
    tokenToUse = extractAndValidateToken(provided);
  }

  const binPath = await ensureCloudflaredBinary();
  status = 'connecting';
  activeTokenSecret = tokenToUse;

  const args =
    targetMode === 'token'
      ? ['tunnel', '--no-autoupdate', '--protocol', 'http2', 'run']
      : ['tunnel', '--no-autoupdate', '--protocol', 'http2', '--url', PANEL_TARGET_URL];

  const env: NodeJS.ProcessEnv = { ...process.env };
  if (tokenToUse) {
    // Pass token via environment variable instead of CLI argv so it never shows in process lists
    env.TUNNEL_TOKEN = tokenToUse;
  } else {
    delete env.TUNNEL_TOKEN;
  }

  pushLog(
    targetMode === 'token'
      ? `Connecting KilloraCloud Panel (${PANEL_TARGET_URL}) to your Cloudflare Zero Trust custom domain tunnel...`
      : `Starting instant Cloudflare Quick Tunnel for KilloraCloud Panel (${PANEL_TARGET_URL})...`
  );

  const child = spawn(binPath, args, {
    shell: false,
    stdio: ['ignore', 'pipe', 'pipe'],
    env,
  });

  activeChild = child;

  return new Promise<PanelTunnelStatus>((resolve, reject) => {
    let settled = false;
    const finishResolve = () => {
      if (!settled) {
        settled = true;
        clearTimeout(startupTimer);
        resolve(getPanelTunnelStatus());
      }
    };
    const finishReject = (msg: string) => {
      if (!settled) {
        settled = true;
        clearTimeout(startupTimer);
        reject(new Error(msg));
      }
    };

    const handleOutput = (rawBuf: Buffer) => {
      const text = rawBuf.toString('utf8');
      for (const rawLine of text.split(/\r?\n/)) {
        if (!rawLine.trim()) continue;
        pushLog(rawLine);

        // Quick tunnel URL detection
        if (targetMode === 'quick') {
          const urlMatch = rawLine.match(TRYCLOUDFLARE_REGEX);
          if (urlMatch?.[0]) {
            publicUrl = urlMatch[0];
            status = 'connected';
            connectedAt = connectedAt || new Date().toISOString();
            finishResolve();
          }
        }

        // Edge connection registration detection (applies to both token and quick tunnels)
        if (/Registered tunnel connection/i.test(rawLine)) {
          edgeConnections += 1;
          connectedAt = connectedAt || new Date().toISOString();
          if (targetMode === 'token') {
            publicUrl = customUrl || null;
            status = 'connected';
            finishResolve();
          }
        }

        // Auth / token errors
        if (
          /Unauthorized|Invalid tunnel secret|failed to decode token|Provided Tunnel token is not valid/i.test(
            rawLine
          )
        ) {
          lastError = 'Cloudflare rejected the Tunnel Token. Check your token in Zero Trust Dashboard.';
          status = 'error';
          finishReject(lastError);
        }
      }
    };

    child.stdout?.on('data', handleOutput);
    child.stderr?.on('data', handleOutput);

    child.on('error', (err) => {
      if (activeChild === child) {
        activeChild = null;
        status = 'error';
        lastError = err.message;
        pushLog(`cloudflared error: ${err.message}`);
      }
      finishReject(err.message);
    });

    child.on('exit', (code) => {
      if (activeChild === child) {
        activeChild = null;
        if (status !== 'idle') {
          status = 'error';
          lastError = lastError || `cloudflared exited unexpectedly (code ${code ?? 'unknown'})`;
          pushLog(lastError);
        }
      }
      finishReject(lastError || `cloudflared exited (code ${code ?? 'unknown'})`);
    });

    const startupTimer = setTimeout(() => {
      if (!settled) {
        // Still connecting or connected without matching line yet — return current status cleanly
        if (status === 'connecting' && edgeConnections > 0) {
          status = 'connected';
        }
        finishResolve();
      }
    }, 10_000);
  });
}

export async function bootstrapEnvPanelTunnel(): Promise<void> {
  const envToken = process.env.CLOUDFLARE_TUNNEL_TOKEN?.trim();
  if (!envToken) return;
  try {
    await startPanelTunnel({
      mode: 'token',
      token: envToken,
      customUrl: customUrl || process.env.CLOUDFLARE_CUSTOM_URL || '',
    });
    console.log('Cloudflare Panel Tunnel auto-connected from CLOUDFLARE_TUNNEL_TOKEN.');
  } catch (err) {
    console.warn(
      'Cloudflare Panel Tunnel auto-start warning:',
      err instanceof Error ? err.message : String(err)
    );
  }
}
