# KilloraCloud Firestore Security Specification (Phase 0 TDD)

## 1. Data Invariants
1. **Default-Deny Safety**: Every document path not explicitly matched is denied (`allow read, write: if false`).
2. **PII Isolation**: `/users/{userId}` contains email and profile data; strictly readable/writable only by `isOwner(userId)` or `isAdmin()`.
3. **Verified Identity & Admin Integrity**: All mutations require `request.auth != null && request.auth.token.email_verified == true`. Self-assigned admin roles are strictly blocked on create and update.
4. **VPS & Tunnel Ownership**: Every document in `/users/{userId}/vps_instances/{vpsId}`, `/users/{userId}/tunnels/{tunnelId}`, and `/users/{userId}/members/{memberId}` MUST enforce `ownerId == userId == request.auth.uid` (or `isAdmin()`), immutable `ownerId` and `createdAt`, strict `hasAll` + `hasOnly` key sets, and string length limits matching `firebase-blueprint.json`.
5. **Path ID Hardening**: All single-document operations (`get`, `create`, `update`, `delete`) validate path IDs with `isValidId()` (`^[a-zA-Z0-9_-]{1,128}$`).
6. **Secure List Queries**: Every `allow list` validates `resource.data.ownerId == request.auth.uid || isAdmin()` without calling `get()`/`exists()` inside list rules.

## 2. The Dirty Dozen Adversarial Payloads
1. **Unauthenticated VPS Read**: `auth = null` attempting `get /users/u1/vps_instances/vps-100` -> `PERMISSION_DENIED`.
2. **Unverified Email Write**: `auth = { uid: 'u1', token: { email: 'a@b.com', email_verified: false } }` creating VPS -> `PERMISSION_DENIED`.
3. **Admin Email Spoof (Unverified)**: `auth = { uid: 'attacker', token: { email: 'binad5215@gmail.com', email_verified: false } }` reading another user's profile -> `PERMISSION_DENIED`.
4. **Cross-Tenant PII Leak**: Authenticated `u2` attempting `get /users/u1` -> `PERMISSION_DENIED`.
5. **Self-Assigned Admin Privilege Escalation**: `u2` creating `/users/u2` with `role: 'admin'` -> `PERMISSION_DENIED`.
6. **Shadow Field Injection (Ghost Field)**: `u1` creating VPS with extra key `isSuperAdmin: true` -> `PERMISSION_DENIED`.
7. **OwnerId Spoofing on Create**: `u1` creating `/users/u1/vps_instances/vps-101` with `ownerId: 'u2'` -> `PERMISSION_DENIED`.
8. **Immutable Field Tampering on Update**: `u1` updating `createdAt` or `ownerId` on existing VPS -> `PERMISSION_DENIED`.
9. **ID Poisoning / Denial of Wallet**: `u1` creating VPS with 500-character document ID containing `$../` -> `PERMISSION_DENIED`.
10. **Value Poisoning (Type Mismatch)**: `u1` updating `vcpu: "unlimited"` (string instead of number) -> `PERMISSION_DENIED`.
11. **Oversized Payload Attack**: `u1` writing 50KB `name` string into VPS record (exceeds `maxLength: 80`) -> `PERMISSION_DENIED`.
12. **Cross-User Tunnel Deletion**: `u2` attempting `delete /users/u1/tunnels/tun-1` -> `PERMISSION_DENIED`.
