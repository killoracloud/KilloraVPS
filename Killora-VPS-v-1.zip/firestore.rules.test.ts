/**
 * Firestore Security Rules Verification Spec (Dirty Dozen Adversarial Suite)
 * Matches security_spec.md and firestore.rules.
 */
export interface DirtyDozenCase {
  id: number;
  name: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  path: string;
  auth: { uid: string; email?: string; email_verified?: boolean } | null;
  payload?: Record<string, unknown>;
  expected: 'PERMISSION_DENIED';
}

export const DIRTY_DOZEN_TESTS: DirtyDozenCase[] = [
  {
    id: 1,
    name: 'Unauthenticated VPS read',
    operation: 'get',
    path: '/users/u1/vps_instances/vps-100',
    auth: null,
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: 'Unverified email VPS create',
    operation: 'create',
    path: '/users/u1/vps_instances/vps-100',
    auth: { uid: 'u1', email: 'u1@example.com', email_verified: false },
    payload: { id: 'vps-100', ownerId: 'u1', name: 'node1' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'Admin email spoof without email_verified',
    operation: 'get',
    path: '/users/u1',
    auth: { uid: 'attacker', email: 'binad5215@gmail.com', email_verified: false },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'Cross-tenant PII read',
    operation: 'get',
    path: '/users/u1',
    auth: { uid: 'u2', email: 'u2@example.com', email_verified: true },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'Self-assigned admin role escalation',
    operation: 'create',
    path: '/users/u2',
    auth: { uid: 'u2', email: 'u2@example.com', email_verified: true },
    payload: {
      uid: 'u2',
      email: 'u2@example.com',
      displayName: 'User 2',
      role: 'admin',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Shadow ghost field injection',
    operation: 'create',
    path: '/users/u1/vps_instances/vps-101',
    auth: { uid: 'u1', email: 'u1@example.com', email_verified: true },
    payload: {
      id: 'vps-101',
      ownerId: 'u1',
      vmid: 101,
      name: 'vm1',
      hostname: 'vm1',
      osId: 'proxmox-9',
      status: 'running',
      vcpu: 4,
      ramMb: 4096,
      diskGb: 60,
      cpuModel: 'AMD EPYC',
      ipAddress: '10.10.10.2',
      nodeName: 'pve-node-01',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
      isSuperAdmin: true,
    },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'OwnerId spoofing on create',
    operation: 'create',
    path: '/users/u1/vps_instances/vps-102',
    auth: { uid: 'u1', email: 'u1@example.com', email_verified: true },
    payload: { id: 'vps-102', ownerId: 'u2' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Immutable createdAt tampering on update',
    operation: 'update',
    path: '/users/u1/vps_instances/vps-100',
    auth: { uid: 'u1', email: 'u1@example.com', email_verified: true },
    payload: { createdAt: '1999-01-01T00:00:00Z' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: 'Invalid path ID poisoning',
    operation: 'create',
    path: '/users/u1/vps_instances/../../evil$id',
    auth: { uid: 'u1', email: 'u1@example.com', email_verified: true },
    payload: { id: 'evil' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'Type mismatch value poisoning on vcpu',
    operation: 'update',
    path: '/users/u1/vps_instances/vps-100',
    auth: { uid: 'u1', email: 'u1@example.com', email_verified: true },
    payload: { vcpu: 'unlimited' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'Oversized VPS name string exceeding 80 chars',
    operation: 'update',
    path: '/users/u1/vps_instances/vps-100',
    auth: { uid: 'u1', email: 'u1@example.com', email_verified: true },
    payload: { name: 'A'.repeat(500) },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'Cross-user tunnel deletion',
    operation: 'delete',
    path: '/users/u1/tunnels/tun-1',
    auth: { uid: 'u2', email: 'u2@example.com', email_verified: true },
    expected: 'PERMISSION_DENIED',
  },
];
