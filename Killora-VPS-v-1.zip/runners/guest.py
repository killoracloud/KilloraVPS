# Host-side Podman adapter. Never execute customer commands on the host.
import os, sys
if len(sys.argv)<2: sys.exit(2)
os.execvp('podman',['podman',*sys.argv[1:]])
