import java.util.*;
class Guest {
 public static void main(String[] args) throws Exception {
  if(args.length==0) System.exit(2);
  var cmd=new ArrayList<String>();cmd.add("podman");cmd.addAll(Arrays.asList(args));
  var p=new ProcessBuilder(cmd).inheritIO().start();
  Runtime.getRuntime().addShutdownHook(new Thread(()->p.destroyForcibly()));
  System.exit(p.waitFor());
 }
}
