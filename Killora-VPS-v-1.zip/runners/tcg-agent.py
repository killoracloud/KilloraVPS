import socket,json,sys,time,base64,fcntl,os
# Serialize QGA clients: the guest-agent channel is shared.
if sys.argv[2] != "--qmp":
 lock=os.open(sys.argv[1]+".lock",os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
 deadline=time.monotonic()+10
 while True:
  try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB); break
  except BlockingIOError:
   if time.monotonic()>deadline: raise RuntimeError("Guest agent busy")
   time.sleep(.1)
s=socket.socket(socket.AF_UNIX); s.settimeout(10); s.connect(sys.argv[1]); f=s.makefile('rwb'); seq=0
def call(cmd,args=None):
 global seq
 seq+=1; req={'execute':cmd,'id':seq}
 if args is not None: req['arguments']=args
 f.write(json.dumps(req).encode()+b'\n'); f.flush()
 while True:
  line=f.readline(2097152)
  if not line: raise RuntimeError('Disconnected')
  m=json.loads(line)
  if m.get('id')==seq:
   if 'error' in m: raise RuntimeError('Guest command failed')
   return m['return']
if sys.argv[2]=='--qmp':
 if sys.argv[3] not in ('query-status','quit','system_reset','stop','cont'): raise RuntimeError('Invalid QMP command')
 f.readline(65536); call('qmp_capabilities'); print(json.dumps(call(sys.argv[3]))); sys.exit(0)
args=sys.argv[2:]; data=sys.stdin.buffer.read(65537)
if len(data)>65536: raise RuntimeError('Input too large')
p={'path':args[0],'arg':args[1:],'capture-output':True}
if data: p['input-data']=base64.b64encode(data).decode()
pid=call('guest-exec',p)['pid']; deadline=time.monotonic()+90
while time.monotonic()<deadline:
 r=call('guest-exec-status',{'pid':pid})
 if r.get('exited'):
  sys.stdout.buffer.write(base64.b64decode(r.get('out-data',''))); sys.stderr.buffer.write(base64.b64decode(r.get('err-data',''))); sys.exit(r.get('exitcode',1))
 time.sleep(.25)
raise RuntimeError('Guest command timed out')
