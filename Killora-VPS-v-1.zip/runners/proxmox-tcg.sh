#!/bin/sh
set -eu
exec java "$(dirname "$0")/ProxmoxTCG.java" "$@"
