import java.nio.file.*;
import java.util.*;
class ProxmoxTCG {
 public static void main(String[] args) throws Exception {
  if(args.length != 5) throw new IllegalArgumentException("Usage: ProxmoxTCG.java install|boot disk iso-or-dash RAM-MiB CPUs");
  String mode=args[0]; if(!Set.of("install","boot").contains(mode)) throw new IllegalArgumentException("Invalid mode");
  Path disk=Path.of(args[1]).toRealPath(); if(!Files.isRegularFile(disk)) throw new IllegalArgumentException("Disk must be a regular file");
  int ram=Integer.parseInt(args[3]), cpu=Integer.parseInt(args[4]); if(ram<2048||ram>131072||cpu<1||cpu>64) throw new IllegalArgumentException("Invalid resources");
  var cmd=new ArrayList<>(List.of("qemu-system-x86_64","-accel","tcg,thread=multi","-machine","q35","-cpu","max","-m",String.valueOf(ram),"-smp",String.valueOf(cpu),"-nodefaults","-device","VGA","-display","vnc=127.0.0.1:0","-netdev","user,id=net0,restrict=on,ipv6=off,hostfwd=tcp:127.0.0.1:18006-:8006","-device","virtio-net-pci,netdev=net0","-monitor","none","-serial","none","-sandbox","on,obsolete=deny,elevateprivileges=deny,spawn=deny,resourcecontrol=deny","-drive","file="+escape(disk.toString())+",format=qcow2,if=virtio"));
  if(mode.equals("install")){Path iso=Path.of(args[2]).toRealPath();if(!Files.isRegularFile(iso))throw new IllegalArgumentException("ISO must be a regular file");cmd.addAll(List.of("-drive","file="+escape(iso.toString())+",media=cdrom,readonly=on","-boot","order=d"));}else cmd.addAll(List.of("-boot","order=c"));
  var p=new ProcessBuilder(cmd).inheritIO().start();Runtime.getRuntime().addShutdownHook(new Thread(()->p.destroy()));System.exit(p.waitFor());
 }
 static String escape(String s){return s.replace(",",",,");}
}
