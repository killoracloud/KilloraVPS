# Killora VPS v-1
Existing dashboard, Discord bot, Cloudflare tunnel and virtualization engine.

## Development / staging
Use a supported Linux host and Node.js version compatible with package dependencies. Install dependencies (`npm install`), configure environment variables from `.env.example` and the deployment guide, then run `npm run build` and `npm start`. Export environment variables before starting; do not expose development mode publicly.

See [deployment configuration](docs/DEPLOYMENT.md) and [security limitations](docs/SECURITY.md). Customer TCG is restricted to the designated trusted test owner; do not enable public customer hosting without independent isolation testing. TCG requires physical CPU/RAM but not KVM.

## Verification
`node tests/engine-static.cjs` checks source invariants. Syntax transpilation and Python compilation passed in the packaging environment; dependency installation, full build, live virtualization and security tests were not performed.
