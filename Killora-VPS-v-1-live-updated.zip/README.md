# Killora VPS v-1
Existing dashboard, Discord bot, Cloudflare tunnel and virtualization engine.

## Development / staging
Use a supported Linux host and Node.js version compatible with package dependencies. Install dependencies (`npm install`), configure environment variables from `.env.example` and the deployment guide, then run `npm run build` and `npm start`. Export environment variables before starting; do not expose development mode publicly.

See [deployment configuration](docs/DEPLOYMENT.md) and [security limitations](docs/SECURITY.md). Customer TCG is restricted to the designated trusted test owner; do not enable public customer hosting without independent isolation testing. TCG requires physical CPU/RAM but not KVM.

## Verification
`node tests/engine-static.cjs` checks source invariants. Syntax transpilation and Python compilation passed in the packaging environment; dependency installation, full build, live virtualization and security tests were not performed.

Docker plan display: neofetch, screenfetch and fastfetch are branded plan summaries installed on creation and reinstall, refreshed on resize. Existing guests are not automatically migrated. Standard resource commands remain unchanged.

## Merged live-server fixes
- nftables uses a private temporary regular file on the target node instead of /dev/stdin.
- Established SSH replies permitted in the tenant input chain; other tenant input remains blocked.
- Non-PTY command streaming no longer requests Docker TTY. Interactive PTY path unchanged.
- Provisioning errors logged on the server.
- Docker SSHX installs on demand from a trusted executable at /usr/local/bin/sshx on the node; opt-in remains required.
- Existing fetch plan display retained.
- Existing live .env, database, manual guest changes and installed host packages are not included. Automatic Pinggy, Discord reinstall repair and live Proxmox validation remain unfinished.

## Commands previously applied on the live VPS
The source patches listed above are already merged. For a private Docker test installation, run `bash scripts/configure-private-test.sh` after configuring `.env`. This preserves other settings and backs up the file. Start the panel with `node --env-file=.env --import tsx server.ts`. If manually running Incus on a Conda-based host, `bash scripts/start-incus-clean.sh` reproduces the clean PATH/library environment workaround; do not start a second daemon. Missing kernel modules and LXC boot restrictions still require host support. Install trusted SSHX on the host separately. Guest OpenSSH installation previously performed manually is not a host package or source patch; public SSH remains opt-in and is not automatically exposed. Live guest data and host package installations cannot be recovered from this source archive.
