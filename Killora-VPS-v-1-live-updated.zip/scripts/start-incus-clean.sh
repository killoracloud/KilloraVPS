#!/usr/bin/env bash
set -euo pipefail
for bin in /usr/libexec/incus/incusd /usr/lib/incus/incusd /usr/sbin/incusd; do
 if [[ -x "$bin" ]]; then exec env -u LD_LIBRARY_PATH -u LD_PRELOAD PATH=/usr/sbin:/usr/bin:/sbin:/bin "$bin" --debug; fi
done
echo 'Incus daemon not found' >&2; exit 1
