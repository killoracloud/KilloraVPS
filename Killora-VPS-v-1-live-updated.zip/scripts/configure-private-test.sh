#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
umask 077
[[ -f .env ]] || { echo 'Create and configure .env from .env.example first'; exit 1; }
cp -p .env ".env.backup.$(date +%s)"
python3 - <<'PY'
from pathlib import Path
p=Path('.env')
settings={'KC_ENABLE_DOCKER_CUSTOMERS':'1','KC_ENABLE_SANDBOX_FALLBACK':'0','KC_CUSTOMER_TCG':'0','KC_ENABLE_PUBLIC_SSH':'0','KC_ENABLE_GUEST_SSHX':'1'}
lines=[l for l in p.read_text().splitlines() if l.split('=',1)[0].strip() not in settings]
p.write_text('\n'.join(lines+[f'{k}={v}' for k,v in settings.items()])+'\n')
p.chmod(0o600)
PY
command -v docker >/dev/null && docker info --format '{{.ServerVersion}}'
if ! test -x /usr/local/bin/sshx; then echo 'Install trusted SSHX binary at /usr/local/bin/sshx before using Discord SSHX'; fi
echo 'Private test settings updated. Restart panel manually.'
